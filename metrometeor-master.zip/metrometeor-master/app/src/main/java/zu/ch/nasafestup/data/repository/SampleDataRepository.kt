package zu.ch.nasafestup.data.repository

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SampleDataRepository @Inject constructor() {
    
    // Sample data for demonstration purposes
    // This can be expanded to include actual data fetching logic
    
    fun getSampleData(): String {
        return "Sample data from repository"
    }
    
    // Add more methods as needed for your application
}
package zu.ch.nasafestup.presentation.screens.events

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import zu.ch.nasafestup.presentation.components.EventCard
import zu.ch.nasafestup.presentation.components.ScreenHeader

@Composable
fun EventsScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            ScreenHeader(
                title = "Events",
                subtitle = "Discover amazing events happening around you"
            )
            
            LazyColumn(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(getSampleEvents()) { event ->
                    EventCard(
                        title = event.title,
                        description = event.description,
                        location = event.location,
                        time = event.time,
                        onCardClick = {
                            // Navigate to event detail
                        }
                    )
                }
            }
        }
    }
}

data class SampleEvent(
    val title: String,
    val description: String,
    val location: String,
    val time: String
)

private fun getSampleEvents() = listOf(
    SampleEvent(
        "Summer Music Festival",
        "Join us for an amazing summer music festival",
        "Central Park",
        "7:00 PM"
    ),
    SampleEvent(
        "Food & Wine Expo",
        "Taste the best food and wine from local vendors",
        "Convention Center",
        "12:00 PM"
    ),
    SampleEvent(
        "Art Exhibition",
        "Contemporary art exhibition featuring local artists",
        "Museum District",
        "10:00 AM"
    )
)
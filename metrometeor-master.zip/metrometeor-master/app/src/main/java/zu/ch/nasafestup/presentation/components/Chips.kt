package zu.ch.nasafestup.presentation.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import zu.ch.nasafestup.ui.theme.NasaFestUpTheme

@Composable
fun FilterChipGroup(
    chips: List<ChipData>,
    selectedChips: Set<String>,
    onChipClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(chips) { chip ->
            FilterChip(
                onClick = { onChipClick(chip.id) },
                label = {
                    Text(
                        text = chip.label,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )
                },
                selected = selectedChips.contains(chip.id),
                leadingIcon = if (selectedChips.contains(chip.id)) {
                    {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Selected",
                            modifier = Modifier.size(FilterChipDefaults.IconSize)
                        )
                    }
                } else {
                    chip.icon?.let { icon ->
                        {
                            Icon(
                                imageVector = icon,
                                contentDescription = chip.label,
                                modifier = Modifier.size(FilterChipDefaults.IconSize)
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(16.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    }
}

@Composable
fun SuggestionChipGroup(
    chips: List<ChipData>,
    onChipClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(chips) { chip ->
            SuggestionChip(
                onClick = { onChipClick(chip.id) },
                label = {
                    Text(
                        text = chip.label,
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                icon = chip.icon?.let { icon ->
                    {
                        Icon(
                            imageVector = icon,
                            contentDescription = chip.label,
                            modifier = Modifier.size(SuggestionChipDefaults.IconSize)
                        )
                    }
                },
                shape = RoundedCornerShape(16.dp),
                colors = SuggestionChipDefaults.suggestionChipColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                border = BorderStroke(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outline
                )
            )
        }
    }
}

data class ChipData(
    val id: String,
    val label: String,
    val icon: ImageVector? = null
)

@Preview(showBackground = true)
@Composable
fun ChipsPreview() {
    NasaFestUpTheme {
        val sampleChips = listOf(
            ChipData("music", "Music"),
            ChipData("food", "Food"),
            ChipData("sports", "Sports"),
            ChipData("arts", "Arts")
        )
        
        FilterChipGroup(
            chips = sampleChips,
            selectedChips = setOf("music", "food"),
            onChipClick = { },
            modifier = Modifier.padding(16.dp)
        )
    }
}
package zu.ch.nasafestup.network.api

import zu.ch.nasafestup.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface TrafficApiService {
    
    @GET("traffic/")
    suspend fun getTrafficData(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("radius") radius: Int = 5000
    ): Response<TrafficData>
    
    @POST("traffic/route")
    suspend fun getRouteOptions(
        @Body request: Map<String, Any> // from_location, to_location, preferences
    ): Response<List<RouteOption>>
    
    @GET("traffic/disruptions")
    suspend fun getActiveDisruptions(
        @Query("latitude") latitude: Double? = null,
        @Query("longitude") longitude: Double? = null,
        @Query("radius") radius: Int = 10000
    ): Response<List<Disruption>>
    
    @GET("traffic/prediction")
    suspend fun getTrafficPrediction(
        @Query("route_id") routeId: String,
        @Query("departure_time") departureTime: String
    ): Response<RouteOption>
}

interface PlannerApiService {
    
    @GET("planner/groups")
    suspend fun getUserGroups(): Response<List<PlannerGroup>>
    
    @POST("planner/groups")
    suspend fun createGroup(
        @Body group: Map<String, Any>
    ): Response<PlannerGroup>
    
    @GET("planner/groups/{group_id}")
    suspend fun getGroupDetails(
        @Path("group_id") groupId: String
    ): Response<PlannerGroup>
    
    @PUT("planner/groups/{group_id}")
    suspend fun updateGroup(
        @Path("group_id") groupId: String,
        @Body updates: Map<String, Any>
    ): Response<PlannerGroup>
    
    @POST("planner/groups/{group_id}/members")
    suspend fun addGroupMember(
        @Path("group_id") groupId: String,
        @Body memberInfo: Map<String, String>
    ): Response<GroupMember>
    
    @DELETE("planner/groups/{group_id}/members/{member_id}")
    suspend fun removeGroupMember(
        @Path("group_id") groupId: String,
        @Path("member_id") memberId: String
    ): Response<Unit>
    
    @POST("planner/groups/{group_id}/events")
    suspend fun addEventToGroup(
        @Path("group_id") groupId: String,
        @Body eventInfo: Map<String, String>
    ): Response<Unit>
    
    @PUT("planner/groups/{group_id}/location")
    suspend fun updateMemberLocation(
        @Path("group_id") groupId: String,
        @Body location: Location
    ): Response<Unit>
}

interface SOSApiService {
    
    @GET("sos/emergency-info")
    suspend fun getEmergencyInfo(): Response<EmergencyInfo>
    
    @PUT("sos/emergency-info")
    suspend fun updateEmergencyInfo(
        @Body emergencyInfo: EmergencyInfo
    ): Response<EmergencyInfo>
    
    @POST("sos/contacts")
    suspend fun addEmergencyContact(
        @Body contact: EmergencyContact
    ): Response<EmergencyContact>
    
    @PUT("sos/contacts/{contact_id}")
    suspend fun updateEmergencyContact(
        @Path("contact_id") contactId: String,
        @Body contact: EmergencyContact
    ): Response<EmergencyContact>
    
    @DELETE("sos/contacts/{contact_id}")
    suspend fun deleteEmergencyContact(
        @Path("contact_id") contactId: String
    ): Response<Unit>
    
    @POST("sos/emergency-alert")
    suspend fun sendEmergencyAlert(
        @Body alertInfo: Map<String, Any>
    ): Response<APIResponse<String>>
    
    @PUT("sos/location-sharing")
    suspend fun updateLocationSharing(
        @Body settings: Map<String, Boolean>
    ): Response<Unit>
}

interface DealsApiService {
    
    @GET("deals/")
    suspend fun getDeals(
        @Query("category") category: String? = null,
        @Query("limit") limit: Int = 50,
        @Query("skip") skip: Int = 0,
        @Query("sort_by") sortBy: String = "discount_percentage",
        @Query("min_discount") minDiscount: Int? = null
    ): Response<DealsResponse>
    
    @GET("deals/{deal_id}")
    suspend fun getDealDetails(
        @Path("deal_id") dealId: String
    ): Response<Deal>
    
    @GET("deals/categories")
    suspend fun getDealCategories(): Response<List<String>>
    
    @GET("deals/personalized")
    suspend fun getPersonalizedDeals(
        @Query("user_preferences") preferences: String? = null
    ): Response<List<Deal>>
    
    @POST("deals/{deal_id}/favorite")
    suspend fun addToFavorites(
        @Path("deal_id") dealId: String
    ): Response<Unit>
    
    @DELETE("deals/{deal_id}/favorite")
    suspend fun removeFromFavorites(
        @Path("deal_id") dealId: String
    ): Response<Unit>
    
    @GET("deals/favorites")
    suspend fun getFavoriteDeals(): Response<List<Deal>>
    
    @POST("deals/{deal_id}/purchase")
    suspend fun purchaseDeal(
        @Path("deal_id") dealId: String,
        @Body purchaseInfo: Map<String, Any>
    ): Response<APIResponse<String>>
}

interface HeatmapApiService {
    
    @POST("heatmap/")
    suspend fun getHeatmapData(
        @Body request: HeatmapRequest
    ): Response<HeatmapResponse>
    
    @GET("heatmap/crowd")
    suspend fun getCrowdHeatmap(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("radius") radius: Int = 2000
    ): Response<List<HeatmapPoint>>
    
    @GET("heatmap/traffic")
    suspend fun getTrafficHeatmap(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("radius") radius: Int = 5000
    ): Response<List<HeatmapPoint>>
}
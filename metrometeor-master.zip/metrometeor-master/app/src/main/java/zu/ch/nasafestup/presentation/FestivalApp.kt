package zu.ch.nasafestup.presentation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import zu.ch.nasafestup.presentation.components.BottomNavigationBar
import zu.ch.nasafestup.presentation.navigation.FestivalNavGraph
import zu.ch.nasafestup.presentation.navigation.Screen
import zu.ch.nasafestup.presentation.navigation.bottomNavigationItems

@Composable
fun FestivalApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    
    // Determine if bottom navigation should be shown
    val showBottomNav = bottomNavigationItems.any { screen ->
        currentDestination?.hierarchy?.any { it.route == screen.route } == true
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Scaffold(
            bottomBar = {
                AnimatedVisibility(
                    visible = showBottomNav,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                ) {
                    BottomNavigationBar(
                        items = bottomNavigationItems,
                        currentDestination = currentDestination,
                        onItemClick = { screen ->
                            navController.navigate(screen.route) {
                                // Pop up to the start destination to avoid large back stack
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                // Avoid multiple copies of the same destination
                                launchSingleTop = true
                                // Restore state when re-selecting a previously selected item
                                restoreState = true
                            }
                        }
                    )
                }
            }
        ) { paddingValues ->
            FestivalNavGraph(
                navController = navController,
                startDestination = Screen.Home.route
            )
        }
    }
}
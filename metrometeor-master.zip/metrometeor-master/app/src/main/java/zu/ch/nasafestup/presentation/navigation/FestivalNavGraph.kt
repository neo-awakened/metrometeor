package zu.ch.nasafestup.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import zu.ch.nasafestup.presentation.screens.deals.DealsScreen
import zu.ch.nasafestup.presentation.screens.events.EventsScreen
import zu.ch.nasafestup.presentation.screens.home.HomeScreen
import zu.ch.nasafestup.presentation.screens.more.MoreScreen
import zu.ch.nasafestup.presentation.screens.offlinemaps.OfflineMapsScreen
import zu.ch.nasafestup.presentation.screens.planner.PlannerScreen
import zu.ch.nasafestup.presentation.screens.sos.SOSScreen
import zu.ch.nasafestup.presentation.screens.traffic.TrafficScreen

@Composable
fun FestivalNavGraph(
    navController: NavHostController,
    startDestination: String = Screen.Home.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Bottom Navigation Screens
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        
        composable(Screen.Events.route) {
            EventsScreen(navController = navController)
        }
        
        composable(Screen.Traffic.route) {
            TrafficScreen(navController = navController)
        }
        
        composable(Screen.Planner.route) {
            PlannerScreen(navController = navController)
        }
        
        composable(Screen.More.route) {
            MoreScreen(navController = navController)
        }
        
        // Secondary Screens
        composable(Screen.SOS.route) {
            SOSScreen(navController = navController)
        }
        
        composable(Screen.OfflineMaps.route) {
            OfflineMapsScreen(navController = navController)
        }
        
        composable(Screen.Deals.route) {
            DealsScreen(navController = navController)
        }
        
        // Detail Screens
        composable(Screen.EventDetail.route) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: ""
            // EventDetailScreen(eventId = eventId, navController = navController)
        }
        
        composable(Screen.GroupDetail.route) { backStackEntry ->
            val groupId = backStackEntry.arguments?.getString("groupId") ?: ""
            // GroupDetailScreen(groupId = groupId, navController = navController)
        }
        
        composable(Screen.DealDetail.route) { backStackEntry ->
            val dealId = backStackEntry.arguments?.getString("dealId") ?: ""
            // DealDetailScreen(dealId = dealId, navController = navController)
        }
    }
}
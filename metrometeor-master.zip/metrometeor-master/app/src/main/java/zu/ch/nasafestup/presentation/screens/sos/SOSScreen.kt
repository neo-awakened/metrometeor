package zu.ch.nasafestup.presentation.screens.sos

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import zu.ch.nasafestup.presentation.components.EmergencyButton
import zu.ch.nasafestup.presentation.components.ScreenHeader

@Composable
fun SOSScreen(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            ScreenHeader(
                title = "SOS Settings",
                subtitle = "Emergency contacts and safety information"
            )
            
            EmergencyButton(
                onClick = {
                    // Handle emergency action
                }
            )
            
            Text(
                text = "Emergency Features:",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Medium
            )
            
            Text(
                text = "• Quick access to emergency services
" +
                        "• Share location with emergency contacts
" +
                        "• Medical information storage
" +
                        "• Emergency contact management
" +
                        "• Safety check-in features",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
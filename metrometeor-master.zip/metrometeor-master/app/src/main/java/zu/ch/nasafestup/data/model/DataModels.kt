package zu.ch.nasafestup.data.model

data class WashroomModel(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val washroomType: String,
    val isAccessible: Boolean,
    val isFree: Boolean,
    val isOpen24h: Boolean,
    val district: String?,
    val description: String?
)

data class WashroomResponse(
    val washrooms: List<WashroomModel>,
    val total: Int,
    val page: Int,
    val limit: Int
)

data class WashroomSearchRequest(
    val latitude: Double,
    val longitude: Double,
    val radius: Int = 1000,
    val washroomType: String? = null,
    val accessibilityRequired: Boolean = false,
    val freeOnly: Boolean = false,
    val open24hOnly: Boolean = false
)

data class APIResponse<T>(
    val data: T,
    val message: String?,
    val success: Boolean
)

data class TrafficData(
    val congestionLevel: String,
    val avgSpeed: Double,
    val estimatedDelay: Int,
    val routes: List<RouteOption>
)

data class RouteOption(
    val id: String,
    val duration: Int,
    val distance: Double,
    val traffic: String,
    val description: String
)

data class Disruption(
    val id: String,
    val type: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    val severity: String,
    val startTime: String,
    val estimatedEndTime: String?
)

data class PlannerGroup(
    val id: String,
    val name: String,
    val description: String?,
    val members: List<GroupMember>,
    val events: List<String>,
    val createdAt: String
)

data class GroupMember(
    val id: String,
    val name: String,
    val status: String,
    val lastLocation: Location?,
    val joinedAt: String
)

data class Location(
    val latitude: Double,
    val longitude: Double,
    val timestamp: String
)

data class EmergencyInfo(
    val id: String,
    val fullName: String,
    val medicalConditions: String?,
    val medications: String?,
    val bloodType: String?,
    val allergies: String?,
    val emergencyContacts: List<EmergencyContact>
)

data class EmergencyContact(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val relationship: String,
    val isPrimary: Boolean
)

data class DealsResponse(
    val deals: List<Deal>,
    val total: Int,
    val page: Int,
    val limit: Int
)

data class Deal(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val originalPrice: Double,
    val discountedPrice: Double,
    val discountPercentage: Int,
    val validUntil: String,
    val vendor: String,
    val imageUrl: String?,
    val termsAndConditions: String?
)

data class HeatmapRequest(
    val latitude: Double,
    val longitude: Double,
    val radius: Int,
    val type: String // "crowd", "traffic", etc.
)

data class HeatmapResponse(
    val points: List<HeatmapPoint>,
    val timestamp: String
)

data class HeatmapPoint(
    val latitude: Double,
    val longitude: Double,
    val intensity: Float,
    val timestamp: String
)
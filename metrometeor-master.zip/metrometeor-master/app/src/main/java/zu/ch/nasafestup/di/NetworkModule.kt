package zu.ch.nasafestup.di

import zu.ch.nasafestup.network.api.WashroomApiService
import zu.ch.nasafestup.network.api.TrafficApiService
import zu.ch.nasafestup.network.api.PlannerApiService
import zu.ch.nasafestup.network.api.SOSApiService
import zu.ch.nasafestup.network.api.DealsApiService
import zu.ch.nasafestup.network.api.HeatmapApiService
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    
    // TODO: Change this to your actual backend URL
    // For local development: "http://10.0.2.2:8000/api/v1/" (Android emulator)
    // For device testing: "http://YOUR_LOCAL_IP:8000/api/v1/"
    // For production: "https://your-backend-domain.com/api/v1/"
    private const val BASE_URL = "http://10.0.2.2:8000/api/v1/"
    
    @Provides
    @Singleton
    fun provideGson(): Gson {
        return GsonBuilder()
            .setLenient()
            .create()
    }
    
    @Provides
    @Singleton
    fun provideHttpLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
    }
    
    @Provides
    @Singleton
    fun provideOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }
    
    @Provides
    @Singleton
    fun provideRetrofit(
        okHttpClient: OkHttpClient,
        gson: Gson
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
    }
    
    @Provides
    @Singleton
    fun provideWashroomApiService(retrofit: Retrofit): WashroomApiService {
        return retrofit.create(WashroomApiService::class.java)
    }
    
    @Provides
    @Singleton
    fun provideTrafficApiService(retrofit: Retrofit): TrafficApiService {
        return retrofit.create(TrafficApiService::class.java)
    }
    
    @Provides
    @Singleton
    fun providePlannerApiService(retrofit: Retrofit): PlannerApiService {
        return retrofit.create(PlannerApiService::class.java)
    }
    
    @Provides
    @Singleton
    fun provideSOSApiService(retrofit: Retrofit): SOSApiService {
        return retrofit.create(SOSApiService::class.java)
    }
    
    @Provides
    @Singleton
    fun provideDealsApiService(retrofit: Retrofit): DealsApiService {
        return retrofit.create(DealsApiService::class.java)
    }
    
    @Provides
    @Singleton
    fun provideHeatmapApiService(retrofit: Retrofit): HeatmapApiService {
        return retrofit.create(HeatmapApiService::class.java)
    }
}
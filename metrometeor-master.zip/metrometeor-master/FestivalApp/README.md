# Festival App - Modern Android Application

A comprehensive Android application built with Kotlin and Jetpack Compose, featuring an interactive festival and events management system with advanced mapping, traffic simulation, group coordination, and emergency safety features.

## 🌟 Features

### 🏠 Home Screen (Map Interface)
- **Interactive Google Maps Integration**
  - Real-time event markers with category-based colors
  - Traffic indicators and alerts
  - Location-based services
  - Smooth map animations and gestures

- **Smart Bottom Sheet**
  - Collapsible event preview panel
  - Pull-to-expand with haptic feedback
  - Quick event statistics and traffic status

- **Advanced Search & Navigation**
  - Real-time search with suggestions
  - Voice search integration ready
  - Profile and settings quick access

### 📅 Events Screen
- **Advanced Event Discovery**
  - Smart filtering by category (Music, Food, Art, Sports, etc.)
  - Real-time search with instant results
  - Multiple sorting options (Date, Distance, Popularity, Price)
  - Pull-to-refresh functionality

- **Rich Event Cards**
  - Animated card interactions
  - Crowd density indicators with color coding
  - Distance calculation and navigation
  - Bookmark and sharing capabilities
  - High-quality image support

### 🚗 Traffic Screen
- **AI-Powered Traffic Insights**
  - Real-time traffic prediction
  - Construction and event-based alerts
  - Alternative route suggestions
  - Integration with external navigation apps

### 👥 Planner Screen (Group Coordination)
- **Advanced Group Management**
  - Create and join groups
  - Real-time member location sharing
  - Group chat with location features
  - Collaborative event planning
  - Emergency coordination protocols

### 🆘 Emergency Features
- **SOS Settings & Safety**
  - Quick emergency contact access
  - Medical information storage
  - Crisis management tools
  - Location sharing controls
  - Accessibility features for emergency situations

### 📱 Additional Screens
- **Offline Maps**: Smart map downloading and storage management
- **Deals & Tickets**: AI-powered deal discovery and group booking
- **More**: Settings, profile management, and additional features

## 🏗️ Architecture

### Modern Android Development Stack
- **Language**: Kotlin 100%
- **UI Framework**: Jetpack Compose
- **Architecture Pattern**: MVVM (Model-View-ViewModel)
- **Dependency Injection**: Dagger Hilt
- **Navigation**: Navigation Compose
- **State Management**: StateFlow & Compose State

### Key Components
```
📁 app/src/main/java/com/festivalapp/
├── 📁 data/
│   ├── 📁 model/          # Data models and entities
│   └── 📁 repository/     # Data repositories and sample data
├── 📁 di/                 # Dependency injection modules
├── 📁 presentation/
│   ├── 📁 components/     # Reusable UI components
│   ├── 📁 navigation/     # Navigation setup and routing
│   ├── 📁 screens/        # Screen implementations
│   │   ├── 📁 home/       # Home screen with map
│   │   ├── 📁 events/     # Events listing and filtering
│   │   ├── 📁 traffic/    # Traffic simulation
│   │   ├── 📁 planner/    # Group coordination
│   │   └── 📁 more/       # Additional features
│   └── FestivalApp.kt     # Main app composable
└── 📁 ui/theme/           # Material Design 3 theming
```

## 🎨 Design System

### Material Design 3 Implementation
- **Color Palette**: 
  - Primary: Blue (#2196F3) - Navigation and primary actions
  - Secondary: Orange (#FF5722) - Events and highlights
  - Success: Green (#4CAF50) - Confirmations and safety
  - Error: Red (#F44336) - Emergency and warnings

- **Typography**: Roboto font family with proper hierarchy
- **Spacing**: 4dp base unit system for consistent spacing
- **Components**: Custom Material 3 components with animations

### Reusable Components
- ✅ **Buttons**: Primary, Secondary, Emergency, Action buttons
- ✅ **Cards**: Event cards with animations and interactions
- ✅ **Navigation**: Bottom navigation with badge support
- ✅ **Chips**: Filter chips with selection states
- ✅ **Headers**: App headers with search and actions
- ✅ **Loading**: Various loading indicators and skeleton screens

## 🚀 Animations & Interactions

### Micro-interactions
- **Button Press**: Scale animation with elevation change
- **Card Tap**: Elevation and scale effects
- **Navigation**: Smooth transitions between screens
- **Loading States**: Pulsing and rotating indicators

### Screen Transitions
- **Push Navigation**: Slide from right (Android standard)
- **Modal Presentation**: Slide up from bottom
- **Bottom Sheet**: Gesture-driven with rubber band effect

### Advanced Animations
- **Map Markers**: Bounce animation on tap
- **Filter Chips**: Color and scale transitions
- **Search Bar**: Expand/collapse with smooth easing
- **Pull-to-Refresh**: Custom spring animations

## 📱 Platform Features

### Android Integration
- **Edge-to-Edge UI**: Modern immersive experience
- **Material You**: Dynamic colors (can be enabled)
- **Permissions**: Location, Camera, Phone for full functionality
- **Deep Links**: Custom URL scheme support
- **Notifications**: Event updates and group coordination

### Performance Optimizations
- **Lazy Loading**: Efficient list rendering
- **Image Caching**: Coil for optimized image loading
- **State Management**: Efficient state flow management
- **Memory**: Proper lifecycle management

## 🛠️ Development Setup

### Prerequisites
- Android Studio Hedgehog | 2023.1.1 or later
- JDK 8 or higher
- Android SDK API 26+ (Android 8.0)
- Google Maps API Key

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone [repository-url]
   cd FestivalApp
   ```

2. **Configure Google Maps API**
   - Get API key from [Google Cloud Console](https://console.cloud.google.com/)
   - Add to `local.properties`:
     ```
     MAPS_API_KEY=YOUR_GOOGLE_MAPS_API_KEY_HERE
     ```

3. **Build and Run**
   ```bash
   ./gradlew assembleDebug
   ./gradlew installDebug
   ```

### Dependencies
```kotlin
// Core Android
implementation("androidx.core:core-ktx:1.12.0")
implementation("androidx.activity:activity-compose:1.8.2")

// Compose & Material Design 3
implementation(platform("androidx.compose:compose-bom:2023.10.01"))
implementation("androidx.compose.material3:material3")

// Navigation & Architecture
implementation("androidx.navigation:navigation-compose:2.7.6")
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")

// Dependency Injection
implementation("com.google.dagger:hilt-android:2.48")

// Maps & Location
implementation("com.google.maps.android:maps-compose:4.3.0")
implementation("com.google.android.gms:play-services-maps:18.2.0")

// Networking & Images
implementation("com.squareup.retrofit2:retrofit:2.9.0")
implementation("io.coil-kt:coil-compose:2.5.0")

// Animations
implementation("com.airbnb.android:lottie-compose:6.2.0")
```

## 📊 Sample Data

The app includes comprehensive sample data for demonstration:

### Events
- **5 Sample Events** across different categories
- **Realistic Zurich locations** with proper coordinates
- **Crowd levels and timing** information
- **Pricing and organizer** details

### Traffic Information
- **Real-time traffic simulation** with different severity levels
- **Construction and event-based** alerts
- **Estimated delays** and affected routes

### Groups & Social Features
- **Sample groups** with member management
- **Real-time status** indicators
- **Planned events** and coordination features

## 🎯 Key Features Implemented

### ✅ Completed Features
1. **Project Structure** - Modern Android architecture with MVVM
2. **Navigation System** - Bottom navigation with smooth transitions
3. **Design System** - Material Design 3 components and theming
4. **Home Screen** - Interactive map with Google Maps integration
5. **Events Screen** - Advanced filtering, search, and card animations

### 🚧 Next Development Phases
6. **Traffic Screen** - Route planning and real-time updates
7. **Planner Screen** - Group management and collaboration tools
8. **Additional Screens** - SOS, Offline Maps, and Deals features
9. **Enhanced Animations** - Gesture-based interactions and transitions
10. **Testing & Polish** - Comprehensive testing and bug fixes

## 🔧 Customization

### Theme Customization
```kotlin
// Update colors in ui/theme/Color.kt
val PrimaryBlue = Color(0xFF2196F3)  // Change primary color
val AccentOrange = Color(0xFFFF5722) // Change accent color

// Modify typography in ui/theme/Type.kt
val Typography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp) // Adjust text sizes
)
```

### Adding New Screens
1. Create new package in `presentation/screens/`
2. Implement ViewModel with Hilt injection
3. Create Composable screen function
4. Add route to `navigation/Screen.kt`
5. Update `navigation/FestivalNavGraph.kt`

## 📱 Screenshots

*Screenshots and demo videos can be added here once the app is fully running*

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Material Design 3** guidelines and components
- **Jetpack Compose** for modern UI development
- **Google Maps Platform** for mapping services
- **Android Developer Community** for best practices and inspiration

---

**Built with ❤️ using Modern Android Development practices**
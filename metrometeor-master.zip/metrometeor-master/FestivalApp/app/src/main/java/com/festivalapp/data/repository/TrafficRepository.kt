package com.festivalapp.data.repository

import com.festivalapp.data.model.*
import com.festivalapp.network.api.TrafficApiService
import com.festivalapp.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TrafficRepository @Inject constructor(
    private val api: TrafficApiService
) {
    
    suspend fun getTrafficData(
        latitude: Double,
        longitude: Double,
        radius: Int = 5000
    ): Flow<Resource<TrafficData>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getTrafficData(latitude, longitude, radius)
            
            if (response.isSuccessful) {
                response.body()?.let { trafficData ->
                    emit(Resource.Success(trafficData))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getRouteOptions(
        fromLocation: Location,
        toLocation: Location,
        preferences: Map<String, Any> = emptyMap()
    ): Flow<Resource<List<RouteOption>>> = flow {
        try {
            emit(Resource.Loading())
            
            val request = mapOf(
                "from_location" to fromLocation,
                "to_location" to toLocation,
                "preferences" to preferences
            )
            
            val response = api.getRouteOptions(request)
            
            if (response.isSuccessful) {
                response.body()?.let { routes ->
                    emit(Resource.Success(routes))
                } ?: emit(Resource.Error("No routes found"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getActiveDisruptions(
        latitude: Double? = null,
        longitude: Double? = null,
        radius: Int = 10000
    ): Flow<Resource<List<Disruption>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getActiveDisruptions(latitude, longitude, radius)
            
            if (response.isSuccessful) {
                response.body()?.let { disruptions ->
                    emit(Resource.Success(disruptions))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
}
package com.festivalapp.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val PrimaryBlue = Color(0xFF2196F3)
val PrimaryBlueDark = Color(0xFF1976D2)
val PrimaryBlueLight = Color(0xFFBBDEFB)

// Secondary Colors
val AccentOrange = Color(0xFFFF5722)
val AccentOrangeDark = Color(0xFFE64A19)
val AccentOrangeLight = Color(0xFFFFCCBC)

// Status Colors
val SuccessGreen = Color(0xFF4CAF50)
val WarningYellow = Color(0xFFFFC107)
val ErrorRed = Color(0xFFF44336)
val InfoBlue = Color(0xFF2196F3)

// Traffic Colors
val TrafficGreen = Color(0xFF4CAF50)
val TrafficYellow = Color(0xFFFFC107)
val TrafficOrange = Color(0xFFFF5722)
val TrafficRed = Color(0xFFF44336)

// Crowd Density Colors
val CrowdLow = Color(0xFF4CAF50)
val CrowdMedium = Color(0xFFFFC107)
val CrowdHigh = Color(0xFFFF5722)
val CrowdVeryHigh = Color(0xFFF44336)

// Neutral Colors
val TextPrimary = Color(0xFF212121)
val TextSecondary = Color(0xFF757575)
val TextHint = Color(0xFFBDBDBD)
val DividerColor = Color(0xFFE0E0E0)
val BackgroundColor = Color(0xFFFAFAFA)
val SurfaceColor = Color(0xFFFFFFFF)
val SurfaceVariant = Color(0xFFF5F5F5)

// Emergency Colors
val EmergencyRed = Color(0xFFF44336)
val EmergencyRedDark = Color(0xFFD32F2F)
val EmergencyBackground = Color(0xFFFFEBEE)

// Material Design 3 Light Colors
val md_theme_light_primary = Color(0xFF2196F3)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFBBDEFB)
val md_theme_light_onPrimaryContainer = Color(0xFF0D47A1)
val md_theme_light_secondary = Color(0xFFFF5722)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFFFCCBC)
val md_theme_light_onSecondaryContainer = Color(0xFFBF360C)
val md_theme_light_tertiary = Color(0xFF4CAF50)
val md_theme_light_onTertiary = Color(0xFFFFFFFF)
val md_theme_light_tertiaryContainer = Color(0xFFC8E6C9)
val md_theme_light_onTertiaryContainer = Color(0xFF1B5E20)
val md_theme_light_error = Color(0xFFF44336)
val md_theme_light_errorContainer = Color(0xFFFFEBEE)
val md_theme_light_onError = Color(0xFFFFFFFF)
val md_theme_light_onErrorContainer = Color(0xFFB71C1C)
val md_theme_light_background = Color(0xFFFAFAFA)
val md_theme_light_onBackground = Color(0xFF212121)
val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF212121)
val md_theme_light_surfaceVariant = Color(0xFFF5F5F5)
val md_theme_light_onSurfaceVariant = Color(0xFF757575)
val md_theme_light_outline = Color(0xFFE0E0E0)
val md_theme_light_inverseOnSurface = Color(0xFFFAFAFA)
val md_theme_light_inverseSurface = Color(0xFF212121)
val md_theme_light_inversePrimary = Color(0xFF90CAF9)

// Material Design 3 Dark Colors
val md_theme_dark_primary = Color(0xFF90CAF9)
val md_theme_dark_onPrimary = Color(0xFF0D47A1)
val md_theme_dark_primaryContainer = Color(0xFF1976D2)
val md_theme_dark_onPrimaryContainer = Color(0xFFBBDEFB)
val md_theme_dark_secondary = Color(0xFFFFAB91)
val md_theme_dark_onSecondary = Color(0xFFBF360C)
val md_theme_dark_secondaryContainer = Color(0xFFE64A19)
val md_theme_dark_onSecondaryContainer = Color(0xFFFFCCBC)
val md_theme_dark_tertiary = Color(0xFFA5D6A7)
val md_theme_dark_onTertiary = Color(0xFF1B5E20)
val md_theme_dark_tertiaryContainer = Color(0xFF388E3C)
val md_theme_dark_onTertiaryContainer = Color(0xFFC8E6C9)
val md_theme_dark_error = Color(0xFFEF5350)
val md_theme_dark_errorContainer = Color(0xFFB71C1C)
val md_theme_dark_onError = Color(0xFFFFFFFF)
val md_theme_dark_onErrorContainer = Color(0xFFFFCDD2)
val md_theme_dark_background = Color(0xFF121212)
val md_theme_dark_onBackground = Color(0xFFFFFFFF)
val md_theme_dark_surface = Color(0xFF1E1E1E)
val md_theme_dark_onSurface = Color(0xFFFFFFFF)
val md_theme_dark_surfaceVariant = Color(0xFF2C2C2C)
val md_theme_dark_onSurfaceVariant = Color(0xFFBDBDBD)
val md_theme_dark_outline = Color(0xFF616161)
val md_theme_dark_inverseOnSurface = Color(0xFF121212)
val md_theme_dark_inverseSurface = Color(0xFFFFFFFF)
val md_theme_dark_inversePrimary = Color(0xFF2196F3)
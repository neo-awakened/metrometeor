package com.festivalapp.data.repository

import com.festivalapp.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SampleDataRepository @Inject constructor() {
    
    // Sample Events Data
    fun getEvents(): Flow<List<Event>> = flow {
        delay(500) // Simulate network delay
        emit(sampleEvents)
    }
    
    fun getEventById(id: String): Flow<Event?> = flow {
        delay(300)
        emit(sampleEvents.find { it.id == id })
    }
    
    fun getEventsNearLocation(location: Location, radiusKm: Double): Flow<List<Event>> = flow {
        delay(400)
        emit(sampleEvents.filter { event ->
            // Simple distance calculation (not precise for production)
            val distance = calculateDistance(location, event.location)
            distance <= radiusKm
        })
    }
    
    // Sample Traffic Data
    fun getTrafficInfo(): Flow<List<TrafficInfo>> = flow {
        delay(300)
        emit(sampleTrafficInfo)
    }
    
    // Sample Groups Data
    fun getUserGroups(): Flow<List<Group>> = flow {
        delay(400)
        emit(sampleGroups)
    }
    
    // Sample Deals Data
    fun getDeals(): Flow<List<Deal>> = flow {
        delay(350)
        emit(sampleDeals)
    }
    
    // Sample Offline Maps Data
    fun getOfflineMapAreas(): Flow<List<OfflineMapArea>> = flow {
        delay(200)
        emit(sampleOfflineMapAreas)
    }
    
    // Utility function for distance calculation
    private fun calculateDistance(loc1: Location, loc2: Location): Double {
        val earthRadius = 6371.0 // Earth's radius in kilometers
        val lat1Rad = Math.toRadians(loc1.latitude)
        val lon1Rad = Math.toRadians(loc1.longitude)
        val lat2Rad = Math.toRadians(loc2.latitude)
        val lon2Rad = Math.toRadians(loc2.longitude)
        
        val deltaLat = lat2Rad - lat1Rad
        val deltaLon = lon2Rad - lon1Rad
        
        val a = kotlin.math.sin(deltaLat / 2) * kotlin.math.sin(deltaLat / 2) +
                kotlin.math.cos(lat1Rad) * kotlin.math.cos(lat2Rad) *
                kotlin.math.sin(deltaLon / 2) * kotlin.math.sin(deltaLon / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        
        return earthRadius * c
    }
    
    companion object {
        // Zurich, Switzerland coordinates for sample data
        private val zurichCenter = Location(47.3769, 8.5417, "Zurich, Switzerland")
        
        val sampleEvents = listOf(
            Event(
                id = "1",
                title = "Summer Music Festival",
                description = "Experience the best electronic music artists from around the world in this spectacular outdoor festival.",
                category = EventCategory.MUSIC,
                location = Location(47.3761, 8.5490, "Limmatquai 1, 8001 Zurich", "Riverside Stage"),
                startTime = System.currentTimeMillis() + 3600000, // 1 hour from now
                endTime = System.currentTimeMillis() + 14400000, // 4 hours from now
                imageUrl = null,
                crowdLevel = CrowdLevel.HIGH,
                ticketPrice = 45.0,
                organizer = "Zurich Events AG",
                tags = listOf("electronic", "outdoor", "dancing")
            ),
            Event(
                id = "2",
                title = "Street Food Market",
                description = "Taste delicious food from around the world at our international street food market.",
                category = EventCategory.FOOD,
                location = Location(47.3774, 8.5391, "Bahnhofstrasse 15, 8001 Zurich", "Central Plaza"),
                startTime = System.currentTimeMillis() + 1800000, // 30 minutes from now
                endTime = System.currentTimeMillis() + 21600000, // 6 hours from now
                imageUrl = null,
                crowdLevel = CrowdLevel.MEDIUM,
                organizer = "Food Festival Zurich",
                tags = listOf("food", "international", "family-friendly")
            ),
            Event(
                id = "3",
                title = "Art Gallery Opening",
                description = "Contemporary art exhibition featuring local and international artists.",
                category = EventCategory.ART,
                location = Location(47.3738, 8.5407, "Kunsthaus Zurich, Heimplatz 1", "Main Gallery"),
                startTime = System.currentTimeMillis() + 7200000, // 2 hours from now
                endTime = System.currentTimeMillis() + 18000000, // 5 hours from now
                imageUrl = null,
                crowdLevel = CrowdLevel.LOW,
                ticketPrice = 25.0,
                organizer = "Kunsthaus Zurich",
                tags = listOf("art", "culture", "exhibition")
            ),
            Event(
                id = "4",
                title = "Lake Zurich Festival",
                description = "Annual celebration with fireworks, boat tours, and live entertainment.",
                category = EventCategory.FESTIVAL,
                location = Location(47.3667, 8.5500, "Lake Zurich Promenade", "Waterfront"),
                startTime = System.currentTimeMillis() + 10800000, // 3 hours from now
                endTime = System.currentTimeMillis() + 25200000, // 7 hours from now
                imageUrl = null,
                crowdLevel = CrowdLevel.VERY_HIGH,
                organizer = "City of Zurich",
                tags = listOf("festival", "fireworks", "family-friendly")
            ),
            Event(
                id = "5",
                title = "Tech Workshop: AI & Future",
                description = "Learn about the latest developments in artificial intelligence and machine learning.",
                category = EventCategory.WORKSHOP,
                location = Location(47.3836, 8.5354, "ETH Zurich, Rämistrasse 101", "Auditorium Maximum"),
                startTime = System.currentTimeMillis() + 5400000, // 1.5 hours from now
                endTime = System.currentTimeMillis() + 12600000, // 3.5 hours from now
                imageUrl = null,
                crowdLevel = CrowdLevel.MEDIUM,
                ticketPrice = 15.0,
                organizer = "ETH Zurich",
                tags = listOf("technology", "workshop", "AI", "learning")
            )
        )
        
        val sampleTrafficInfo = listOf(
            TrafficInfo(
                id = "t1",
                location = Location(47.3850, 8.5200, "A1 Highway near Zurich"),
                level = TrafficLevel.HEAVY,
                description = "Construction work causing delays",
                estimatedDelay = 15,
                affectedRoutes = listOf("A1", "A3"),
                lastUpdated = System.currentTimeMillis() - 300000 // 5 minutes ago
            ),
            TrafficInfo(
                id = "t2",
                location = Location(47.3700, 8.5300, "Bahnhofstrasse"),
                level = TrafficLevel.MODERATE,
                description = "Event-related traffic congestion",
                estimatedDelay = 8,
                affectedRoutes = listOf("Bahnhofstrasse", "Limmatquai"),
                lastUpdated = System.currentTimeMillis() - 180000 // 3 minutes ago
            )
        )
        
        val sampleGroups = listOf(
            Group(
                id = "g1",
                name = "Festival Explorers",
                description = "We love discovering new festivals and events together!",
                members = listOf(
                    GroupMember("m1", "Alice", null, true, null, null, GroupRole.ADMIN),
                    GroupMember("m2", "Bob", null, false, System.currentTimeMillis() - 1800000),
                    GroupMember("m3", "Charlie", null, true)
                ),
                createdBy = "m1",
                createdAt = System.currentTimeMillis() - 2592000000, // 30 days ago
                plannedEvents = listOf("1", "4")
            ),
            Group(
                id = "g2",
                name = "Foodies United",
                description = "Food lovers exploring the best culinary experiences in the city.",
                members = listOf(
                    GroupMember("m4", "Diana", null, true, null, null, GroupRole.ADMIN),
                    GroupMember("m5", "Eve", null, true),
                    GroupMember("m6", "Frank", null, false, System.currentTimeMillis() - 900000)
                ),
                createdBy = "m4",
                createdAt = System.currentTimeMillis() - 1296000000, // 15 days ago
                plannedEvents = listOf("2")
            )
        )
        
        val sampleDeals = listOf(
            Deal(
                id = "d1",
                title = "Festival Pass - 2 Days",
                description = "Access to all music events for the weekend",
                originalPrice = 120.0,
                discountedPrice = 85.0,
                discountPercentage = 29,
                validUntil = System.currentTimeMillis() + 2592000000, // 30 days from now
                category = DealCategory.TICKETS,
                vendor = "EventBrite Zurich",
                location = zurichCenter,
                isGroupDeal = true,
                minGroupSize = 4
            ),
            Deal(
                id = "d2",
                title = "Hotel Downtown - Weekend Stay",
                description = "Luxury accommodation in the heart of Zurich",
                originalPrice = 280.0,
                discountedPrice = 210.0,
                discountPercentage = 25,
                validUntil = System.currentTimeMillis() + 1296000000, // 15 days from now
                category = DealCategory.ACCOMMODATION,
                vendor = "Zurich Hotels",
                location = zurichCenter
            )
        )
        
        val sampleOfflineMapAreas = listOf(
            OfflineMapArea(
                id = "om1",
                name = "Zurich City Center",
                centerLocation = zurichCenter,
                boundingBox = BoundingBox(
                    northEast = Location(47.3900, 8.5600, ""),
                    southWest = Location(47.3600, 8.5200, "")
                ),
                sizeInMB = 45.2,
                isDownloaded = true,
                downloadProgress = 1.0f,
                lastUpdated = System.currentTimeMillis() - 86400000 // 1 day ago
            ),
            OfflineMapArea(
                id = "om2",
                name = "Lake Zurich Area",
                centerLocation = Location(47.3500, 8.5500, "Lake Zurich"),
                boundingBox = BoundingBox(
                    northEast = Location(47.3700, 8.5800, ""),
                    southWest = Location(47.3300, 8.5200, "")
                ),
                sizeInMB = 32.8,
                isDownloaded = false,
                downloadProgress = 0.0f
            )
        )
    }
}
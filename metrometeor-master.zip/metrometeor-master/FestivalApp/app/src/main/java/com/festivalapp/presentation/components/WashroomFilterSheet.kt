package com.festivalapp.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.festivalapp.data.model.WashroomType
import com.festivalapp.presentation.screens.home.WashroomFilter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WashroomFilterSheet(
    filter: WashroomFilter,
    onFilterChanged: (WashroomFilter) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Handle bar
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .background(
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(2.dp)
                    )
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Title
            Text(
                text = "Washroom Filters",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Washroom type section
            Text(
                text = "Type",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WashroomType.values().forEach { type ->
                    FilterChip(
                        onClick = { 
                            onFilterChanged(
                                filter.copy(
                                    type = if (filter.type == type) null else type
                                )
                            )
                        },
                        label = { 
                            Text(
                                text = when (type) {
                                    WashroomType.FIXED -> "Fixed"
                                    WashroomType.MOBILE -> "Mobile"
                                    WashroomType.PISSOIR -> "Pissoir"
                                }
                            )
                        },
                        selected = filter.type == type,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Options section
            Text(
                text = "Options",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Accessibility
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Accessible,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Wheelchair Accessible",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Switch(
                    checked = filter.accessibilityRequired,
                    onCheckedChange = { 
                        onFilterChanged(filter.copy(accessibilityRequired = it))
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Free only
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachMoney,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Free Only",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Switch(
                    checked = filter.freeOnly,
                    onCheckedChange = { 
                        onFilterChanged(filter.copy(freeOnly = it))
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // 24h only
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Open 24 Hours",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Switch(
                    checked = filter.open24hOnly,
                    onCheckedChange = { 
                        onFilterChanged(filter.copy(open24hOnly = it))
                    }
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Search radius
            Text(
                text = "Search Radius: ${filter.radiusMeters}m",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Slider(
                value = filter.radiusMeters.toFloat(),
                onValueChange = { 
                    onFilterChanged(filter.copy(radiusMeters = it.toInt()))
                },
                valueRange = 100f..5000f,
                steps = 9, // 100, 500, 1000, 1500, 2000, 2500, 3000, 4000, 5000
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Reset button
            OutlinedButton(
                onClick = { 
                    onFilterChanged(WashroomFilter()) // Reset to default
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Reset Filters")
            }
            
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
package com.festivalapp.presentation.screens.offlinemaps

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.festivalapp.data.model.MapRegion
import com.festivalapp.presentation.components.LoadingIndicator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfflineMapsScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: OfflineMapsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Offline Maps", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = viewModel::refreshMaps) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = modifier.fillMaxSize().padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Storage Info
            uiState.mapData?.let { mapData ->
                item {
                    StorageInfoCard(
                        totalStorageUsed = mapData.totalStorageUsed,
                        availableStorage = mapData.availableStorage,
                        downloadedRegions = mapData.downloadedRegions.size
                    )
                }
                
                // Downloaded Maps
                if (mapData.downloadedRegions.isNotEmpty()) {
                    item {
                        Text(
                            text = "Downloaded Maps",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    items(mapData.downloadedRegions) { region ->
                        MapRegionCard(
                            region = region,
                            onDownload = { viewModel.downloadMap(region.id) },
                            onDelete = { viewModel.deleteMap(region.id) }
                        )
                    }
                }
                
                // Available Maps
                item {
                    Text(
                        text = "Available for Download",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                items(mapData.availableRegions.filter { !it.isDownloaded }) { region ->
                    MapRegionCard(
                        region = region,
                        onDownload = { viewModel.downloadMap(region.id) },
                        onDelete = { viewModel.deleteMap(region.id) }
                    )
                }
            }
            
            if (uiState.isLoading) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        LoadingIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageInfoCard(
    totalStorageUsed: Double,
    availableStorage: Double,
    downloadedRegions: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Storage Information",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StorageStat(
                    icon = Icons.Default.Storage,
                    title = "Used Storage",
                    value = "${String.format("%.1f", totalStorageUsed)} GB"
                )
                StorageStat(
                    icon = Icons.Default.CloudDownload,
                    title = "Available",
                    value = "${String.format("%.1f", availableStorage)} GB"
                )
                StorageStat(
                    icon = Icons.Default.Map,
                    title = "Downloaded",
                    value = "$downloadedRegions maps"
                )
            }
            
            val totalStorage = totalStorageUsed + availableStorage
            val usagePercentage = if (totalStorage > 0) totalStorageUsed / totalStorage else 0.0
            
            LinearProgressIndicator(
                progress = { usagePercentage.toFloat() },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun StorageStat(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun MapRegionCard(
    region: MapRegion,
    onDownload: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = region.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = region.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Size: ${String.format("%.1f", region.sizeMb)} MB",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                if (region.isDownloaded) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Downloaded",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = onDelete) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                } else {
                    IconButton(onClick = onDownload) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Download",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            
            // Download Progress
            if (region.downloadProgress > 0f && region.downloadProgress < 1f) {
                Column {
                    Text(
                        text = "Downloading... ${(region.downloadProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    LinearProgressIndicator(
                        progress = { region.downloadProgress },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}
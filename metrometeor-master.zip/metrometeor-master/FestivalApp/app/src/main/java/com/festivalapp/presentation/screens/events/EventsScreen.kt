package com.festivalapp.presentation.screens.events

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshContainer
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.festivalapp.data.model.EventCategory
import com.festivalapp.presentation.components.AppHeader
import com.festivalapp.presentation.components.EventCard
import com.festivalapp.presentation.components.EventCardData
import com.festivalapp.presentation.components.FilterChip
import com.festivalapp.presentation.components.FilterChipData
import com.festivalapp.presentation.components.FilterChipRow
import com.festivalapp.presentation.components.HeaderAction
import com.festivalapp.presentation.components.LoadingIndicator
import com.festivalapp.presentation.components.PrimaryButton
import com.festivalapp.presentation.components.SearchBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventsScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: EventsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    
    var isSearchActive by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    
    val listState = rememberLazyListState()
    val pullToRefreshState = rememberPullToRefreshState()
    
    if (pullToRefreshState.isRefreshing) {
        LaunchedEffect(true) {
            viewModel.refreshEvents()
            pullToRefreshState.endRefresh()
        }
    }
    
    Scaffold(
        topBar = {
            AppHeader(
                title = "Events",
                actions = {
                    HeaderAction(
                        icon = Icons.Default.Search,
                        contentDescription = "Search",
                        onClick = { isSearchActive = !isSearchActive }
                    )
                    
                    Box {
                        HeaderAction(
                            icon = Icons.Default.Sort,
                            contentDescription = "Sort",
                            onClick = { showSortMenu = true }
                        )
                        
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            SortOption.values().forEach { option ->
                                DropdownMenuItem(
                                    text = { 
                                        Text(
                                            text = option.displayName,
                                            fontWeight = if (option == sortOption) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        viewModel.onSortOptionChanged(option)
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }
                    
                    HeaderAction(
                        icon = Icons.Default.Settings,
                        contentDescription = "Settings",
                        onClick = { /* Handle settings */ }
                    )
                }
            )
        },
        modifier = modifier.nestedScroll(pullToRefreshState.nestedScrollConnection)
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Search bar
                AnimatedVisibility(
                    visible = isSearchActive,
                    enter = slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessHigh
                        )
                    ) + fadeIn(),
                    exit = slideOutVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessHigh
                        )
                    ) + fadeOut()
                ) {
                    SearchBar(
                        query = searchQuery,
                        onQueryChange = viewModel::onSearchQueryChange,
                        onSearch = { /* Handle search */ },
                        placeholder = "Search events...",
                        isActive = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    )
                }
                
                // Filter chips
                val filterChips = listOf(
                    FilterChipData("all", "All Events", selectedCategory == null)
                ) + EventCategory.values().map { category ->
                    FilterChipData(
                        id = category.name,
                        label = category.name.lowercase().replaceFirstChar { it.uppercase() },
                        isSelected = selectedCategory == category
                    )
                }
                
                FilterChipRow(
                    chips = filterChips,
                    onChipClick = { chip ->
                        val category = if (chip.id == "all") null else EventCategory.valueOf(chip.id)
                        viewModel.onCategorySelected(category)
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                
                // Events list
                when {
                    uiState.isLoading && uiState.events.isEmpty() -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            LoadingIndicator(size = 48.dp)
                        }
                    }
                    
                    uiState.error != null -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "Something went wrong",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    text = uiState.error ?: "Unknown error",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                PrimaryButton(
                                    text = "Retry",
                                    onClick = viewModel::onRetry
                                )
                            }
                        }
                    }
                    
                    uiState.events.isEmpty() -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = if (searchQuery.isNotEmpty() || selectedCategory != null) {
                                        "No events found"
                                    } else {
                                        "No events available"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (searchQuery.isNotEmpty() || selectedCategory != null) {
                                    Text(
                                        text = "Try adjusting your filters",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    
                    else -> {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(
                                items = uiState.events,
                                key = { event -> event.id }
                            ) { event ->
                                EventCard(
                                    event = EventCardData(
                                        id = event.id,
                                        title = event.title,
                                        subtitle = "${event.category.name} • ${
                                            event.location.venue ?: event.location.address
                                        }",
                                        distance = "2.1 km", // Calculate actual distance
                                        crowdLevel = when (event.crowdLevel) {
                                            com.festivalapp.data.model.CrowdLevel.LOW -> 
                                                com.festivalapp.presentation.components.CrowdLevel.LOW
                                            com.festivalapp.data.model.CrowdLevel.MEDIUM -> 
                                                com.festivalapp.presentation.components.CrowdLevel.MEDIUM
                                            com.festivalapp.data.model.CrowdLevel.HIGH -> 
                                                com.festivalapp.presentation.components.CrowdLevel.HIGH
                                            com.festivalapp.data.model.CrowdLevel.VERY_HIGH -> 
                                                com.festivalapp.presentation.components.CrowdLevel.VERY_HIGH
                                        },
                                        category = event.category.name,
                                        imageUrl = event.imageUrl
                                    ),
                                    onClick = { viewModel.onEventClick(event) },
                                    onSaveClick = { viewModel.onEventBookmark(event) },
                                    onShareClick = { viewModel.onEventShare(event) }
                                )
                            }
                        }
                    }
                }
            }
            
            PullToRefreshContainer(
                modifier = Modifier.align(Alignment.TopCenter),
                state = pullToRefreshState,
            )
        }
    }
}
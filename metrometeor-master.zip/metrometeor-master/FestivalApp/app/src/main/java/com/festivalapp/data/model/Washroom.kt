package com.festivalapp.data.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Location(
    @SerializedName("latitude")
    val latitude: Double,
    @SerializedName("longitude")
    val longitude: Double,
    @SerializedName("address")
    val address: String? = null
) : Parcelable

enum class WashroomType(val value: String) {
    @SerializedName("fixed")
    FIXED("fixed"),
    @SerializedName("mobile")
    MOBILE("mobile"),
    @SerializedName("pissoir")
    PISSOIR("pissoir")
}

enum class AccessibilityLevel(val value: String) {
    @SerializedName("wheelchair_accessible")
    WHEELCHAIR_ACCESSIBLE("wheelchair_accessible"),
    @SerializedName("not_wheelchair_accessible")
    NOT_WHEELCHAIR_ACCESSIBLE("not_wheelchair_accessible"),
    @SerializedName("partially_accessible")
    PARTIALLY_ACCESSIBLE("partially_accessible")
}

@Parcelize
data class WashroomModel(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("address")
    val address: String,
    @SerializedName("location")
    val location: Location,
    @SerializedName("washroom_type")
    val washroomType: WashroomType,
    @SerializedName("accessibility")
    val accessibility: AccessibilityLevel,
    @SerializedName("is_free")
    val isFree: Boolean,
    @SerializedName("is_open_24h")
    val isOpen24h: Boolean,
    @SerializedName("opening_hours")
    val openingHours: String? = null,
    @SerializedName("description")
    val description: String? = null,
    @SerializedName("contact_info")
    val contactInfo: String? = null,
    @SerializedName("district")
    val district: String? = null,
    @SerializedName("postal_code")
    val postalCode: String? = null,
    @SerializedName("distance_from_user")
    val distanceFromUser: Double? = null,
    @SerializedName("last_updated")
    val lastUpdated: String? = null
) : Parcelable

@Parcelize
data class WashroomSearchRequest(
    @SerializedName("location")
    val location: Location,
    @SerializedName("radius_meters")
    val radiusMeters: Int = 1000,
    @SerializedName("washroom_type")
    val washroomType: WashroomType? = null,
    @SerializedName("accessibility_required")
    val accessibilityRequired: Boolean = false,
    @SerializedName("free_only")
    val freeOnly: Boolean = false,
    @SerializedName("open_24h_only")
    val open24hOnly: Boolean = false
) : Parcelable

@Parcelize
data class WashroomResponse(
    @SerializedName("washrooms")
    val washrooms: List<WashroomModel>,
    @SerializedName("total_count")
    val totalCount: Int,
    @SerializedName("search_radius")
    val searchRadius: Int,
    @SerializedName("center_location")
    val centerLocation: Location,
    @SerializedName("filters_applied")
    val filtersApplied: Map<String, Any>
) : Parcelable

data class APIResponse<T>(
    @SerializedName("success")
    val success: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("data")
    val data: T? = null,
    @SerializedName("error")
    val error: String? = null
)
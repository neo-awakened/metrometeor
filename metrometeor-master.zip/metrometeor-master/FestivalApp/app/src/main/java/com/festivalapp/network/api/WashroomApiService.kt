package com.festivalapp.network.api

import com.festivalapp.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface WashroomApiService {
    
    @GET("washrooms/search")
    suspend fun searchWashrooms(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("radius") radius: Int = 1000,
        @Query("washroom_type") washroomType: String? = null,
        @Query("accessibility_required") accessibilityRequired: Boolean = false,
        @Query("free_only") freeOnly: Boolean = false,
        @Query("open_24h_only") open24hOnly: Boolean = false
    ): Response<WashroomResponse>
    
    @POST("washrooms/search")
    suspend fun searchWashroomsPost(
        @Body request: WashroomSearchRequest
    ): Response<WashroomResponse>
    
    @GET("washrooms/nearby")
    suspend fun getNearbyWashrooms(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("limit") limit: Int = 10
    ): Response<List<WashroomModel>>
    
    @GET("washrooms/{washroom_id}")
    suspend fun getWashroomDetails(
        @Path("washroom_id") washroomId: String
    ): Response<WashroomModel>
    
    @GET("washrooms/")
    suspend fun getAllWashrooms(
        @Query("washroom_type") washroomType: String? = null,
        @Query("accessibility_required") accessibilityRequired: Boolean = false,
        @Query("limit") limit: Int = 100,
        @Query("skip") skip: Int = 0
    ): Response<List<WashroomModel>>
    
    @GET("washrooms/stats/summary")
    suspend fun getWashroomStatistics(): Response<APIResponse<Map<String, Any>>>
    
    @GET("washrooms/types")
    suspend fun getWashroomTypes(): Response<List<String>>
    
    @GET("washrooms/districts/{district}/washrooms")
    suspend fun getWashroomsByDistrict(
        @Path("district") district: String,
        @Query("limit") limit: Int = 50
    ): Response<List<WashroomModel>>
    
    @GET("washrooms/accessibility/wheelchair")
    suspend fun getWheelchairAccessibleWashrooms(
        @Query("latitude") latitude: Double? = null,
        @Query("longitude") longitude: Double? = null,
        @Query("radius") radius: Int = 5000,
        @Query("limit") limit: Int = 20
    ): Response<List<WashroomModel>>
}
package com.festivalapp.presentation.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material3.BottomSheetScaffold
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberBottomSheetScaffoldState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.festivalapp.data.model.Event
import com.festivalapp.data.model.EventCategory
import com.festivalapp.data.model.Location
import com.festivalapp.presentation.components.EventCard
import com.festivalapp.presentation.components.EventCardData
import com.festivalapp.presentation.components.LoadingIndicator
import com.festivalapp.presentation.components.SearchBar
import com.festivalapp.presentation.components.StatusIndicator
import com.festivalapp.ui.theme.TrafficGreen
import com.festivalapp.ui.theme.TrafficOrange
import com.festivalapp.ui.theme.TrafficRed
import com.festivalapp.presentation.components.WashroomDetailSheet
import com.festivalapp.presentation.components.WashroomFilterSheet
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val showWashrooms by viewModel.showWashrooms.collectAsState()
    val washroomFilter by viewModel.washroomFilter.collectAsState()
    
    val scaffoldState = rememberBottomSheetScaffoldState()
    
    // State for washroom filter sheet
    var showWashroomFilter by remember { mutableStateOf(false) }
    val washroomFilterSheetState = rememberModalBottomSheetState()
    
    // State for washroom detail sheet
    val washroomDetailSheetState = rememberModalBottomSheetState()
    
    // Zurich center as default location
    val defaultLocation = LatLng(47.3769, 8.5417)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultLocation, 13f)
    }
    
    BottomSheetScaffold(
        scaffoldState = scaffoldState,
        sheetContent = {
            BottomSheetContent(
                events = uiState.events,
                isLoading = uiState.isLoading,
                onEventClick = { event ->
                    viewModel.onEventClick(event)
                },
                modifier = Modifier.fillMaxWidth()
            )
        },
        sheetPeekHeight = 120.dp,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Google Map
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(
                    mapType = MapType.NORMAL,
                    isMyLocationEnabled = false // We'll handle location manually
                ),
                uiSettings = MapUiSettings(
                    zoomControlsEnabled = false,
                    myLocationButtonEnabled = false,
                    mapToolbarEnabled = false
                ),
                onMapLoaded = {
                    viewModel.onMapReady()
                }
            ) {
                // Event markers
                uiState.events.forEach { event ->
                    val position = LatLng(event.location.latitude, event.location.longitude)
                    
                    Marker(
                        state = MarkerState(position = position),
                        title = event.title,
                        snippet = "${event.category.name} • ${event.location.venue ?: event.location.address}",
                        icon = BitmapDescriptorFactory.defaultMarker(
                            when (event.category) {
                                EventCategory.MUSIC -> BitmapDescriptorFactory.HUE_BLUE
                                EventCategory.FOOD -> BitmapDescriptorFactory.HUE_GREEN
                                EventCategory.ART -> BitmapDescriptorFactory.HUE_VIOLET
                                EventCategory.SPORTS -> BitmapDescriptorFactory.HUE_ORANGE
                                else -> BitmapDescriptorFactory.HUE_RED
                            }
                        ),
                        onClick = {
                            viewModel.onEventClick(event)
                            false
                        }
                    )
                }
                
                // Traffic markers
                uiState.trafficInfo.forEach { traffic ->
                    val position = LatLng(traffic.location.latitude, traffic.location.longitude)
                    
                    Marker(
                        state = MarkerState(position = position),
                        title = "Traffic Alert",
                        snippet = traffic.description,
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW)
                    )
                }
                
                // Washroom markers
                if (showWashrooms) {
                    uiState.washrooms.forEach { washroom ->
                        val position = LatLng(washroom.location.latitude, washroom.location.longitude)
                        
                        Marker(
                            state = MarkerState(position = position),
                            title = washroom.name,
                            snippet = "${washroom.washroomType.value} • ${if (washroom.isFree) "Free" else "Paid"} • ${washroom.address}",
                            icon = BitmapDescriptorFactory.defaultMarker(
                                when (washroom.washroomType) {
                                    com.festivalapp.data.model.WashroomType.FIXED -> BitmapDescriptorFactory.HUE_CYAN
                                    com.festivalapp.data.model.WashroomType.MOBILE -> BitmapDescriptorFactory.HUE_AZURE
                                    com.festivalapp.data.model.WashroomType.PISSOIR -> BitmapDescriptorFactory.HUE_BLUE
                                }
                            ),
                            onClick = {
                                viewModel.onWashroomSelected(washroom)
                                false
                            }
                        )
                    }
                }
            }
            
            // Top overlay with search and actions
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(16.dp),
                color = Color.Transparent
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // App header with logo and profile
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Festival App",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = viewModel::toggleWashroomVisibility,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (showWashrooms) MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                                    )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WaterDrop,
                                    contentDescription = "Toggle Washrooms",
                                    tint = if (showWashrooms) MaterialTheme.colorScheme.onPrimary
                                           else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            
                            // Filter button (only show when washrooms are visible)
                            AnimatedVisibility(
                                visible = showWashrooms,
                                enter = fadeIn() + slideInVertically(),
                                exit = fadeOut() + slideOutVertically()
                            ) {
                                IconButton(
                                    onClick = { showWashroomFilter = true },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterList,
                                        contentDescription = "Filter Washrooms",
                                        tint = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            
                            IconButton(
                                onClick = { /* Profile action */ },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "Profile",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    
                    // Search bar
                    SearchBar(
                        query = searchQuery,
                        onQueryChange = viewModel::onSearchQueryChange,
                        onSearch = { /* Handle search */ },
                        placeholder = "Search events & places",
                        isActive = isSearchActive,
                        onActiveChange = viewModel::onSearchActiveChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                    )
                    
                    // Quick stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Explore,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "${uiState.events.size} events nearby",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatusIndicator(
                                    color = if (uiState.trafficInfo.isEmpty()) TrafficGreen else TrafficYellow,
                                    text = "Traffic: ${if (uiState.trafficInfo.isEmpty()) "Light" else "Moderate"}"
                                )
                            }
                        }
                    }
                }
            }
            
            // Floating Action Button for location
            ExtendedFloatingActionButton(
                onClick = { /* Request location */ },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .padding(bottom = 120.dp), // Account for bottom sheet
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "My Location"
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("My Location")
            }
            
            // Loading overlay
            AnimatedVisibility(
                visible = uiState.isLoading,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingIndicator(size = 48.dp)
                }
            }
        }
    }
}

@Composable
private fun BottomSheetContent(
    events: List<Event>,
    isLoading: Boolean,
    onEventClick: (Event) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Handle bar
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .background(
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(2.dp)
                    )
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Title
            Text(
                text = "Nearby Events",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingIndicator()
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(events) { event ->
                        EventCard(
                            event = EventCardData(
                                id = event.id,
                                title = event.title,
                                subtitle = "${event.category.name} • ${event.location.venue ?: ""}",
                                distance = "2.1 km", // Calculate actual distance
                                crowdLevel = when (event.crowdLevel) {
                                    com.festivalapp.data.model.CrowdLevel.LOW -> com.festivalapp.presentation.components.CrowdLevel.LOW
                                    com.festivalapp.data.model.CrowdLevel.MEDIUM -> com.festivalapp.presentation.components.CrowdLevel.MEDIUM
                                    com.festivalapp.data.model.CrowdLevel.HIGH -> com.festivalapp.presentation.components.CrowdLevel.HIGH
                                    com.festivalapp.data.model.CrowdLevel.VERY_HIGH -> com.festivalapp.presentation.components.CrowdLevel.VERY_HIGH
                                },
                                category = event.category.name
                            ),
                            onClick = { onEventClick(event) },
                            onSaveClick = { /* Handle save */ },
                            onShareClick = { /* Handle share */ }
                        )
                    }
                }
            }
        }
    }
    
    // Washroom filter bottom sheet
    if (showWashroomFilter) {
        ModalBottomSheet(
            onDismissRequest = { showWashroomFilter = false },
            sheetState = washroomFilterSheetState,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            WashroomFilterSheet(
                filter = washroomFilter,
                onFilterChanged = { newFilter ->
                    viewModel.updateWashroomFilter(newFilter)
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
    
    // Washroom detail bottom sheet
    uiState.selectedWashroom?.let { selectedWashroom ->
        ModalBottomSheet(
            onDismissRequest = { viewModel.clearSelectedWashroom() },
            sheetState = washroomDetailSheetState,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            WashroomDetailSheet(
                washroom = selectedWashroom,
                onDirectionsClick = {
                    // Open Google Maps with directions
                    // This would typically use an Intent to open maps
                    viewModel.clearSelectedWashroom()
                },
                onDismiss = { viewModel.clearSelectedWashroom() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
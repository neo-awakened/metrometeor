package com.festivalapp.presentation.screens.sos

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.EmergencyInfo
import com.festivalapp.data.repository.SOSRepository
import com.festivalapp.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SOSUiState(
    val isLoading: Boolean = false,
    val emergencyInfo: EmergencyInfo? = null,
    val error: String? = null,
    val alertSent: Boolean = false
)

@HiltViewModel
class SOSViewModel @Inject constructor(
    private val sosRepository: SOSRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SOSUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadEmergencyInfo()
    }

    private fun loadEmergencyInfo() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            
            sosRepository.getEmergencyInfo()
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Failed to load emergency info: ${e.message}"
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _uiState.value = _uiState.value.copy(isLoading = true)
                        }
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                emergencyInfo = resource.data,
                                error = null
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                error = resource.message
                            )
                        }
                    }
                }
        }
    }

    fun sendEmergencyAlert() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                sosRepository.sendEmergencyAlert()
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to send emergency alert: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    alertSent = true
                                )
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to send emergency alert: ${e.message}"
                )
            }
        }
    }

    fun toggleLocationSharing(enabled: Boolean) {
        viewModelScope.launch {
            try {
                sosRepository.updateLocationSharing(enabled)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            error = "Failed to update location sharing: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                val updatedInfo = _uiState.value.emergencyInfo?.copy(
                                    locationSharingEnabled = enabled
                                )
                                _uiState.value = _uiState.value.copy(
                                    emergencyInfo = updatedInfo
                                )
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                // Handle loading if needed
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = "Failed to update location sharing: ${e.message}"
                )
            }
        }
    }

    fun addEmergencyContact() {
        // This would typically open a dialog or navigate to a form
        // For now, we'll just trigger a placeholder action
        viewModelScope.launch {
            // Implementation would depend on your UI flow
            // Could open a dialog, navigate to a new screen, etc.
        }
    }

    fun editContact(contactId: String) {
        // Similar to addEmergencyContact, this would open an edit form
        viewModelScope.launch {
            // Implementation depends on UI design
        }
    }

    fun deleteContact(contactId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                sosRepository.deleteEmergencyContact(contactId)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to delete contact: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(isLoading = false)
                                loadEmergencyInfo() // Reload to get updated list
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to delete contact: ${e.message}"
                )
            }
        }
    }

    fun callEmergencyServices(number: String) {
        // This would trigger an intent to call emergency services
        // Implementation would use Android's Intent.ACTION_CALL
        viewModelScope.launch {
            try {
                // In a real implementation, you would:
                // val intent = Intent(Intent.ACTION_CALL).apply {
                //     data = Uri.parse("tel:$number")
                // }
                // context.startActivity(intent)
                
                // For now, we'll just log this action
                println("Would call emergency number: $number")
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = "Failed to make emergency call: ${e.message}"
                )
            }
        }
    }

    fun callContact(phoneNumber: String) {
        // Similar to callEmergencyServices but for emergency contacts
        viewModelScope.launch {
            try {
                // Implementation would use Intent.ACTION_CALL
                println("Would call contact: $phoneNumber")
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = "Failed to call contact: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun resetAlertStatus() {
        _uiState.value = _uiState.value.copy(alertSent = false)
    }
}
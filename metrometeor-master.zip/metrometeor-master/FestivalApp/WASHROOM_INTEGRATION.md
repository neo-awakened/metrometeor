# Washroom Feature Integration - Testing Guide

## Overview
The Android app now includes full integration with the Python backend for washroom functionality. Users can view, filter, and get details about washrooms in Zurich on the map.

## Backend Setup Required

1. **Start the Python Backend:**
   ```bash
   cd zurich_mobility_app
   python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

2. **Verify Backend is Running:**
   - Visit: http://localhost:8000/docs
   - Test washroom endpoint: http://localhost:8000/api/v1/washrooms/

## Android App Features

### 1. **Washroom Map Toggle**
- Blue water drop icon in the top-right corner
- Tap to show/hide washrooms on the map
- Icon highlights when washrooms are visible

### 2. **Washroom Markers**
- Different colors for different types:
  - **Cyan**: Fixed washrooms
  - **Azure**: Mobile washrooms  
  - **Blue**: Pissoir
- Tap markers to see washroom details

### 3. **Washroom Filtering**
- Filter icon appears when washrooms are visible
- Filter by:
  - **Type**: Fixed, Mobile, Pissoir
  - **Accessibility**: Wheelchair accessible
  - **Cost**: Free only
  - **Hours**: 24-hour availability
  - **Radius**: 100m to 5km search radius

### 4. **Washroom Details**
- Tap any washroom marker to see details:
  - Name and address
  - Distance from user
  - Type and features (free, 24h)
  - Accessibility information
  - Opening hours
  - Contact information
  - Directions button

## API Integration Details

### **WashroomApiService**
- GET `/washrooms/search` - Search with query parameters
- POST `/washrooms/search` - Advanced search with filters
- GET `/washrooms/nearby` - Quick nearby search
- GET `/washrooms/{id}` - Get specific washroom details

### **Data Models**
- `WashroomModel` - Complete washroom information
- `WashroomType` - FIXED, MOBILE, PISSOIR
- `AccessibilityLevel` - Wheelchair accessibility levels
- `WashroomFilter` - Filter criteria for searches

### **Repository Pattern**
- `WashroomRepository` - Handles API calls and caching
- 5-minute cache validity for performance
- Error handling for network issues
- Distance calculations using Haversine formula

## Testing Scenarios

### **Basic Functionality**
1. Launch app and grant location permission
2. Tap washroom toggle (water drop icon)
3. Verify washroom markers appear on map
4. Tap filter icon and adjust filters
5. Tap washroom marker to see details

### **Network Testing**
1. Test with backend running
2. Test with backend offline (error handling)
3. Test with slow network (loading states)
4. Test filter changes (real-time updates)

### **Location Testing**
1. Test with precise location
2. Test with approximate location
3. Test different radius settings
4. Verify distance calculations

## Configuration

### **Backend URL**
Current setting in `NetworkModule.kt`:
- **Emulator**: `http://10.0.2.2:8000/api/v1/`
- **Device**: Update to your local IP
- **Production**: Update to production URL

### **Permissions Required**
- Internet access ✅
- Location access ✅
- Network state ✅

## Troubleshooting

### **No Washrooms Visible**
- Check backend is running on correct port
- Verify network connectivity
- Check location permissions granted
- Ensure washroom toggle is enabled

### **API Errors**
- Check backend logs for errors
- Verify API endpoint URLs
- Check network configuration
- Validate request/response formats

### **Performance Issues**
- Repository includes caching (5min)
- Limit search radius for better performance
- Backend pagination supported

## Architecture Benefits

1. **Clean Architecture**: Repository pattern with dependency injection
2. **Reactive UI**: StateFlow and Compose for real-time updates  
3. **Error Handling**: Comprehensive error states and user feedback
4. **Caching**: Smart caching to reduce API calls
5. **Filtering**: Client-side and server-side filtering options
6. **Animations**: Smooth transitions and loading states

## Next Steps

1. **Real Device Testing**: Test with actual device and network
2. **Performance Optimization**: Monitor API response times
3. **Offline Support**: Add local database for offline functionality
4. **User Preferences**: Save filter preferences
5. **Analytics**: Track washroom usage patterns

The washroom feature is now fully integrated and ready for testing with the Python backend!
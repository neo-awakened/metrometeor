package com.festivalapp.presentation.screens.traffic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.festivalapp.data.model.*
import com.festivalapp.presentation.components.LoadingIndicator
import com.festivalapp.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrafficScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: TrafficViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedRoute by viewModel.selectedRoute.collectAsState()
    val destination by viewModel.destination.collectAsState()
    
    var showRouteSearch by remember { mutableStateOf(false) }
    var showDisruptions by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Traffic Insights",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshData() }
                    ) {
                        val rotation by animateFloatAsState(
                            targetValue = if (uiState.isLoading) 360f else 0f,
                            label = "refresh_rotation"
                        )
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            modifier = Modifier.rotate(rotation)
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Quick Stats Bar
            item {
                TrafficStatsCard(
                    trafficData = uiState.trafficData,
                    disruptionsCount = uiState.activeDisruptions.size
                )
            }
            
            // Route Search Section
            item {
                RouteSearchCard(
                    destination = destination,
                    onDestinationChange = viewModel::updateDestination,
                    onSearchRoutes = { 
                        uiState.userLocation?.let { userLoc ->
                            // For demo, create a sample destination location
                            val destLocation = Location(
                                latitude = 47.3769 + 0.01, // Slightly offset from Zurich center
                                longitude = 8.5417 + 0.01,
                                address = destination
                            )
                            viewModel.searchRoutes(userLoc, destLocation)
                        }
                    },
                    onSwapLocations = viewModel::swapLocations,
                    isSearching = uiState.isSearchingRoutes
                )
            }
            
            // Route Options
            if (uiState.routeOptions.isNotEmpty()) {
                item {
                    Text(
                        text = "Route Options",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                items(uiState.routeOptions) { route ->
                    RouteOptionCard(
                        route = route,
                        isSelected = selectedRoute?.routeId == route.routeId,
                        onClick = { viewModel.selectRoute(route) }
                    )
                }
            }
            
            // Traffic Disruptions
            if (uiState.activeDisruptions.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active Disruptions (${uiState.activeDisruptions.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        
                        TextButton(
                            onClick = { showDisruptions = !showDisruptions }
                        ) {
                            Text(if (showDisruptions) "Hide" else "Show")
                            Icon(
                                imageVector = if (showDisruptions) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }
                    }
                }
                
                if (showDisruptions) {
                    items(uiState.activeDisruptions) { disruption ->
                        DisruptionCard(disruption = disruption)
                    }
                }
            }
            
            // Loading State
            if (uiState.isLoading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        LoadingIndicator()
                    }
                }
            }
            
            // Error State
            uiState.error?.let { error ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Text(
                                text = error,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = viewModel::clearError) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrafficStatsCard(
    trafficData: TrafficData?,
    disruptionsCount: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Current Traffic
            StatItem(
                icon = Icons.Default.Traffic,
                title = "Current Traffic",
                value = trafficData?.currentConditions?.value?.uppercase() ?: "Unknown",
                color = when (trafficData?.currentConditions) {
                    TrafficLevel.LOW -> TrafficGreen
                    TrafficLevel.MODERATE -> TrafficYellow
                    TrafficLevel.HIGH -> TrafficOrange
                    TrafficLevel.SEVERE -> TrafficRed
                    else -> MaterialTheme.colorScheme.onSurface
                }
            )
            
            // Average Delay
            StatItem(
                icon = Icons.Default.AccessTime,
                title = "Avg Delay",
                value = if (trafficData != null) "+${trafficData.averageDelayMinutes} min" else "N/A",
                color = if ((trafficData?.averageDelayMinutes ?: 0) > 10) TrafficOrange else TrafficGreen
            )
            
            // Road Closures
            StatItem(
                icon = Icons.Default.Warning,
                title = "Disruptions",
                value = "$disruptionsCount active",
                color = if (disruptionsCount > 0) TrafficRed else TrafficGreen
            )
        }
    }
}

@Composable
private fun StatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RouteSearchCard(
    destination: String,
    onDestinationChange: (String) -> Unit,
    onSearchRoutes: () -> Unit,
    onSwapLocations: () -> Unit,
    isSearching: Boolean,
    modifier: Modifier = Modifier
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Route Planning",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            // From location (current location)
            OutlinedTextField(
                value = "Current Location",
                onValueChange = { },
                label = { Text("From") },
                leadingIcon = {
                    Icon(Icons.Default.MyLocation, contentDescription = null)
                },
                readOnly = true,
                modifier = Modifier.fillMaxWidth()
            )
            
            // Swap button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                IconButton(
                    onClick = onSwapLocations,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapVert,
                        contentDescription = "Swap locations",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            
            // To location (destination)
            OutlinedTextField(
                value = destination,
                onValueChange = onDestinationChange,
                label = { Text("To") },
                leadingIcon = {
                    Icon(Icons.Default.LocationOn, contentDescription = null)
                },
                placeholder = { Text("Enter destination...") },
                modifier = Modifier.fillMaxWidth()
            )
            
            // Search button
            Button(
                onClick = onSearchRoutes,
                enabled = destination.isNotEmpty() && !isSearching,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isSearching) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Find Routes")
            }
        }
    }
}

@Composable
private fun RouteOptionCard(
    route: RouteOption,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                MaterialTheme.colorScheme.primaryContainer 
            else 
                MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected) 
            androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) 
        else null
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = route.description,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                
                TrafficLevelChip(level = route.trafficLevel)
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                RouteMetric(
                    icon = Icons.Default.Schedule,
                    label = "Duration",
                    value = "${route.durationMinutes} min"
                )
                
                RouteMetric(
                    icon = Icons.Default.Straighten,
                    label = "Distance", 
                    value = "${String.format("%.1f", route.distanceKm)} km"
                )
                
                route.estimatedCost?.let { cost ->
                    RouteMetric(
                        icon = Icons.Default.AttachMoney,
                        label = "Cost",
                        value = "$${String.format("%.2f", cost)}"
                    )
                }
            }
        }
    }
}

@Composable
private fun TrafficLevelChip(
    level: TrafficLevel,
    modifier: Modifier = Modifier
) {
    val color = when (level) {
        TrafficLevel.LOW -> TrafficGreen
        TrafficLevel.MODERATE -> TrafficYellow
        TrafficLevel.HIGH -> TrafficOrange
        TrafficLevel.SEVERE -> TrafficRed
    }
    
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.2f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = level.value.uppercase(),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun RouteMetric(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun DisruptionCard(
    disruption: Disruption,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = disruption.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            
            Text(
                text = disruption.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            
            if (disruption.affectedRoutes.isNotEmpty()) {
                Text(
                    text = "Affected routes: ${disruption.affectedRoutes.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                )
            }
        }
    }
}
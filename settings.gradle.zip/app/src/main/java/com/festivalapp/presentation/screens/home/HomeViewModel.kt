package com.festivalapp.presentation.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.Event
import com.festivalapp.data.model.Location
import com.festivalapp.data.model.TrafficInfo
import com.festivalapp.data.model.WashroomModel
import com.festivalapp.data.model.WashroomType
import com.festivalapp.data.model.AccessibilityLevel
import com.festivalapp.data.repository.SampleDataRepository
import com.festivalapp.data.repository.WashroomRepository
import com.festivalapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: SampleDataRepository,
    private val washroomRepository: WashroomRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()
    
    // Washroom-related state
    private val _showWashrooms = MutableStateFlow(false)
    val showWashrooms: StateFlow<Boolean> = _showWashrooms.asStateFlow()
    
    private val _washroomFilter = MutableStateFlow(WashroomFilter())
    val washroomFilter: StateFlow<WashroomFilter> = _washroomFilter.asStateFlow()
    
    init {
        loadData()
    }
    
    private fun loadData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                // Load events
                repository.getEvents()
                    .catch { e -> 
                        _uiState.value = _uiState.value.copy(
                            error = e.message,
                            isLoading = false
                        )
                    }
                    .collect { events ->
                        _uiState.value = _uiState.value.copy(
                            events = events,
                            isLoading = false,
                            error = null
                        )
                    }
                
                // Load traffic info
                repository.getTrafficInfo()
                    .catch { e -> 
                        // Traffic info errors are not critical for the home screen
                        println("Traffic info error: ${e.message}")
                    }
                    .collect { trafficInfo ->
                        _uiState.value = _uiState.value.copy(
                            trafficInfo = trafficInfo
                        )
                    }
                    
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = e.message ?: "Unknown error occurred",
                    isLoading = false
                )
            }
        }
    }
    
    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        if (query.isEmpty()) {
            loadData()
        } else {
            filterEvents(query)
        }
    }
    
    fun onSearchActiveChange(isActive: Boolean) {
        _isSearchActive.value = isActive
        if (!isActive) {
            _searchQuery.value = ""
            loadData()
        }
    }
    
    private fun filterEvents(query: String) {
        val currentEvents = _uiState.value.events
        val filteredEvents = currentEvents.filter { event ->
            event.title.contains(query, ignoreCase = true) ||
            event.description.contains(query, ignoreCase = true) ||
            event.category.name.contains(query, ignoreCase = true) ||
            event.tags.any { it.contains(query, ignoreCase = true) }
        }
        
        _uiState.value = _uiState.value.copy(events = filteredEvents)
    }
    
    fun onEventClick(event: Event) {
        // Handle event click - navigate to event details
        // This will be implemented when navigation is set up
    }
    
    fun onLocationPermissionGranted(location: Location) {
        _uiState.value = _uiState.value.copy(userLocation = location)
        loadNearbyEvents(location)
    }
    
    private fun loadNearbyEvents(location: Location) {
        viewModelScope.launch {
            repository.getEventsNearLocation(location, 10.0) // 10km radius
                .catch { e -> 
                    println("Nearby events error: ${e.message}")
                }
                .collect { nearbyEvents ->
                    _uiState.value = _uiState.value.copy(
                        nearbyEvents = nearbyEvents
                    )
                }
        }
    }
    
    fun refreshData() {
        loadData()
    }
    
    fun onMapReady() {
        _uiState.value = _uiState.value.copy(isMapReady = true)
    }
    
    fun onBottomSheetStateChange(isExpanded: Boolean) {
        _uiState.value = _uiState.value.copy(isBottomSheetExpanded = isExpanded)
    }
    
    // Washroom functionality
    fun toggleWashroomVisibility() {
        val newVisibility = !_showWashrooms.value
        _showWashrooms.value = newVisibility
        
        if (newVisibility) {
            loadWashrooms()
        } else {
            _uiState.value = _uiState.value.copy(washrooms = emptyList())
        }
    }
    
    fun updateWashroomFilter(filter: WashroomFilter) {
        _washroomFilter.value = filter
        if (_showWashrooms.value) {
            loadWashrooms()
        }
    }
    
    private fun loadWashrooms() {
        val userLocation = _uiState.value.userLocation
        if (userLocation == null) {
            _uiState.value = _uiState.value.copy(
                error = "Location required to show washrooms"
            )
            return
        }
        
        viewModelScope.launch {
            val filter = _washroomFilter.value
            
            washroomRepository.searchWashrooms(
                latitude = userLocation.latitude,
                longitude = userLocation.longitude,
                radius = filter.radiusMeters,
                washroomType = filter.type,
                accessibilityRequired = filter.accessibilityRequired,
                freeOnly = filter.freeOnly,
                open24hOnly = filter.open24hOnly
            ).catch { e ->
                _uiState.value = _uiState.value.copy(
                    error = "Failed to load washrooms: ${e.message}",
                    isWashroomsLoading = false
                )
            }.collect { resource ->
                when (resource) {
                    is Resource.Loading -> {
                        _uiState.value = _uiState.value.copy(isWashroomsLoading = true)
                    }
                    is Resource.Success -> {
                        _uiState.value = _uiState.value.copy(
                            washrooms = resource.data?.washrooms ?: emptyList(),
                            isWashroomsLoading = false,
                            error = null
                        )
                    }
                    is Resource.Error -> {
                        _uiState.value = _uiState.value.copy(
                            error = resource.message ?: "Failed to load washrooms",
                            isWashroomsLoading = false
                        )
                    }
                }
            }
        }
    }
    
    fun onWashroomSelected(washroom: WashroomModel) {
        _uiState.value = _uiState.value.copy(selectedWashroom = washroom)
    }
    
    fun clearSelectedWashroom() {
        _uiState.value = _uiState.value.copy(selectedWashroom = null)
    }
    
    fun refreshWashrooms() {
        if (_showWashrooms.value) {
            loadWashrooms()
        }
    }
}

data class HomeUiState(
    val isLoading: Boolean = false,
    val events: List<Event> = emptyList(),
    val nearbyEvents: List<Event> = emptyList(),
    val trafficInfo: List<TrafficInfo> = emptyList(),
    val userLocation: Location? = null,
    val isMapReady: Boolean = false,
    val isBottomSheetExpanded: Boolean = false,
    val washrooms: List<WashroomModel> = emptyList(),
    val isWashroomsLoading: Boolean = false,
    val selectedWashroom: WashroomModel? = null,
    val error: String? = null
)

data class WashroomFilter(
    val type: WashroomType? = null,
    val accessibilityRequired: Boolean = false,
    val freeOnly: Boolean = false,
    val open24hOnly: Boolean = false,
    val radiusMeters: Int = 1000
)
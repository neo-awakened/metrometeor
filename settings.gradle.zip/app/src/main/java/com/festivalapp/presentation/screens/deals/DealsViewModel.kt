package com.festivalapp.presentation.screens.deals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.*
import com.festivalapp.data.repository.DealsRepository
import com.festivalapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DealsViewModel @Inject constructor(
    private val repository: DealsRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(DealsUiState())
    val uiState: StateFlow<DealsUiState> = _uiState.asStateFlow()
    
    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()
    
    private val _sortBy = MutableStateFlow("discount_percentage")
    val sortBy: StateFlow<String> = _sortBy.asStateFlow()
    
    private val _showFavoritesOnly = MutableStateFlow(false)
    val showFavoritesOnly: StateFlow<Boolean> = _showFavoritesOnly.asStateFlow()
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _favoriteDeals = MutableStateFlow<Set<String>>(emptySet())
    val favoriteDeals: StateFlow<Set<String>> = _favoriteDeals.asStateFlow()
    
    init {
        loadInitialData()
    }
    
    private fun loadInitialData() {
        loadDeals()
        loadCategories()
        loadFavorites()
    }
    
    private fun loadDeals() {
        viewModelScope.launch {
            val category = if (_showFavoritesOnly.value) null else _selectedCategory.value
            
            repository.getDeals(
                category = category,
                sortBy = _sortBy.value
            ).catch { e ->
                _uiState.value = _uiState.value.copy(
                    error = "Failed to load deals: ${e.message}",
                    isLoading = false
                )
            }.collect { resource ->
                when (resource) {
                    is Resource.Loading -> {
                        _uiState.value = _uiState.value.copy(isLoading = true)
                    }
                    is Resource.Success -> {
                        val deals = resource.data?.deals ?: emptyList()
                        val filteredDeals = if (_showFavoritesOnly.value) {
                            deals.filter { it.id in _favoriteDeals.value }
                        } else {
                            deals
                        }
                        
                        val searchFilteredDeals = if (_searchQuery.value.isNotEmpty()) {
                            filteredDeals.filter { deal ->
                                deal.title.contains(_searchQuery.value, ignoreCase = true) ||
                                deal.description.contains(_searchQuery.value, ignoreCase = true) ||
                                deal.vendor.contains(_searchQuery.value, ignoreCase = true) ||
                                deal.category.contains(_searchQuery.value, ignoreCase = true)
                            }
                        } else {
                            filteredDeals
                        }
                        
                        _uiState.value = _uiState.value.copy(
                            deals = searchFilteredDeals,
                            totalSavings = resource.data?.totalSavings ?: 0.0,
                            personalizedRecommendations = resource.data?.personalizedRecommendations ?: emptyList(),
                            isLoading = false,
                            error = null
                        )
                    }
                    is Resource.Error -> {
                        _uiState.value = _uiState.value.copy(
                            error = resource.message ?: "Failed to load deals",
                            isLoading = false
                        )
                    }
                }
            }
        }
    }
    
    private fun loadCategories() {
        viewModelScope.launch {
            repository.getDealCategories()
                .catch { e ->
                    println("Failed to load categories: ${e.message}")
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                categories = resource.data ?: emptyList()
                            )
                        }
                        is Resource.Error -> {
                            println("Categories error: ${resource.message}")
                        }
                        is Resource.Loading -> { /* No action needed */ }
                    }
                }
        }
    }
    
    private fun loadFavorites() {
        viewModelScope.launch {
            repository.getFavoriteDeals()
                .catch { e ->
                    println("Failed to load favorites: ${e.message}")
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Success -> {
                            val favoriteIds = resource.data?.map { it.id }?.toSet() ?: emptySet()
                            _favoriteDeals.value = favoriteIds
                        }
                        is Resource.Error -> {
                            println("Favorites error: ${resource.message}")
                        }
                        is Resource.Loading -> { /* No action needed */ }
                    }
                }
        }
    }
    
    fun selectCategory(category: String?) {
        _selectedCategory.value = category
        loadDeals()
    }
    
    fun updateSortBy(sortBy: String) {
        _sortBy.value = sortBy
        loadDeals()
    }
    
    fun toggleFavoritesOnly() {
        _showFavoritesOnly.value = !_showFavoritesOnly.value
        loadDeals()
    }
    
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        loadDeals()
    }
    
    fun toggleFavorite(dealId: String) {
        val currentFavorites = _favoriteDeals.value
        val isCurrentlyFavorite = dealId in currentFavorites
        
        viewModelScope.launch {
            try {
                if (isCurrentlyFavorite) {
                    repository.removeFromFavorites(dealId).collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _favoriteDeals.value = currentFavorites - dealId
                                if (_showFavoritesOnly.value) {
                                    loadDeals() // Refresh to remove from list
                                }
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    error = "Failed to remove from favorites"
                                )
                            }
                            is Resource.Loading -> { /* No action needed */ }
                        }
                    }
                } else {
                    repository.addToFavorites(dealId).collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _favoriteDeals.value = currentFavorites + dealId
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    error = "Failed to add to favorites"
                                )
                            }
                            is Resource.Loading -> { /* No action needed */ }
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = "Failed to update favorites: ${e.message}"
                )
            }
        }
    }
    
    fun getDealDetails(dealId: String) {
        viewModelScope.launch {
            repository.getDealDetails(dealId)
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        error = "Failed to load deal details: ${e.message}"
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                selectedDeal = resource.data
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                error = resource.message ?: "Failed to load deal details"
                            )
                        }
                        is Resource.Loading -> { /* No action needed */ }
                    }
                }
        }
    }
    
    fun clearSelectedDeal() {
        _uiState.value = _uiState.value.copy(selectedDeal = null)
    }
    
    fun refreshDeals() {
        repository.clearCache()
        loadInitialData()
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
    
    fun isFavorite(dealId: String): Boolean {
        return dealId in _favoriteDeals.value
    }
}

data class DealsUiState(
    val isLoading: Boolean = false,
    val deals: List<Deal> = emptyList(),
    val categories: List<String> = emptyList(),
    val totalSavings: Double = 0.0,
    val personalizedRecommendations: List<Deal> = emptyList(),
    val selectedDeal: Deal? = null,
    val error: String? = null
)
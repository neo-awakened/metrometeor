package com.festivalapp.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector? = null
) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Events : Screen("events", "Events", Icons.Default.CalendarToday)
    object Traffic : Screen("traffic", "Traffic", Icons.Default.DirectionsCar)
    object Planner : Screen("planner", "Planner", Icons.Default.Group)
    object More : Screen("more", "More", Icons.Default.Menu)
    
    // Secondary screens accessible from More
    object SOS : Screen("sos", "SOS Settings")
    object OfflineMaps : Screen("offline_maps", "Offline Maps")
    object Deals : Screen("deals", "Deals & Tickets")
    object Settings : Screen("settings", "Settings")
    object Profile : Screen("profile", "Profile")
    
    // Detail screens
    object EventDetail : Screen("event_detail/{eventId}", "Event Details") {
        fun createRoute(eventId: String) = "event_detail/$eventId"
    }
    object GroupDetail : Screen("group_detail/{groupId}", "Group Details") {
        fun createRoute(groupId: String) = "group_detail/$groupId"
    }
    object DealDetail : Screen("deal_detail/{dealId}", "Deal Details") {
        fun createRoute(dealId: String) = "deal_detail/$dealId"
    }
}

val bottomNavigationItems = listOf(
    Screen.Home,
    Screen.Events,
    Screen.Traffic,
    Screen.Planner,
    Screen.More
)
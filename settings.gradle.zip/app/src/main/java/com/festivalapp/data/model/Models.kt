package com.festivalapp.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Event(
    val id: String,
    val title: String,
    val description: String,
    val category: EventCategory,
    val location: Location,
    val startTime: Long,
    val endTime: Long,
    val imageUrl: String? = null,
    val crowdLevel: CrowdLevel = CrowdLevel.LOW,
    val ticketPrice: Double? = null,
    val isBookmarked: Boolean = false,
    val organizer: String,
    val tags: List<String> = emptyList()
) : Parcelable

@Parcelize
data class Location(
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val venue: String? = null
) : Parcelable

enum class EventCategory {
    MUSIC, FOOD, ART, SPORTS, ENTERTAINMENT, CULTURE, WORKSHOP, FESTIVAL
}

enum class CrowdLevel {
    LOW, MEDIUM, HIGH, VERY_HIGH
}

enum class TrafficLevel {
    LIGHT, MODERATE, HEAVY, SEVERE
}

@Parcelize
data class TrafficInfo(
    val id: String,
    val location: Location,
    val level: TrafficLevel,
    val description: String,
    val estimatedDelay: Int, // in minutes
    val affectedRoutes: List<String> = emptyList(),
    val lastUpdated: Long
) : Parcelable

@Parcelize
data class Group(
    val id: String,
    val name: String,
    val description: String,
    val members: List<GroupMember>,
    val createdBy: String,
    val createdAt: Long,
    val isPublic: Boolean = false,
    val maxMembers: Int = 50,
    val plannedEvents: List<String> = emptyList() // Event IDs
) : Parcelable

@Parcelize
data class GroupMember(
    val id: String,
    val name: String,
    val avatarUrl: String? = null,
    val isOnline: Boolean = false,
    val lastSeen: Long? = null,
    val location: Location? = null,
    val role: GroupRole = GroupRole.MEMBER
) : Parcelable

enum class GroupRole {
    ADMIN, MODERATOR, MEMBER
}

@Parcelize
data class Deal(
    val id: String,
    val title: String,
    val description: String,
    val originalPrice: Double,
    val discountedPrice: Double,
    val discountPercentage: Int,
    val imageUrl: String? = null,
    val validUntil: Long,
    val category: DealCategory,
    val vendor: String,
    val location: Location? = null,
    val isGroupDeal: Boolean = false,
    val minGroupSize: Int = 1,
    val termsAndConditions: String = ""
) : Parcelable

enum class DealCategory {
    FOOD, ACCOMMODATION, TRANSPORTATION, ENTERTAINMENT, TICKETS, MERCHANDISE
}

@Parcelize
data class OfflineMapArea(
    val id: String,
    val name: String,
    val centerLocation: Location,
    val boundingBox: BoundingBox,
    val sizeInMB: Double,
    val isDownloaded: Boolean = false,
    val downloadProgress: Float = 0f,
    val lastUpdated: Long? = null
) : Parcelable

@Parcelize
data class BoundingBox(
    val northEast: Location,
    val southWest: Location
) : Parcelable
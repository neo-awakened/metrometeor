package com.festivalapp.data.repository

import com.festivalapp.data.api.PlannerApiService
import com.festivalapp.data.model.PlannerGroup
import com.festivalapp.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlannerRepository @Inject constructor(
    private val plannerApiService: PlannerApiService
) {

    fun getUserGroups(): Flow<Resource<List<PlannerGroup>>> = flow {
        try {
            emit(Resource.Loading())
            val groups = plannerApiService.getUserGroups()
            emit(Resource.Success(groups))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch groups"))
        }
    }

    fun getGroupDetails(groupId: String): Flow<Resource<PlannerGroup>> = flow {
        try {
            emit(Resource.Loading())
            val group = plannerApiService.getGroupDetails(groupId)
            emit(Resource.Success(group))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch group details"))
        }
    }

    fun createGroup(name: String, description: String?): Flow<Resource<PlannerGroup>> = flow {
        try {
            emit(Resource.Loading())
            val groupRequest = mapOf(
                "name" to name,
                "description" to (description ?: "")
            )
            val group = plannerApiService.createGroup(groupRequest)
            emit(Resource.Success(group))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to create group"))
        }
    }

    fun joinGroup(inviteCode: String): Flow<Resource<PlannerGroup>> = flow {
        try {
            emit(Resource.Loading())
            val joinRequest = mapOf("inviteCode" to inviteCode)
            val group = plannerApiService.joinGroup(joinRequest)
            emit(Resource.Success(group))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to join group"))
        }
    }

    fun leaveGroup(groupId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            plannerApiService.leaveGroup(groupId)
            emit(Resource.Success(true))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to leave group"))
        }
    }

    fun updateGroup(groupId: String, name: String, description: String?): Flow<Resource<PlannerGroup>> = flow {
        try {
            emit(Resource.Loading())
            val updateRequest = mapOf(
                "name" to name,
                "description" to (description ?: "")
            )
            val group = plannerApiService.updateGroup(groupId, updateRequest)
            emit(Resource.Success(group))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to update group"))
        }
    }

    fun addEventToGroup(groupId: String, eventId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val eventRequest = mapOf("eventId" to eventId)
            plannerApiService.addEventToGroup(groupId, eventRequest)
            emit(Resource.Success(true))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to add event to group"))
        }
    }

    fun removeEventFromGroup(groupId: String, eventId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            plannerApiService.removeEventFromGroup(groupId, eventId)
            emit(Resource.Success(true))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to remove event from group"))
        }
    }

    fun shareLocation(groupId: String, latitude: Double, longitude: Double): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val locationRequest = mapOf(
                "latitude" to latitude,
                "longitude" to longitude
            )
            plannerApiService.shareLocation(groupId, locationRequest)
            emit(Resource.Success(true))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to share location"))
        }
    }

    fun getGroupLocations(groupId: String): Flow<Resource<List<Map<String, Any>>>> = flow {
        try {
            emit(Resource.Loading())
            val locations = plannerApiService.getGroupLocations(groupId)
            emit(Resource.Success(locations))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch group locations"))
        }
    }
}
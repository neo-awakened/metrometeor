package com.festivalapp.data.repository

import com.festivalapp.data.api.HeatmapApiService
import com.festivalapp.data.model.MapData
import com.festivalapp.data.model.MapRegion
import com.festivalapp.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OfflineMapsRepository @Inject constructor(
    private val heatmapApiService: HeatmapApiService
) {

    fun getMapData(): Flow<Resource<MapData>> = flow {
        try {
            emit(Resource.Loading())
            val mapData = heatmapApiService.getMapData()
            emit(Resource.Success(mapData))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch map data"))
        }
    }

    fun getAvailableRegions(): Flow<Resource<List<MapRegion>>> = flow {
        try {
            emit(Resource.Loading())
            val regions = heatmapApiService.getAvailableRegions()
            emit(Resource.Success(regions))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch available regions"))
        }
    }

    fun downloadMap(regionId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = heatmapApiService.downloadMap(regionId)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to download map"))
        }
    }

    fun deleteMap(regionId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = heatmapApiService.deleteMap(regionId)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to delete map"))
        }
    }

    fun pauseDownload(regionId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = heatmapApiService.pauseDownload(regionId)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to pause download"))
        }
    }

    fun resumeDownload(regionId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = heatmapApiService.resumeDownload(regionId)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to resume download"))
        }
    }

    fun clearCache(): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = heatmapApiService.clearCache()
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to clear cache"))
        }
    }

    fun getDownloadProgress(regionId: String): Flow<Resource<Float>> = flow {
        try {
            emit(Resource.Loading())
            val progress = heatmapApiService.getDownloadProgress(regionId)
            emit(Resource.Success(progress["progress"] as? Float ?: 0f))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to get download progress"))
        }
    }

    suspend fun pauseDownload(regionId: String) {
        // Direct suspend function for immediate actions
        try {
            heatmapApiService.pauseDownload(regionId)
        } catch (e: Exception) {
            throw e
        }
    }
}
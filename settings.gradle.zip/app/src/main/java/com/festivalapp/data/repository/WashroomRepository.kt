package com.festivalapp.data.repository

import com.festivalapp.data.model.*
import com.festivalapp.network.api.WashroomApiService
import com.festivalapp.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WashroomRepository @Inject constructor(
    private val api: WashroomApiService
) {
    
    // Cache for washrooms to avoid unnecessary API calls
    private var cachedWashrooms: List<WashroomModel>? = null
    private var lastCacheTime: Long = 0
    private val cacheValidityDuration = 5 * 60 * 1000L // 5 minutes
    
    suspend fun searchWashrooms(
        latitude: Double,
        longitude: Double,
        radius: Int = 1000,
        washroomType: WashroomType? = null,
        accessibilityRequired: Boolean = false,
        freeOnly: Boolean = false,
        open24hOnly: Boolean = false
    ): Flow<Resource<WashroomResponse>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.searchWashrooms(
                latitude = latitude,
                longitude = longitude,
                radius = radius,
                washroomType = washroomType?.value,
                accessibilityRequired = accessibilityRequired,
                freeOnly = freeOnly,
                open24hOnly = open24hOnly
            )
            
            if (response.isSuccessful) {
                response.body()?.let { washroomResponse ->
                    emit(Resource.Success(washroomResponse))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun searchWashroomsAdvanced(
        request: WashroomSearchRequest
    ): Flow<Resource<WashroomResponse>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.searchWashroomsPost(request)
            
            if (response.isSuccessful) {
                response.body()?.let { washroomResponse ->
                    emit(Resource.Success(washroomResponse))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getNearbyWashrooms(
        latitude: Double,
        longitude: Double,
        limit: Int = 10
    ): Flow<Resource<List<WashroomModel>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getNearbyWashrooms(
                latitude = latitude,
                longitude = longitude,
                limit = limit
            )
            
            if (response.isSuccessful) {
                response.body()?.let { washrooms ->
                    emit(Resource.Success(washrooms))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getWashroomDetails(
        washroomId: String
    ): Flow<Resource<WashroomModel>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getWashroomDetails(washroomId)
            
            if (response.isSuccessful) {
                response.body()?.let { washroom ->
                    emit(Resource.Success(washroom))
                } ?: emit(Resource.Error("Washroom not found"))
            } else {
                when (response.code()) {
                    404 -> emit(Resource.Error("Washroom not found"))
                    else -> emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
                }
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getAllWashrooms(
        useCache: Boolean = true,
        washroomType: WashroomType? = null,
        accessibilityRequired: Boolean = false,
        limit: Int = 100,
        skip: Int = 0
    ): Flow<Resource<List<WashroomModel>>> = flow {
        try {
            emit(Resource.Loading())
            
            // Check cache first if enabled
            if (useCache && isCacheValid() && cachedWashrooms != null) {
                var filteredWashrooms = cachedWashrooms!!
                
                // Apply filters to cached data
                if (washroomType != null) {
                    filteredWashrooms = filteredWashrooms.filter { it.washroomType == washroomType }
                }
                
                if (accessibilityRequired) {
                    filteredWashrooms = filteredWashrooms.filter { 
                        it.accessibility == AccessibilityLevel.WHEELCHAIR_ACCESSIBLE 
                    }
                }
                
                // Apply pagination
                val paginatedWashrooms = filteredWashrooms.drop(skip).take(limit)
                emit(Resource.Success(paginatedWashrooms))
                return@flow
            }
            
            val response = api.getAllWashrooms(
                washroomType = washroomType?.value,
                accessibilityRequired = accessibilityRequired,
                limit = limit,
                skip = skip
            )
            
            if (response.isSuccessful) {
                response.body()?.let { washrooms ->
                    // Cache the results if it's a full fetch
                    if (skip == 0 && washroomType == null && !accessibilityRequired) {
                        cachedWashrooms = washrooms
                        lastCacheTime = System.currentTimeMillis()
                    }
                    emit(Resource.Success(washrooms))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getWheelchairAccessibleWashrooms(
        latitude: Double? = null,
        longitude: Double? = null,
        radius: Int = 5000,
        limit: Int = 20
    ): Flow<Resource<List<WashroomModel>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getWheelchairAccessibleWashrooms(
                latitude = latitude,
                longitude = longitude,
                radius = radius,
                limit = limit
            )
            
            if (response.isSuccessful) {
                response.body()?.let { washrooms ->
                    emit(Resource.Success(washrooms))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getWashroomTypes(): Flow<Resource<List<String>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getWashroomTypes()
            
            if (response.isSuccessful) {
                response.body()?.let { types ->
                    emit(Resource.Success(types))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    fun clearCache() {
        cachedWashrooms = null
        lastCacheTime = 0
    }
    
    private fun isCacheValid(): Boolean {
        return System.currentTimeMillis() - lastCacheTime < cacheValidityDuration
    }
    
    /**
     * Filter washrooms by distance from a given location
     */
    fun filterWashroomsByDistance(
        washrooms: List<WashroomModel>,
        userLatitude: Double,
        userLongitude: Double,
        maxDistanceKm: Double
    ): List<WashroomModel> {
        return washrooms.filter { washroom ->
            val distance = calculateDistance(
                userLatitude, userLongitude,
                washroom.location.latitude, washroom.location.longitude
            )
            distance <= maxDistanceKm
        }
    }
    
    /**
     * Calculate distance between two coordinates using Haversine formula
     */
    private fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val r = 6371 // Earth's radius in kilometers
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
                kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
                kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return r * c
    }
}
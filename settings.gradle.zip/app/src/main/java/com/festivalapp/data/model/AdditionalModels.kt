package com.festivalapp.data.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

// Traffic Models
enum class TrafficLevel(val value: String) {
    @SerializedName("low")
    LOW("low"),
    @SerializedName("moderate")
    MODERATE("moderate"),
    @SerializedName("high")
    HIGH("high"),
    @SerializedName("severe")
    SEVERE("severe")
}

@Parcelize
data class RouteOption(
    @SerializedName("route_id")
    val routeId: String,
    @SerializedName("duration_minutes")
    val durationMinutes: Int,
    @SerializedName("distance_km")
    val distanceKm: Double,
    @SerializedName("traffic_level")
    val trafficLevel: TrafficLevel,
    @SerializedName("description")
    val description: String,
    @SerializedName("waypoints")
    val waypoints: List<Location>,
    @SerializedName("estimated_cost")
    val estimatedCost: Double? = null
) : Parcelable

@Parcelize
data class Disruption(
    @SerializedName("id")
    val id: String,
    @SerializedName("title")
    val title: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("location")
    val location: Location,
    @SerializedName("severity")
    val severity: String,
    @SerializedName("start_time")
    val startTime: String,
    @SerializedName("end_time")
    val endTime: String? = null,
    @SerializedName("affected_routes")
    val affectedRoutes: List<String>
) : Parcelable

@Parcelize
data class TrafficData(
    @SerializedName("current_conditions")
    val currentConditions: TrafficLevel,
    @SerializedName("average_delay_minutes")
    val averageDelayMinutes: Int,
    @SerializedName("active_disruptions")
    val activeDisruptions: List<Disruption>,
    @SerializedName("route_suggestions")
    val routeSuggestions: List<RouteOption>,
    @SerializedName("last_updated")
    val lastUpdated: String
) : Parcelable

// Planner Models
@Parcelize
data class GroupMember(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("avatar_url")
    val avatarUrl: String? = null,
    @SerializedName("is_online")
    val isOnline: Boolean,
    @SerializedName("location")
    val location: Location? = null,
    @SerializedName("last_seen")
    val lastSeen: String? = null
) : Parcelable

@Parcelize
data class PlannerGroup(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("description")
    val description: String? = null,
    @SerializedName("created_by")
    val createdBy: String,
    @SerializedName("members")
    val members: List<GroupMember>,
    @SerializedName("events")
    val events: List<String>, // Event IDs
    @SerializedName("meeting_point")
    val meetingPoint: Location? = null,
    @SerializedName("is_location_sharing_enabled")
    val isLocationSharingEnabled: Boolean,
    @SerializedName("created_at")
    val createdAt: String
) : Parcelable

// SOS Models
@Parcelize
data class EmergencyContact(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("phone_number")
    val phoneNumber: String,
    @SerializedName("relationship")
    val relationship: String,
    @SerializedName("is_primary")
    val isPrimary: Boolean
) : Parcelable

@Parcelize
data class EmergencyInfo(
    @SerializedName("emergency_contacts")
    val emergencyContacts: List<EmergencyContact>,
    @SerializedName("medical_info")
    val medicalInfo: Map<String, String>? = null,
    @SerializedName("location_sharing_enabled")
    val locationSharingEnabled: Boolean,
    @SerializedName("emergency_services_number")
    val emergencyServicesNumber: String
) : Parcelable

// Deals Models
@Parcelize
data class Deal(
    @SerializedName("id")
    val id: String,
    @SerializedName("title")
    val title: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("original_price")
    val originalPrice: Double,
    @SerializedName("discounted_price")
    val discountedPrice: Double,
    @SerializedName("discount_percentage")
    val discountPercentage: Int,
    @SerializedName("category")
    val category: String,
    @SerializedName("valid_until")
    val validUntil: String,
    @SerializedName("vendor")
    val vendor: String,
    @SerializedName("image_url")
    val imageUrl: String? = null,
    @SerializedName("terms_conditions")
    val termsConditions: String? = null
) : Parcelable

@Parcelize
data class DealsResponse(
    @SerializedName("deals")
    val deals: List<Deal>,
    @SerializedName("categories")
    val categories: List<String>,
    @SerializedName("total_savings")
    val totalSavings: Double,
    @SerializedName("personalized_recommendations")
    val personalizedRecommendations: List<Deal>
) : Parcelable

// Offline Maps Models
@Parcelize
data class MapRegion(
    @SerializedName("id")
    val id: String,
    @SerializedName("name")
    val name: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("bounds")
    val bounds: MapBounds,
    @SerializedName("size_mb")
    val sizeMb: Double,
    @SerializedName("is_downloaded")
    val isDownloaded: Boolean = false,
    @SerializedName("download_progress")
    val downloadProgress: Float = 0f,
    @SerializedName("last_updated")
    val lastUpdated: String? = null
) : Parcelable

@Parcelize
data class MapBounds(
    @SerializedName("north")
    val north: Double,
    @SerializedName("south")
    val south: Double,
    @SerializedName("east")
    val east: Double,
    @SerializedName("west")
    val west: Double
) : Parcelable

@Parcelize
data class OfflineMapData(
    @SerializedName("available_regions")
    val availableRegions: List<MapRegion>,
    @SerializedName("downloaded_regions")
    val downloadedRegions: List<MapRegion>,
    @SerializedName("total_storage_used")
    val totalStorageUsed: Double,
    @SerializedName("available_storage")
    val availableStorage: Double
) : Parcelable

// Heatmap Models (extending existing)
@Parcelize
data class HeatmapPoint(
    @SerializedName("latitude")
    val latitude: Double,
    @SerializedName("longitude")
    val longitude: Double,
    @SerializedName("intensity")
    val intensity: Float, // 0.0 to 1.0
    @SerializedName("data_type")
    val dataType: String, // "crowd", "traffic", "events"
    @SerializedName("timestamp")
    val timestamp: String
) : Parcelable

@Parcelize
data class HeatmapRequest(
    @SerializedName("coordinates")
    val coordinates: List<Location>,
    @SerializedName("radius_meters")
    val radiusMeters: Int = 1000,
    @SerializedName("data_types")
    val dataTypes: List<String> = listOf("crowd", "traffic"),
    @SerializedName("start_time")
    val startTime: String? = null,
    @SerializedName("end_time")
    val endTime: String? = null
) : Parcelable

@Parcelize
data class HeatmapResponse(
    @SerializedName("points")
    val points: List<HeatmapPoint>,
    @SerializedName("bounds")
    val bounds: Map<String, Double>, // min_lat, max_lat, min_lng, max_lng
    @SerializedName("generated_at")
    val generatedAt: String,
    @SerializedName("data_sources")
    val dataSources: List<String>
) : Parcelable
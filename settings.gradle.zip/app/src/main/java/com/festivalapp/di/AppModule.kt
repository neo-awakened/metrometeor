package com.festivalapp.di

import com.festivalapp.data.repository.SampleDataRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    
    @Provides
    @Singleton
    fun provideSampleDataRepository(): SampleDataRepository {
        return SampleDataRepository()
    }
}
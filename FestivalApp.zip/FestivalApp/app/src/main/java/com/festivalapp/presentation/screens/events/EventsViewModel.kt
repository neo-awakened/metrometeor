package com.festivalapp.presentation.screens.events

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.Event
import com.festivalapp.data.model.EventCategory
import com.festivalapp.data.repository.SampleDataRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EventsViewModel @Inject constructor(
    private val repository: SampleDataRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(EventsUiState())
    val uiState: StateFlow<EventsUiState> = _uiState.asStateFlow()
    
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()
    
    private val _selectedCategory = MutableStateFlow<EventCategory?>(null)
    val selectedCategory: StateFlow<EventCategory?> = _selectedCategory.asStateFlow()
    
    private val _sortOption = MutableStateFlow(SortOption.DATE)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()
    
    private val allEvents = mutableListOf<Event>()
    
    init {
        loadEvents()
    }
    
    private fun loadEvents() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            repository.getEvents()
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        error = e.message,
                        isLoading = false
                    )
                }
                .collect { events ->
                    allEvents.clear()
                    allEvents.addAll(events)
                    
                    _uiState.value = _uiState.value.copy(
                        events = filterAndSortEvents(events),
                        isLoading = false,
                        error = null
                    )
                }
        }
    }
    
    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        updateFilteredEvents()
    }
    
    fun onCategorySelected(category: EventCategory?) {
        _selectedCategory.value = category
        updateFilteredEvents()
    }
    
    fun onSortOptionChanged(sortOption: SortOption) {
        _sortOption.value = sortOption
        updateFilteredEvents()
    }
    
    private fun updateFilteredEvents() {
        val filteredEvents = filterAndSortEvents(allEvents)
        _uiState.value = _uiState.value.copy(events = filteredEvents)
    }
    
    private fun filterAndSortEvents(events: List<Event>): List<Event> {
        var filteredEvents = events
        
        // Filter by search query
        val query = _searchQuery.value
        if (query.isNotEmpty()) {
            filteredEvents = filteredEvents.filter { event ->
                event.title.contains(query, ignoreCase = true) ||
                event.description.contains(query, ignoreCase = true) ||
                event.organizer.contains(query, ignoreCase = true) ||
                event.tags.any { it.contains(query, ignoreCase = true) }
            }
        }
        
        // Filter by category
        val category = _selectedCategory.value
        if (category != null) {
            filteredEvents = filteredEvents.filter { it.category == category }
        }
        
        // Sort events
        return when (_sortOption.value) {
            SortOption.DATE -> filteredEvents.sortedBy { it.startTime }
            SortOption.DISTANCE -> filteredEvents.sortedBy { it.location.address } // Simplified
            SortOption.POPULARITY -> filteredEvents.sortedByDescending { it.crowdLevel.ordinal }
            SortOption.PRICE -> filteredEvents.sortedBy { it.ticketPrice ?: 0.0 }
        }
    }
    
    fun onEventClick(event: Event) {
        // Navigate to event details
        // This will be implemented when navigation is fully set up
    }
    
    fun onEventBookmark(event: Event) {
        // Toggle bookmark status
        val updatedEvents = allEvents.map { 
            if (it.id == event.id) {
                it.copy(isBookmarked = !it.isBookmarked)
            } else {
                it
            }
        }
        
        allEvents.clear()
        allEvents.addAll(updatedEvents)
        updateFilteredEvents()
    }
    
    fun onEventShare(event: Event) {
        // Handle event sharing
        // Implementation depends on sharing requirements
    }
    
    fun refreshEvents() {
        loadEvents()
    }
    
    fun onRetry() {
        _uiState.value = _uiState.value.copy(error = null)
        loadEvents()
    }
}

data class EventsUiState(
    val isLoading: Boolean = false,
    val events: List<Event> = emptyList(),
    val error: String? = null
)

enum class SortOption(val displayName: String) {
    DATE("Date"),
    DISTANCE("Distance"),
    POPULARITY("Popularity"),
    PRICE("Price")
}
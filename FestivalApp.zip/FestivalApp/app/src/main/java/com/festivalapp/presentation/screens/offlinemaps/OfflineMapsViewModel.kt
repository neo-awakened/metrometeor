package com.festivalapp.presentation.screens.offlinemaps

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.MapData
import com.festivalapp.data.repository.OfflineMapsRepository
import com.festivalapp.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

data class OfflineMapsUiState(
    val isLoading: Boolean = false,
    val mapData: MapData? = null,
    val error: String? = null,
    val downloadingRegions: Set<String> = emptySet()
)

@HiltViewModel
class OfflineMapsViewModel @Inject constructor(
    private val offlineMapsRepository: OfflineMapsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(OfflineMapsUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadMapData()
    }

    private fun loadMapData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            
            offlineMapsRepository.getMapData()
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Failed to load map data: ${e.message}"
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _uiState.value = _uiState.value.copy(isLoading = true)
                        }
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                mapData = resource.data,
                                error = null
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                error = resource.message
                            )
                        }
                    }
                }
        }
    }

    fun refreshMaps() {
        loadMapData()
    }

    fun downloadMap(regionId: String) {
        viewModelScope.launch {
            // Add to downloading set
            _uiState.value = _uiState.value.copy(
                downloadingRegions = _uiState.value.downloadingRegions + regionId
            )
            
            try {
                offlineMapsRepository.downloadMap(regionId)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            downloadingRegions = _uiState.value.downloadingRegions - regionId,
                            error = "Failed to download map: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(
                                    downloadingRegions = _uiState.value.downloadingRegions - regionId
                                )
                                loadMapData() // Reload to get updated status
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    downloadingRegions = _uiState.value.downloadingRegions - regionId,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                // Keep in downloading state
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    downloadingRegions = _uiState.value.downloadingRegions - regionId,
                    error = "Failed to download map: ${e.message}"
                )
            }
        }
    }

    fun deleteMap(regionId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                offlineMapsRepository.deleteMap(regionId)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to delete map: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(isLoading = false)
                                loadMapData() // Reload to get updated status
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to delete map: ${e.message}"
                )
            }
        }
    }

    fun pauseDownload(regionId: String) {
        viewModelScope.launch {
            try {
                offlineMapsRepository.pauseDownload(regionId)
                _uiState.value = _uiState.value.copy(
                    downloadingRegions = _uiState.value.downloadingRegions - regionId
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    error = "Failed to pause download: ${e.message}"
                )
            }
        }
    }

    fun resumeDownload(regionId: String) {
        downloadMap(regionId) // Use the same logic as starting a new download
    }

    fun clearStorageCache() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                offlineMapsRepository.clearCache()
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to clear cache: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(isLoading = false)
                                loadMapData() // Reload to get updated storage info
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to clear cache: ${e.message}"
                )
            }
        }
    }

    fun isDownloading(regionId: String): Boolean {
        return _uiState.value.downloadingRegions.contains(regionId)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}
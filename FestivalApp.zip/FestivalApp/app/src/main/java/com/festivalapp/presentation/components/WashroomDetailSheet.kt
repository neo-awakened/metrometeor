package com.festivalapp.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.festivalapp.data.model.AccessibilityLevel
import com.festivalapp.data.model.WashroomModel
import com.festivalapp.data.model.WashroomType

@Composable
fun WashroomDetailSheet(
    washroom: WashroomModel,
    onDirectionsClick: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Handle bar
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .background(
                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(2.dp)
                    )
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Header with close button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = washroom.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Address
            Text(
                text = washroom.address,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            washroom.distanceFromUser?.let { distance ->
                Text(
                    text = "${String.format("%.1f", distance)} km away",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Type and features
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                WashroomTypeChip(
                    type = washroom.washroomType,
                    modifier = Modifier.weight(1f)
                )
                
                if (washroom.isFree) {
                    FeatureChip(
                        icon = Icons.Default.MoneyOff,
                        text = "Free",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                if (washroom.isOpen24h) {
                    FeatureChip(
                        icon = Icons.Default.Schedule,
                        text = "24h",
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Accessibility info
            AccessibilityInfo(accessibility = washroom.accessibility)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Opening hours
            washroom.openingHours?.let { hours ->
                DetailRow(
                    icon = Icons.Default.AccessTime,
                    title = "Opening Hours",
                    content = hours
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            // District info
            washroom.district?.let { district ->
                DetailRow(
                    icon = Icons.Default.LocationOn,
                    title = "District",
                    content = district
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            // Description
            washroom.description?.let { description ->
                DetailRow(
                    icon = Icons.Default.Info,
                    title = "Information",
                    content = description
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            // Contact info
            washroom.contactInfo?.let { contact ->
                DetailRow(
                    icon = Icons.Default.Phone,
                    title = "Contact",
                    content = contact
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            
            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { /* Share functionality */ },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share")
                }
                
                Button(
                    onClick = onDirectionsClick,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Directions,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Directions")
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun WashroomTypeChip(
    type: WashroomType,
    modifier: Modifier = Modifier
) {
    val (icon, text, color) = when (type) {
        WashroomType.FIXED -> Triple(Icons.Default.Business, "Fixed", MaterialTheme.colorScheme.primary)
        WashroomType.MOBILE -> Triple(Icons.Default.DirectionsBus, "Mobile", MaterialTheme.colorScheme.secondary)
        WashroomType.PISSOIR -> Triple(Icons.Default.Wc, "Pissoir", MaterialTheme.colorScheme.tertiary)
    }
    
    AssistChip(
        onClick = { },
        label = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = color
                )
                Text(text = text)
            }
        },
        modifier = modifier
    )
}

@Composable
private fun FeatureChip(
    icon: ImageVector,
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    AssistChip(
        onClick = { },
        label = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = color
                )
                Text(text = text)
            }
        },
        modifier = modifier
    )
}

@Composable
private fun AccessibilityInfo(
    accessibility: AccessibilityLevel,
    modifier: Modifier = Modifier
) {
    val (icon, text, color) = when (accessibility) {
        AccessibilityLevel.WHEELCHAIR_ACCESSIBLE -> 
            Triple(Icons.Default.Accessible, "Wheelchair Accessible", MaterialTheme.colorScheme.primary)
        AccessibilityLevel.NOT_WHEELCHAIR_ACCESSIBLE -> 
            Triple(Icons.Default.Block, "Not Wheelchair Accessible", MaterialTheme.colorScheme.error)
        AccessibilityLevel.PARTIALLY_ACCESSIBLE -> 
            Triple(Icons.Default.Warning, "Partially Accessible", MaterialTheme.colorScheme.tertiary)
    }
    
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = color,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun DetailRow(
    icon: ImageVector,
    title: String,
    content: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = content,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
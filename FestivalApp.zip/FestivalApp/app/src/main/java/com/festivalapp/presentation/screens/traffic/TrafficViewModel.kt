package com.festivalapp.presentation.screens.traffic

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.*
import com.festivalapp.data.repository.TrafficRepository
import com.festivalapp.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TrafficViewModel @Inject constructor(
    private val repository: TrafficRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(TrafficUiState())
    val uiState: StateFlow<TrafficUiState> = _uiState.asStateFlow()
    
    private val _selectedRoute = MutableStateFlow<RouteOption?>(null)
    val selectedRoute: StateFlow<RouteOption?> = _selectedRoute.asStateFlow()
    
    private val _destination = MutableStateFlow("")
    val destination: StateFlow<String> = _destination.asStateFlow()
    
    private val _departureTime = MutableStateFlow(System.currentTimeMillis())
    val departureTime: StateFlow<Long> = _departureTime.asStateFlow()
    
    init {
        loadInitialData()
    }
    
    private fun loadInitialData() {
        // Load traffic data for default location (Zurich center)
        loadTrafficData(47.3769, 8.5417) // Zurich coordinates
        loadActiveDisruptions()
    }
    
    fun loadTrafficData(latitude: Double, longitude: Double, radius: Int = 5000) {
        viewModelScope.launch {
            repository.getTrafficData(latitude, longitude, radius)
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        error = "Failed to load traffic data: ${e.message}",
                        isLoading = false
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _uiState.value = _uiState.value.copy(isLoading = true)
                        }
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                trafficData = resource.data,
                                isLoading = false,
                                error = null
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                error = resource.message ?: "Failed to load traffic data",
                                isLoading = false
                            )
                        }
                    }
                }
        }
    }
    
    fun loadActiveDisruptions(latitude: Double? = null, longitude: Double? = null) {
        viewModelScope.launch {
            repository.getActiveDisruptions(latitude, longitude)
                .catch { e ->
                    println("Failed to load disruptions: ${e.message}")
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                activeDisruptions = resource.data ?: emptyList()
                            )
                        }
                        is Resource.Error -> {
                            // Don't show error for disruptions as it's not critical
                            println("Disruptions error: ${resource.message}")
                        }
                        is Resource.Loading -> { /* No action needed */ }
                    }
                }
        }
    }
    
    fun searchRoutes(fromLocation: Location, toLocation: Location) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearchingRoutes = true)
            
            repository.getRouteOptions(fromLocation, toLocation)
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        error = "Failed to find routes: ${e.message}",
                        isSearchingRoutes = false
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _uiState.value = _uiState.value.copy(isSearchingRoutes = true)
                        }
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                routeOptions = resource.data ?: emptyList(),
                                isSearchingRoutes = false,
                                error = null
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                error = resource.message ?: "Failed to find routes",
                                isSearchingRoutes = false
                            )
                        }
                    }
                }
        }
    }
    
    fun selectRoute(route: RouteOption) {
        _selectedRoute.value = route
    }
    
    fun clearSelectedRoute() {
        _selectedRoute.value = null
    }
    
    fun updateDestination(destination: String) {
        _destination.value = destination
    }
    
    fun updateDepartureTime(timestamp: Long) {
        _departureTime.value = timestamp
    }
    
    fun refreshData() {
        loadInitialData()
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
    
    fun onLocationPermissionGranted(location: Location) {
        _uiState.value = _uiState.value.copy(userLocation = location)
        loadTrafficData(location.latitude, location.longitude)
        loadActiveDisruptions(location.latitude, location.longitude)
    }
    
    fun swapLocations() {
        val currentUserLocation = _uiState.value.userLocation
        val currentDestination = _destination.value
        
        // This would typically involve more complex logic to swap locations
        // For now, we'll just update the destination
        if (currentUserLocation != null && currentDestination.isNotEmpty()) {
            // Implement location swapping logic
        }
    }
}

data class TrafficUiState(
    val isLoading: Boolean = false,
    val isSearchingRoutes: Boolean = false,
    val trafficData: TrafficData? = null,
    val routeOptions: List<RouteOption> = emptyList(),
    val activeDisruptions: List<Disruption> = emptyList(),
    val userLocation: Location? = null,
    val error: String? = null
)
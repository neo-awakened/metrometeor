package com.festivalapp.data.repository

import com.festivalapp.data.model.*
import com.festivalapp.network.api.DealsApiService
import com.festivalapp.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DealsRepository @Inject constructor(
    private val api: DealsApiService
) {
    
    private var cachedDeals: List<Deal>? = null
    private var lastCacheTime: Long = 0
    private val cacheValidityDuration = 10 * 60 * 1000L // 10 minutes
    
    suspend fun getDeals(
        category: String? = null,
        limit: Int = 50,
        skip: Int = 0,
        sortBy: String = "discount_percentage",
        minDiscount: Int? = null,
        useCache: Boolean = true
    ): Flow<Resource<DealsResponse>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getDeals(category, limit, skip, sortBy, minDiscount)
            
            if (response.isSuccessful) {
                response.body()?.let { dealsResponse ->
                    // Cache the deals if it's a full fetch
                    if (skip == 0 && category == null) {
                        cachedDeals = dealsResponse.deals
                        lastCacheTime = System.currentTimeMillis()
                    }
                    emit(Resource.Success(dealsResponse))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getDealDetails(dealId: String): Flow<Resource<Deal>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getDealDetails(dealId)
            
            if (response.isSuccessful) {
                response.body()?.let { deal ->
                    emit(Resource.Success(deal))
                } ?: emit(Resource.Error("Deal not found"))
            } else {
                when (response.code()) {
                    404 -> emit(Resource.Error("Deal not found"))
                    else -> emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
                }
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getDealCategories(): Flow<Resource<List<String>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getDealCategories()
            
            if (response.isSuccessful) {
                response.body()?.let { categories ->
                    emit(Resource.Success(categories))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun addToFavorites(dealId: String): Flow<Resource<Unit>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.addToFavorites(dealId)
            
            if (response.isSuccessful) {
                emit(Resource.Success(Unit))
            } else {
                emit(Resource.Error("Failed to add to favorites"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun removeFromFavorites(dealId: String): Flow<Resource<Unit>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.removeFromFavorites(dealId)
            
            if (response.isSuccessful) {
                emit(Resource.Success(Unit))
            } else {
                emit(Resource.Error("Failed to remove from favorites"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    suspend fun getFavoriteDeals(): Flow<Resource<List<Deal>>> = flow {
        try {
            emit(Resource.Loading())
            
            val response = api.getFavoriteDeals()
            
            if (response.isSuccessful) {
                response.body()?.let { deals ->
                    emit(Resource.Success(deals))
                } ?: emit(Resource.Error("Empty response"))
            } else {
                emit(Resource.Error("HTTP ${response.code()}: ${response.message()}"))
            }
            
        } catch (e: HttpException) {
            emit(Resource.Error("Network error: ${e.localizedMessage}"))
        } catch (e: IOException) {
            emit(Resource.Error("Check your internet connection"))
        } catch (e: Exception) {
            emit(Resource.Error("Unexpected error: ${e.localizedMessage}"))
        }
    }
    
    fun clearCache() {
        cachedDeals = null
        lastCacheTime = 0
    }
    
    private fun isCacheValid(): Boolean {
        return System.currentTimeMillis() - lastCacheTime < cacheValidityDuration
    }
}
package com.festivalapp.presentation.screens.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.festivalapp.data.model.PlannerGroup
import com.festivalapp.data.repository.PlannerRepository
import com.festivalapp.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PlannerUiState(
    val isLoading: Boolean = false,
    val groups: List<PlannerGroup> = emptyList(),
    val selectedGroup: PlannerGroup? = null,
    val error: String? = null,
    val showCreateGroupDialog: Boolean = false
)

@HiltViewModel
class PlannerViewModel @Inject constructor(
    private val plannerRepository: PlannerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlannerUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadGroups()
    }

    fun loadGroups() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            
            plannerRepository.getUserGroups()
                .catch { e ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Failed to load groups: ${e.message}"
                    )
                }
                .collect { resource ->
                    when (resource) {
                        is Resource.Loading -> {
                            _uiState.value = _uiState.value.copy(isLoading = true)
                        }
                        is Resource.Success -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                groups = resource.data ?: emptyList(),
                                error = null
                            )
                        }
                        is Resource.Error -> {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                error = resource.message
                            )
                        }
                    }
                }
        }
    }

    fun selectGroup(groupId: String) {
        val group = _uiState.value.groups.find { it.id == groupId }
        _uiState.value = _uiState.value.copy(selectedGroup = group)
    }

    fun createNewGroup() {
        _uiState.value = _uiState.value.copy(showCreateGroupDialog = true)
    }

    fun hideCreateGroupDialog() {
        _uiState.value = _uiState.value.copy(showCreateGroupDialog = false)
    }

    fun createGroup(name: String, description: String?) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                plannerRepository.createGroup(name, description)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to create group: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    showCreateGroupDialog = false
                                )
                                loadGroups() // Reload groups
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to create group: ${e.message}"
                )
            }
        }
    }

    fun joinGroup(inviteCode: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                plannerRepository.joinGroup(inviteCode)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to join group: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(isLoading = false)
                                loadGroups() // Reload groups
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to join group: ${e.message}"
                )
            }
        }
    }

    fun leaveGroup(groupId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                plannerRepository.leaveGroup(groupId)
                    .catch { e ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Failed to leave group: ${e.message}"
                        )
                    }
                    .collect { resource ->
                        when (resource) {
                            is Resource.Success -> {
                                _uiState.value = _uiState.value.copy(isLoading = false)
                                loadGroups() // Reload groups
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    error = resource.message
                                )
                            }
                            is Resource.Loading -> {
                                _uiState.value = _uiState.value.copy(isLoading = true)
                            }
                        }
                    }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Failed to leave group: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}
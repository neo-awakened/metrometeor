package com.festivalapp.data.repository

import com.festivalapp.data.api.SOSApiService
import com.festivalapp.data.model.EmergencyContact
import com.festivalapp.data.model.EmergencyInfo
import com.festivalapp.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SOSRepository @Inject constructor(
    private val sosApiService: SOSApiService
) {

    fun getEmergencyInfo(): Flow<Resource<EmergencyInfo>> = flow {
        try {
            emit(Resource.Loading())
            val emergencyInfo = sosApiService.getEmergencyInfo()
            emit(Resource.Success(emergencyInfo))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to fetch emergency info"))
        }
    }

    fun sendEmergencyAlert(): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = sosApiService.sendEmergencyAlert()
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to send emergency alert"))
        }
    }

    fun updateLocationSharing(enabled: Boolean): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val request = mapOf("enabled" to enabled)
            val response = sosApiService.updateLocationSharing(request)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to update location sharing"))
        }
    }

    fun addEmergencyContact(contact: EmergencyContact): Flow<Resource<EmergencyContact>> = flow {
        try {
            emit(Resource.Loading())
            val contactRequest = mapOf(
                "name" to contact.name,
                "phoneNumber" to contact.phoneNumber,
                "relationship" to contact.relationship,
                "isPrimary" to contact.isPrimary
            )
            val newContact = sosApiService.addEmergencyContact(contactRequest)
            emit(Resource.Success(newContact))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to add emergency contact"))
        }
    }

    fun updateEmergencyContact(contactId: String, contact: EmergencyContact): Flow<Resource<EmergencyContact>> = flow {
        try {
            emit(Resource.Loading())
            val contactRequest = mapOf(
                "name" to contact.name,
                "phoneNumber" to contact.phoneNumber,
                "relationship" to contact.relationship,
                "isPrimary" to contact.isPrimary
            )
            val updatedContact = sosApiService.updateEmergencyContact(contactId, contactRequest)
            emit(Resource.Success(updatedContact))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to update emergency contact"))
        }
    }

    fun deleteEmergencyContact(contactId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            sosApiService.deleteEmergencyContact(contactId)
            emit(Resource.Success(true))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to delete emergency contact"))
        }
    }

    fun testEmergencyAlert(contactId: String): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = sosApiService.testEmergencyAlert(contactId)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to send test alert"))
        }
    }

    fun updateEmergencyProfile(profileData: Map<String, Any>): Flow<Resource<Boolean>> = flow {
        try {
            emit(Resource.Loading())
            val response = sosApiService.updateEmergencyProfile(profileData)
            emit(Resource.Success(response["success"] as? Boolean ?: false))
        } catch (e: Exception) {
            emit(Resource.Error(e.message ?: "Failed to update emergency profile"))
        }
    }
}
# Zurich Mobility App

A comprehensive FastAPI application providing mobility, events, traffic, and emergency services data for Zurich, Switzerland.

## Features

- **Home Screen API**: Main dashboard with map interface, nearby events, and traffic status
- **Events API**: Event listings, details, route planning, and crowd heatmaps
- **Traffic API**: Real-time traffic analysis, route predictions, and disruptions
- **Group Planner API**: Collaborative trip planning and group coordination
- **Emergency Services API**: SOS features and safety information
- **Deals & Tickets API**: Savings opportunities and ticket booking
- **Heatmap API**: Dynamic heatmap generation for crowd and traffic density

## Data Sources

The application integrates with several Swiss open data sources:

1. **transport.opendata.ch** - Swiss public transport API
2. **opentransportdata.swiss** - Official Swiss transport data platform
3. **Zurich Events API** - City of Zurich events data
4. **SIRI-SX Disruptions** - Real-time transport disruptions

## Installation

1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Copy environment configuration:
```bash
cp env_example.txt .env
```

4. Update the `.env` file with your API keys

## Running the Application

### Development
```bash
python main.py
```

### Production
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

## API Documentation

Once running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## API Endpoints

### Home Screen
- `GET /api/v1/home/dashboard` - Main dashboard data
- `GET /api/v1/home/nearby-events` - Events near user location
- `GET /api/v1/home/traffic-status` - Current traffic conditions
- `GET /api/v1/home/quick-stats` - Quick statistics
- `GET /api/v1/home/search` - Search events and locations

### Events
- `GET /api/v1/events/` - List events with filters
- `GET /api/v1/events/{event_id}` - Event details
- `GET /api/v1/events/{event_id}/routes` - Routes to event
- `GET /api/v1/events/{event_id}/heatmap` - Event crowd heatmap
- `GET /api/v1/events/categories/list` - Event categories

### Traffic
- `GET /api/v1/traffic/status` - Current traffic status
- `GET /api/v1/traffic/routes` - Route predictions

### Group Planner
- `GET /api/v1/planner/groups` - User's groups
- `POST /api/v1/planner/groups` - Create new group
- `GET /api/v1/planner/groups/{group_id}` - Group details

### Emergency Services
- `GET /api/v1/sos/emergency-info` - Emergency contacts and info
- `POST /api/v1/sos/emergency-alert` - Send emergency alert

### Deals & Tickets
- `GET /api/v1/deals/` - Available deals
- `GET /api/v1/deals/categories` - Deal categories

### Heatmap
- `POST /api/v1/heatmap/generate` - Generate heatmap data
- `GET /api/v1/heatmap/data-types` - Available data types

## Project Structure

```
zurich_mobility_app/
├── main.py                 # FastAPI application entry point
├── requirements.txt        # Python dependencies
├── env_example.txt        # Environment configuration template
├── app/
│   ├── __init__.py
│   ├── core/
│   │   ├── config.py      # Application configuration
│   │   └── logging_config.py # Logging setup
│   ├── models/
│   │   └── __init__.py    # Pydantic models
│   ├── services/
│   │   ├── swiss_transport_service.py # Transport API integration
│   │   ├── zurich_events_service.py   # Events API integration
│   │   └── heatmap_service.py         # Heatmap generation
│   └── routers/
│       ├── home_router.py      # Home screen endpoints
│       ├── events_router.py    # Events endpoints
│       ├── traffic_router.py   # Traffic endpoints
│       ├── planner_router.py   # Group planner endpoints
│       ├── sos_router.py       # Emergency services endpoints
│       ├── deals_router.py     # Deals endpoints
│       └── heatmap_router.py   # Heatmap endpoints
```

## Usage Examples

### Get nearby events
```bash
curl "http://localhost:8000/api/v1/home/nearby-events?lat=47.3769&lng=8.5417&radius_km=5"
```

### Generate heatmap
```bash
curl -X POST "http://localhost:8000/api/v1/heatmap/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "coordinates": [{"latitude": 47.3769, "longitude": 8.5417}],
    "radius_meters": 1000,
    "data_types": ["crowd", "traffic"]
  }'
```

### Get traffic status
```bash
curl "http://localhost:8000/api/v1/traffic/status?lat=47.3769&lng=8.5417&radius_km=10"
```

## Configuration

Key configuration options in `.env`:

- `DEBUG`: Enable debug mode
- `HOST` / `PORT`: Server binding
- `GOOGLE_MAPS_API_KEY`: For enhanced mapping features
- `RATE_LIMIT_PER_MINUTE`: API rate limiting
- `LOG_LEVEL`: Logging verbosity

## Data Sources & APIs

### Swiss Transport Data
- **transport.opendata.ch**: Public transport connections, stations, departures
- **opentransportdata.swiss**: Real-time disruptions and GTFS data

### Zurich City Data
- **Zurich Events API**: Official city events and activities
- **Open Data Zurich**: Additional city datasets

### External Services
- **Google Maps API**: Enhanced routing and geocoding (optional)
- **OpenWeather API**: Weather integration (optional)

## License

This project is for educational and demonstration purposes. Please respect the terms of service of the integrated APIs.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes and add tests
4. Submit a pull request

## Support

For questions or issues, please refer to the API documentation at `/docs` when the application is running.
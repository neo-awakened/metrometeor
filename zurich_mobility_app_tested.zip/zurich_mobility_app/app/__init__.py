"""
App package initialization
"""
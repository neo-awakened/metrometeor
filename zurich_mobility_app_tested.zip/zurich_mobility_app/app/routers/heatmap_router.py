"""
Heatmap API Router
Provides endpoints for heatmap data generation
"""

from fastapi import APIRouter, HTTPException, Body
from typing import List
import logging

from app.models import (
    HeatmapRequest,
    HeatmapResponse,
    LocationModel,
    APIResponse
)
from app.services.heatmap_service import heatmap_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/generate", response_model=APIResponse)
async def generate_heatmap(
    request: HeatmapRequest = Body(..., description="Heatmap generation request")
):
    """Generate heatmap data for given coordinates and parameters"""
    try:
        # Validate request
        if not request.coordinates:
            raise HTTPException(status_code=400, detail="At least one coordinate is required")
        
        if not request.data_types:
            raise HTTPException(status_code=400, detail="At least one data type is required")
        
        # Generate heatmap
        heatmap_response = await heatmap_service.generate_heatmap(request)
        
        return APIResponse(
            success=True,
            message=f"Heatmap generated with {len(heatmap_response.points)} data points",
            data=heatmap_response.dict()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error generating heatmap: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to generate heatmap: {str(e)}")


@router.get("/data-types", response_model=APIResponse)
async def get_available_data_types():
    """Get available data types for heatmap generation"""
    try:
        data_types = [
            {
                "value": "crowd",
                "label": "Crowd Density",
                "description": "Shows areas with high people concentration based on events",
                "color": "#FF5722"
            },
            {
                "value": "traffic",
                "label": "Traffic Density",
                "description": "Shows traffic congestion and transport disruptions",
                "color": "#F44336"
            },
            {
                "value": "events",
                "label": "Event Locations",
                "description": "Shows locations of active events and activities",
                "color": "#9C27B0"
            }
        ]
        
        return APIResponse(
            success=True,
            message="Available data types retrieved successfully",
            data={"data_types": data_types}
        )
        
    except Exception as e:
        logger.error(f"Error getting data types: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get data types: {str(e)}")

"""
Events Screen API Router
Provides endpoints for event listings, details, and route planning
"""

from fastapi import APIRouter, HTTPException, Query, Path
from typing import Optional, List
import logging
from datetime import datetime, timedelta

from app.models import (
    EventModel, 
    EventsResponse, 
    LocationModel,
    EventType,
    CrowdDensity,
    RouteOption,
    APIResponse,
    PaginationInfo
)
from app.services.zurich_events_service import zurich_events_service
from app.services.swiss_transport_service import swiss_transport_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/", response_model=APIResponse)
async def get_events(
    lat: Optional[float] = Query(None, ge=-90, le=90, description="User latitude for distance calculation"),
    lng: Optional[float] = Query(None, ge=-180, le=180, description="User longitude for distance calculation"),
    event_type: Optional[str] = Query(None, description="Filter by event type (music, food, sports, cultural, other)"),
    start_date: Optional[str] = Query(None, description="Filter events starting from this date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Filter events ending before this date (YYYY-MM-DD)"),
    radius_km: Optional[float] = Query(None, ge=0.1, le=50.0, description="Search radius in kilometers"),
    page: int = Query(1, ge=1, description="Page number"),
    per_page: int = Query(20, ge=1, le=100, description="Events per page"),
    sort_by: str = Query("date", description="Sort by: date, distance, popularity")
):
    """
    Get events with filtering and pagination
    """
    try:
        # Parse dates
        start_datetime = None
        end_datetime = None
        
        if start_date:
            try:
                start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD")
        
        if end_date:
            try:
                end_datetime = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(days=1)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD")
        
        # Get events
        if lat is not None and lng is not None and radius_km is not None:
            # Get events near location
            user_location = LocationModel(latitude=lat, longitude=lng)
            events = await zurich_events_service.get_events_near_location(
                user_location, 
                radius_km=radius_km,
                limit=1000  # Get all, we'll paginate later
            )
        else:
            # Get all events
            events = await zurich_events_service.get_events(
                event_type=event_type,
                start_date=start_datetime,
                end_date=end_datetime,
                limit=1000
            )
        
        # Apply additional filters
        filtered_events = []
        for event in events:
            # Event type filter
            if event_type and event.event_type.value != event_type:
                continue
            
            # Date filters
            if start_datetime and event.start_time < start_datetime:
                continue
            if end_datetime and event.end_time > end_datetime:
                continue
            
            filtered_events.append(event)
        
        # Sort events
        if sort_by == "date":
            filtered_events.sort(key=lambda x: x.start_time)
        elif sort_by == "distance" and lat is not None and lng is not None:
            filtered_events.sort(key=lambda x: x.distance_from_user or float('inf'))
        elif sort_by == "popularity":
            # Sort by crowd density as proxy for popularity
            crowd_order = {"low": 1, "medium": 2, "high": 3, "very_high": 4}
            filtered_events.sort(key=lambda x: crowd_order.get(x.crowd_density.value, 0), reverse=True)
        
        # Pagination
        total_count = len(filtered_events)
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_events = filtered_events[start_idx:end_idx]
        
        # Create pagination info
        pagination = PaginationInfo(
            page=page,
            per_page=per_page,
            total_count=total_count,
            total_pages=(total_count + per_page - 1) // per_page
        )
        
        # Prepare response data
        events_data = [event.dict() for event in paginated_events]
        
        filters_applied = {
            "event_type": event_type,
            "start_date": start_date,
            "end_date": end_date,
            "radius_km": radius_km,
            "sort_by": sort_by
        }
        
        response_data = {
            "events": events_data,
            "pagination": pagination.dict(),
            "filters_applied": filters_applied,
            "user_location": {"latitude": lat, "longitude": lng} if lat and lng else None
        }
        
        return APIResponse(
            success=True,
            message=f"Retrieved {len(paginated_events)} events (page {page}/{pagination.total_pages})",
            data=response_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting events: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get events: {str(e)}")


@router.get("/{event_id}", response_model=APIResponse)
async def get_event_details(
    event_id: str = Path(..., description="Event ID"),
    lat: Optional[float] = Query(None, ge=-90, le=90, description="User latitude for route planning"),
    lng: Optional[float] = Query(None, ge=-180, le=180, description="User longitude for route planning")
):
    """
    Get detailed information about a specific event
    """
    try:
        # Get all events to find the specific one
        all_events = await zurich_events_service.get_events(limit=1000)
        
        event = None
        for e in all_events:
            if e.id == event_id:
                event = e
                break
        
        if not event:
            raise HTTPException(status_code=404, detail=f"Event with ID {event_id} not found")
        
        event_data = event.dict()
        
        # Add route options if user location provided
        if lat is not None and lng is not None:
            user_location = LocationModel(latitude=lat, longitude=lng)
            
            # Get route options
            route_options = await swiss_transport_service.get_route_options(
                user_location, 
                event.location
            )
            
            # Add mock driving and walking options
            driving_option = RouteOption(
                route_id="driving",
                duration_minutes=25,
                distance_km=event.distance_from_user or 10.0,
                traffic_level=await swiss_transport_service.analyze_traffic_level(user_location),
                description="Driving route",
                waypoints=[user_location, event.location],
                estimated_cost=5.0  # Parking estimate
            )
            
            walking_option = RouteOption(
                route_id="walking",
                duration_minutes=int((event.distance_from_user or 10.0) * 15),  # 15 min per km
                distance_km=event.distance_from_user or 10.0,
                traffic_level=await swiss_transport_service.analyze_traffic_level(user_location),
                description="Walking route",
                waypoints=[user_location, event.location],
                estimated_cost=0.0
            )
            
            all_routes = route_options + [driving_option, walking_option]
            event_data["route_options"] = [route.dict() for route in all_routes]
            
            # Calculate distance
            distance = _calculate_distance(user_location, event.location)
            event_data["distance_from_user"] = round(distance, 2)
        
        # Add crowd prediction timeline
        event_data["crowd_predictions"] = _generate_crowd_predictions(event)
        
        # Add nearby amenities (mock data)
        event_data["nearby_amenities"] = _get_nearby_amenities(event.location)
        
        return APIResponse(
            success=True,
            message="Event details retrieved successfully",
            data=event_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting event details: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get event details: {str(e)}")


@router.get("/{event_id}/routes", response_model=APIResponse)
async def get_event_routes(
    event_id: str = Path(..., description="Event ID"),
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude")
):
    """
    Get route options to a specific event
    """
    try:
        # Find the event
        all_events = await zurich_events_service.get_events(limit=1000)
        event = None
        for e in all_events:
            if e.id == event_id:
                event = e
                break
        
        if not event:
            raise HTTPException(status_code=404, detail=f"Event with ID {event_id} not found")
        
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        # Get public transport routes
        transport_routes = await swiss_transport_service.get_route_options(
            user_location, 
            event.location
        )
        
        # Add driving route
        current_traffic = await swiss_transport_service.analyze_traffic_level(user_location)
        distance = _calculate_distance(user_location, event.location)
        
        driving_route = RouteOption(
            route_id="driving",
            duration_minutes=max(15, int(distance * 3)),  # Rough estimate: 3 min per km in city
            distance_km=distance,
            traffic_level=current_traffic,
            description="Driving route via city roads",
            waypoints=[user_location, event.location],
            estimated_cost=distance * 0.5 + 5.0  # Fuel + parking estimate
        )
        
        # Add walking route
        walking_route = RouteOption(
            route_id="walking",
            duration_minutes=int(distance * 15),  # 15 minutes per km
            distance_km=distance,
            traffic_level=current_traffic,
            description="Walking route",
            waypoints=[user_location, event.location],
            estimated_cost=0.0
        )
        
        all_routes = transport_routes + [driving_route, walking_route]
        
        # Sort by duration
        all_routes.sort(key=lambda x: x.duration_minutes)
        
        routes_data = [route.dict() for route in all_routes]
        
        return APIResponse(
            success=True,
            message=f"Found {len(routes_data)} route options to {event.title}",
            data={
                "event": {
                    "id": event.id,
                    "title": event.title,
                    "location": event.location.dict()
                },
                "user_location": user_location.dict(),
                "routes": routes_data,
                "distance_km": round(distance, 2)
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting event routes: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get event routes: {str(e)}")


@router.get("/{event_id}/heatmap", response_model=APIResponse)
async def get_event_crowd_heatmap(
    event_id: str = Path(..., description="Event ID"),
    radius_meters: int = Query(1000, ge=100, le=5000, description="Heatmap radius in meters")
):
    """
    Get crowd density heatmap for an event area
    """
    try:
        # Find the event
        all_events = await zurich_events_service.get_events(limit=1000)
        event = None
        for e in all_events:
            if e.id == event_id:
                event = e
                break
        
        if not event:
            raise HTTPException(status_code=404, detail=f"Event with ID {event_id} not found")
        
        # Import here to avoid circular imports
        from app.services.heatmap_service import heatmap_service
        from app.models import HeatmapRequest, TimeRange
        
        # Create heatmap request
        heatmap_request = HeatmapRequest(
            coordinates=[event.location],
            radius_meters=radius_meters,
            data_types=["crowd", "traffic"],
            time_range=TimeRange(
                start=event.start_time - timedelta(hours=2),
                end=event.end_time + timedelta(hours=2)
            )
        )
        
        # Generate heatmap
        heatmap_response = await heatmap_service.generate_heatmap(heatmap_request)
        
        return APIResponse(
            success=True,
            message=f"Crowd heatmap generated for {event.title}",
            data={
                "event": {
                    "id": event.id,
                    "title": event.title,
                    "location": event.location.dict(),
                    "crowd_density": event.crowd_density.value
                },
                "heatmap": heatmap_response.dict()
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting event heatmap: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get event heatmap: {str(e)}")


@router.get("/categories/list", response_model=APIResponse)
async def get_event_categories():
    """
    Get list of available event categories
    """
    try:
        categories = [
            {
                "value": "music",
                "label": "Music & Festivals",
                "icon": "music",
                "color": "#9C27B0"
            },
            {
                "value": "food",
                "label": "Food Events",
                "icon": "restaurant",
                "color": "#FF9800"
            },
            {
                "value": "sports",
                "label": "Sports",
                "icon": "sports",
                "color": "#4CAF50"
            },
            {
                "value": "cultural",
                "label": "Cultural",
                "icon": "museum",
                "color": "#2196F3"
            },
            {
                "value": "other",
                "label": "Other Events",
                "icon": "event",
                "color": "#795548"
            }
        ]
        
        return APIResponse(
            success=True,
            message="Event categories retrieved successfully",
            data={"categories": categories}
        )
        
    except Exception as e:
        logger.error(f"Error getting event categories: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get event categories: {str(e)}")


# Helper functions
def _calculate_distance(loc1: LocationModel, loc2: LocationModel) -> float:
    """Calculate distance between two locations in kilometers"""
    import math
    
    lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
    lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
    
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return 6371 * c  # Earth radius in km


def _generate_crowd_predictions(event: EventModel) -> List[dict]:
    """Generate crowd prediction timeline for an event"""
    predictions = []
    start_time = event.start_time - timedelta(hours=2)
    end_time = event.end_time + timedelta(hours=2)
    
    current_time = start_time
    while current_time <= end_time:
        # Simple crowd prediction logic
        hours_to_start = (event.start_time - current_time).total_seconds() / 3600
        hours_from_start = (current_time - event.start_time).total_seconds() / 3600
        
        if hours_to_start > 1:
            crowd_level = 0.2  # Low before event
        elif hours_to_start > 0:
            crowd_level = 0.5 + (1 - hours_to_start) * 0.3  # Building up
        elif 0 <= hours_from_start <= 1:
            crowd_level = 0.9  # Peak during event
        elif hours_from_start <= 2:
            crowd_level = 0.7 - (hours_from_start - 1) * 0.3  # Declining
        else:
            crowd_level = 0.2  # Low after event
        
        predictions.append({
            "time": current_time.isoformat(),
            "crowd_level": min(1.0, max(0.0, crowd_level)),
            "description": _get_crowd_description(crowd_level)
        })
        
        current_time += timedelta(minutes=30)  # 30-minute intervals
    
    return predictions


def _get_crowd_description(level: float) -> str:
    """Get crowd description from level"""
    if level < 0.3:
        return "Low crowd"
    elif level < 0.6:
        return "Moderate crowd"
    elif level < 0.8:
        return "High crowd"
    else:
        return "Very crowded"


def _get_nearby_amenities(location: LocationModel) -> List[dict]:
    """Get nearby amenities (mock data)"""
    return [
        {
            "type": "parking",
            "name": "City Center Parking",
            "distance_meters": 200,
            "price": "2.50 CHF/hour"
        },
        {
            "type": "restaurant",
            "name": "Swiss Bistro",
            "distance_meters": 150,
            "rating": 4.2
        },
        {
            "type": "bathroom",
            "name": "Public Restrooms",
            "distance_meters": 100,
            "price": "Free"
        },
        {
            "type": "atm",
            "name": "UBS ATM",
            "distance_meters": 300,
            "fees": "Standard fees apply"
        }
    ]
"""
Swiss Transport API Service
Integrates with transport.opendata.ch and opentransportdata.swiss
"""

import httpx
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import asyncio
from app.core.config import settings
from app.models import LocationModel, TrafficLevel, Disruption, RouteOption


logger = logging.getLogger(__name__)


class SwissTransportService:
    """Service for Swiss transport data integration"""
    
    def __init__(self):
        self.base_url = settings.OPENTRANSPORT_API_BASE
        self.disruptions_url = settings.DISRUPTIONS_API
        self.timeout = 30.0
        
    async def get_connections(
        self, 
        from_location: str, 
        to_location: str, 
        departure_time: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """Get connections between two locations"""
        try:
            params = {
                "from": from_location,
                "to": to_location,
                "limit": 5
            }
            
            if departure_time:
                params["date"] = departure_time.strftime("%Y-%m-%d")
                params["time"] = departure_time.strftime("%H:%M")
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/connections", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("connections", [])
                
        except Exception as e:
            logger.error(f"Error fetching connections: {str(e)}")
            return []
    
    async def get_nearby_stations(self, location: LocationModel, radius: int = 1000) -> List[Dict[str, Any]]:
        """Get nearby public transport stations"""
        try:
            params = {
                "x": location.longitude,
                "y": location.latitude,
                "limit": 10
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/locations", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("stations", [])
                
        except Exception as e:
            logger.error(f"Error fetching nearby stations: {str(e)}")
            return []
    
    async def get_station_board(self, station_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get departures from a station"""
        try:
            params = {
                "id": station_id,
                "limit": limit
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/stationboard", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("stationboard", [])
                
        except Exception as e:
            logger.error(f"Error fetching station board: {str(e)}")
            return []
    
    async def get_disruptions(self) -> List[Disruption]:
        """Get traffic disruptions from SIRI-SX data (SOAP/XML response)"""
        try:
            import xml.etree.ElementTree as ET
            # Query the disruptions API
            params = {
            }
            headers = {
                "Content-Type": "application/xml",
                "Authorization": "Bearer eyJvcmciOiI2NDA2NTFhNTIyZmEwNTAwMDEyOWJiZTEiLCJpZCI6IjYxYTFiY2ExODRkYjQ1OTJiZTU0YzY0NWViNmNjMGY5IiwiaCI6Im11cm11cjEyOCJ9"
            }
            async with httpx.AsyncClient(timeout=self.timeout, headers=headers) as client:
                response = await client.get(self.disruptions_url, params=params)
                response.raise_for_status()
                xml_data = response.text
                disruptions = []
                try:
                    root = ET.fromstring(xml_data)
                except Exception as e:
                    logger.error(f"Error parsing XML: {str(e)}")
                    return []
                # Find all PtSituationElement nodes
                for situation in root.findall('.//PtSituationElement'):
                    try:
                        # Extract fields
                        alert_cause = situation.findtext('AlertCause', default='Unknown')
                        creation_time = situation.findtext('CreationTime', default=None)
                        validity_period = situation.find('ValidityPeriod')
                        start_time = None
                        end_time = None
                        if validity_period is not None:
                            start_time = validity_period.findtext('StartTime', default=None)
                            end_time = validity_period.findtext('EndTime', default=None)
                        severity = situation.findtext('Severity', default='normal')
                        # Try to get English summary/description, fallback to any
                        summary = None
                        for summary_elem in situation.findall("Summary"):
                            if summary_elem.attrib.get('{http://www.w3.org/XML/1998/namespace}lang', '').lower() == 'en':
                                summary = summary_elem.text
                                break
                        if not summary:
                            summary_elem = situation.find('Summary')
                            summary = summary_elem.text if summary_elem is not None else ''
                        description = None
                        for desc_elem in situation.findall("Description"):
                            if desc_elem.attrib.get('{http://www.w3.org/XML/1998/namespace}lang', '').lower() == 'en':
                                description = desc_elem.text
                                break
                        if not description:
                            desc_elem = situation.find('Description')
                            description = desc_elem.text if desc_elem is not None else ''
                        # Use dummy location (Zurich) as fallback
                        location = LocationModel(latitude=47.3769, longitude=8.5417, address="Zurich, Switzerland")
                        # Try to extract affected routes (LineRef or PublishedLineName)
                        affected_routes = []
                        for line in situation.findall('.//AffectedLine'):
                            line_ref = line.findtext('LineRef')
                            published_name = line.findtext('PublishedLineName')
                            if published_name:
                                affected_routes.append(published_name)
                            elif line_ref:
                                affected_routes.append(line_ref)
                        # Parse times
                        from datetime import datetime
                        def parse_time(val):
                            try:
                                return datetime.fromisoformat(val.replace('Z', '+00:00')) if val else None
                            except Exception:
                                return None
                        disruption = Disruption(
                            id=creation_time or str(datetime.now().timestamp()),
                            title=alert_cause,
                            description=description or summary or '',
                            location=location,
                            severity=severity,
                            start_time=parse_time(start_time),
                            end_time=parse_time(end_time),
                            affected_routes=affected_routes
                        )
                        disruptions.append(disruption)
                    except Exception as e:
                        logger.warning(f"Error parsing disruption record: {str(e)}")
                        continue
                return disruptions
        except Exception as e:
            logger.error(f"Error fetching disruptions: {str(e)}")
            return []
    
    async def analyze_traffic_level(self, location: LocationModel) -> TrafficLevel:
        """Analyze traffic level based on nearby disruptions and transport data"""
        try:
            # Get nearby stations to assess congestion
            stations = await self.get_nearby_stations(location)
            disruptions = await self.get_disruptions()
            
            # Simple traffic level calculation
            nearby_disruptions = 0
            for disruption in disruptions:
                # Calculate distance (simple approximation)
                lat_diff = abs(disruption.location.latitude - location.latitude)
                lng_diff = abs(disruption.location.longitude - location.longitude)
                if lat_diff < 0.01 and lng_diff < 0.01:  # Roughly 1km
                    nearby_disruptions += 1
            
            # Determine traffic level
            if nearby_disruptions == 0:
                return TrafficLevel.LOW
            elif nearby_disruptions <= 2:
                return TrafficLevel.MODERATE
            elif nearby_disruptions <= 5:
                return TrafficLevel.HIGH
            else:
                return TrafficLevel.SEVERE
                
        except Exception as e:
            logger.error(f"Error analyzing traffic level: {str(e)}")
            return TrafficLevel.MODERATE
    
    async def get_route_options(
        self, 
        from_location: LocationModel, 
        to_location: LocationModel
    ) -> List[RouteOption]:
        """Get route options between two locations"""
        try:
            # Convert coordinates to location strings
            from_str = f"{from_location.latitude},{from_location.longitude}"
            to_str = f"{to_location.latitude},{to_location.longitude}"
            
            connections = await self.get_connections(from_str, to_str)
            
            route_options = []
            for i, connection in enumerate(connections[:3]):  # Limit to 3 options
                try:
                    # Parse duration in format '00d01:06:00'
                    duration = connection.get("duration", "00d00:30:00")
                    days, time_part = duration.split('d') if 'd' in duration else ("0", duration)
                    h, m, s = time_part.split(":")
                    duration_minutes = int(days) * 24 * 60 + int(h) * 60 + int(m)

                    # Use products as a list of strings
                    products = connection.get("products", [])
                    description = f"Public transport via {', '.join(products) if products else 'public transport'}"

                    route_option = RouteOption(
                        route_id=f"route_{i}",
                        duration_minutes=duration_minutes,
                        distance_km=10.0,  # Default, as not present in data
                        traffic_level=await self.analyze_traffic_level(from_location),
                        description=description,
                        waypoints=[from_location, to_location],
                        estimated_cost=5.0  # Default, as not present in data
                    )
                    route_options.append(route_option)
                except Exception as e:
                    logger.warning(f"Error parsing route option: {str(e)}")
                    continue
            
            return route_options
            
        except Exception as e:
            logger.error(f"Error getting route options: {str(e)}")
            return []
    
    async def get_realtime_departures(self, location: LocationModel) -> List[Dict[str, Any]]:
        """Get real-time departures near a location"""
        try:
            # Get nearby stations
            stations = await self.get_nearby_stations(location)
            
            if not stations:
                return []
            
            # Get departures from the closest station
            closest_station = stations[0]
            station_id = closest_station.get("id")
            
            if station_id:
                departures = await self.get_station_board(station_id)
                return departures
            
            return []
            
        except Exception as e:
            logger.error(f"Error getting real-time departures: {str(e)}")
            return []


# Global service instance
swiss_transport_service = SwissTransportService()
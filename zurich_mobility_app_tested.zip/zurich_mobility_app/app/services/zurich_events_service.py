"""
Zurich Events API Service
Integrates with Zurich tourism events API
"""

import httpx
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta

from app.core.config import settings
from app.models import EventModel, LocationModel, EventType, CrowdDensity


logger = logging.getLogger(__name__)


class ZurichEventsService:
    """Service for Zurich events data integration"""
    
    def __init__(self):
        self.base_url = settings.ZURICH_EVENTS_API
        self.timeout = 30.0
        
    async def get_events(
        self, 
        event_type: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 50
    ) -> List[EventModel]:
        """Get events from Zurich events API"""
        try:
            # Events API endpoint
            params = {
                "id": "75",  # Events dataset ID
                "limit": limit
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(self.base_url, params=params)
                response.raise_for_status()
                data = response.json()
                events = []
                # Parse events data
                if isinstance(data, dict):
                    records = data.get("records", [])
                elif isinstance(data, list):
                    records = data
                    logger.warning("Events API returned a list instead of a dict; using list as records.")
                else:
                    logger.error(f"Unexpected data type from events API: {type(data)}")
                    records = []
                for record in records:
                    try:
                        event = self._parse_event_record(record)
                        if event:
                            # Apply filters
                            if event_type and event.event_type.value != event_type:
                                continue
                            if start_date and event.start_time < start_date:
                                continue
                            if end_date and event.end_time > end_date:
                                continue
                            
                            events.append(event)
                    except Exception as e:
                        logger.warning(f"Error parsing event record: {str(e)}")
                        continue
                
                return events
                
        except Exception as e:
            logger.error(f"Error fetching events: {str(e)}")
            # Return mock events if API fails
            return await self._get_mock_events()
    
    def _parse_event_record(self, record: Dict[str, Any]) -> Optional[EventModel]:
        """Parse a single event record from the API (adapted for new Zurich Events API structure)"""
        try:
            # Debug: log the record structure for the first few records
            if hasattr(self, '_debug_count'):
                self._debug_count += 1
            else:
                self._debug_count = 1
            if self._debug_count <= 3:
                logger.info(f"Event record structure: {record}")

            # Title: name.en or name.de or name.fr or name.it
            name = record.get("name", {})
            title = name.get("en") or name.get("de") or name.get("fr") or name.get("it")
            if not title:
                logger.warning(f"Skipping event record due to missing title: {record}")
                return None

            # Description: description.en or description.de or description.fr or description.it
            desc = record.get("description", {})
            description = desc.get("en") or desc.get("de") or desc.get("fr") or desc.get("it")
            if not isinstance(description, str):
                description = str(description) if description else None

            # Event type: @type
            event_type_str = record.get("@type", "")
            event_type = self._determine_event_type(title, description or "", event_type_str)

            # Location: geoCoordinates.latitude, geoCoordinates.longitude, address
            geo = record.get("geoCoordinates", {})
            lat = geo.get("latitude", 47.3769)
            lng = geo.get("longitude", 8.5417)
            address_data = record.get("address", {})
            address = f"{address_data.get('streetAddress', '')}, {address_data.get('addressLocality', '')}, {address_data.get('addressCountry', '')}".strip(', ')
            location = LocationModel(
                latitude=lat,
                longitude=lng,
                address=address or "Zurich, Switzerland"
            )

            # Image URL: first photo.url or image.url
            image_url = None
            photos = record.get("photo", [])
            if isinstance(photos, list) and photos:
                image_url = photos[0].get("url")
            if not image_url:
                image = record.get("image", {})
                image_url = image.get("url")

            # Price: price.de or price.en or price.fr or price.it
            price_data = record.get("price", {})
            price_str = price_data.get("de") or price_data.get("en") or price_data.get("fr") or price_data.get("it")
            price = self._parse_price(price_str)

            # Website URL: address.url
            website_url = address_data.get("url")

            # Organizer: leave as None
            organizer = None

            # Start/end time: not present in this structure, set to datetime.now() for type safety
            now = datetime.now()
            start_time = now
            end_time = now

            # Generate mock crowd density based on event type and time (use now if no start_time)
            crowd_density = self._estimate_crowd_density(event_type, start_time)

            event = EventModel(
                id=record.get("identifier") or str(now.timestamp()),
                title=title,
                description=description[:500] if description else None,
                event_type=event_type,
                location=location,
                start_time=start_time,
                end_time=end_time,
                image_url=image_url,
                price=price,
                crowd_density=crowd_density,
                distance_from_user=None,  # Will be calculated when user location is provided
                organizer=organizer,
                website_url=website_url
            )
            return event
        except Exception as e:
            logger.warning(f"Error parsing event record: {str(e)}")
            return None
    
    def _parse_datetime(self, date_str: Optional[str]) -> datetime:
        """Parse datetime from various formats"""
        if not date_str:
            return datetime.now()
        
        try:
            # Try different datetime formats
            formats = [
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d",
                "%d.%m.%Y %H:%M",
                "%d.%m.%Y"
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(date_str, fmt)
                except ValueError:
                    continue
            
            # If no format works, return current time
            return datetime.now()
            
        except Exception:
            return datetime.now()
    
    def _determine_event_type(self, title: str, description: str, category: str) -> EventType:
        """Determine event type from title, description, and category"""
        text = f"{title} {description} {category}".lower()
        
        if any(word in text for word in ["concert", "music", "band", "festival", "dj", "orchestra"]):
            return EventType.MUSIC
        elif any(word in text for word in ["food", "restaurant", "culinary", "wine", "beer", "cooking"]):
            return EventType.FOOD
        elif any(word in text for word in ["sport", "football", "soccer", "tennis", "hockey", "match"]):
            return EventType.SPORTS
        elif any(word in text for word in ["culture", "museum", "art", "theater", "exhibition", "gallery"]):
            return EventType.CULTURAL
        else:
            return EventType.OTHER
    
    def _estimate_crowd_density(self, event_type: EventType, start_time: datetime) -> CrowdDensity:
        """Estimate crowd density based on event type and timing"""
        # Simple heuristic for crowd density
        if event_type == EventType.MUSIC:
            return CrowdDensity.HIGH
        elif event_type == EventType.SPORTS:
            return CrowdDensity.VERY_HIGH
        elif event_type == EventType.FOOD:
            return CrowdDensity.MEDIUM
        elif event_type == EventType.CULTURAL:
            return CrowdDensity.LOW
        
        # Consider timing
        hour = start_time.hour
        if 18 <= hour <= 22:  # Evening events tend to be more crowded
            if event_type in [EventType.MUSIC, EventType.SPORTS]:
                return CrowdDensity.VERY_HIGH
            else:
                return CrowdDensity.HIGH
        
        return CrowdDensity.MEDIUM
    
    def _parse_price(self, price_str: Optional[str]) -> Optional[float]:
        """Parse price from string"""
        if not price_str:
            return None
        
        try:
            # Extract numbers from price string
            import re
            numbers = re.findall(r'\d+\.?\d*', str(price_str))
            if numbers:
                return float(numbers[0])
        except Exception:
            pass
        
        return None
    
    async def get_events_near_location(
        self, 
        location: LocationModel, 
        radius_km: float = 10.0,
        limit: int = 20
    ) -> List[EventModel]:
        """Get events near a specific location"""
        try:
            # Get all events first
            all_events = await self.get_events(limit=100)
            
            # Filter by distance
            nearby_events = []
            for event in all_events:
                distance = self._calculate_distance(location, event.location)
                if distance <= radius_km:
                    event.distance_from_user = distance
                    nearby_events.append(event)
            
            # Sort by distance and limit results
            nearby_events.sort(key=lambda x: x.distance_from_user or float('inf'))
            return nearby_events[:limit]
            
        except Exception as e:
            logger.error(f"Error getting events near location: {str(e)}")
            return []
    
    def _calculate_distance(self, loc1: LocationModel, loc2: LocationModel) -> float:
        """Calculate distance between two locations in kilometers"""
        import math
        
        # Haversine formula
        lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
        lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        # Radius of Earth in kilometers
        r = 6371
        
        return c * r
    
    async def _get_mock_events(self) -> List[EventModel]:
        """Get mock events for testing when API is unavailable"""
        try:
            mock_events = [
                EventModel(
                    id="mock_1",
                    title="Zurich Street Food Festival",
                    description="Annual street food festival featuring cuisines from around the world",
                    event_type=EventType.FOOD,
                    location=LocationModel(latitude=47.3769, longitude=8.5417, address="Zurich City Center"),
                    start_time=datetime.now() + timedelta(days=1),
                    end_time=datetime.now() + timedelta(days=1, hours=8),
                    crowd_density=CrowdDensity.HIGH,
                    price=15.0,
                    organizer="Zurich Tourism",
                    image_url=None,
                    distance_from_user=None,
                    website_url=None
                ),
                EventModel(
                    id="mock_2",
                    title="Classical Concert at Tonhalle",
                    description="Zurich Philharmonic Orchestra performing classical masterpieces",
                    event_type=EventType.MUSIC,
                    location=LocationModel(latitude=47.3656, longitude=8.5435, address="Tonhalle Zurich"),
                    start_time=datetime.now() + timedelta(days=2),
                    end_time=datetime.now() + timedelta(days=2, hours=3),
                    crowd_density=CrowdDensity.MEDIUM,
                    price=45.0,
                    organizer="Tonhalle Orchester Zurich",
                    image_url=None,
                    distance_from_user=None,
                    website_url=None
                ),
                EventModel(
                    id="mock_3",
                    title="FC Zurich vs Basel",
                    description="Swiss Super League football match",
                    event_type=EventType.SPORTS,
                    location=LocationModel(latitude=47.3837, longitude=8.5040, address="Letzigrund Stadium"),
                    start_time=datetime.now() + timedelta(days=3),
                    end_time=datetime.now() + timedelta(days=3, hours=2),
                    crowd_density=CrowdDensity.VERY_HIGH,
                    price=25.0,
                    organizer="FC Zurich",
                    image_url=None,
                    distance_from_user=None,
                    website_url=None
                )
            ]
            
            return mock_events
            
        except Exception as e:
            logger.error(f"Error creating mock events: {str(e)}")
            return []


# Global service instance
zurich_events_service = ZurichEventsService()
"""
Test configuration and utilities
"""

import pytest
import asyncio
from httpx import AsyncClient
from fastapi.testclient import TestClient
from main import app

# Test client
client = TestClient(app)

@pytest.fixture
def test_client():
    """Test client fixture"""
    return client

@pytest.fixture
def event_loop():
    """Event loop fixture for async tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture
async def async_client():
    """Async client fixture"""
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac

# Test data
ZURICH_CENTER = {"lat": 47.3769, "lng": 8.5417}
TEST_EVENT_ID = "test_event_1"
TEST_GROUP_ID = "test_group_1"
TEST_USER_ID = "test_user_1"
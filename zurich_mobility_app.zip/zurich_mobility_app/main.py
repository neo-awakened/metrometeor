"""
Zurich Mobility App - FastAPI Application
Main application entry point for the Zurich mobility and events platform.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from contextlib import asynccontextmanager
import logging

# Import routers
from app.routers import (
    home_router,
    events_router,
    traffic_router,
    planner_router,
    sos_router,
    deals_router,
    heatmap_router
)

# Import configuration
from app.core.config import settings
from app.core.logging_config import setup_logging

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Zurich Mobility App...")
    yield
    logger.info("Shutting down Zurich Mobility App...")


# Create FastAPI application
app = FastAPI(
    title="Zurich Mobility App API",
    description="Comprehensive API for Zurich mobility, events, traffic, and emergency services",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Global exception: {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "zurich-mobility-app"}


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Welcome to Zurich Mobility App API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }


# Include routers
app.include_router(home_router.router, prefix="/api/v1/home", tags=["Home Screen"])
app.include_router(events_router.router, prefix="/api/v1/events", tags=["Events"])
app.include_router(traffic_router.router, prefix="/api/v1/traffic", tags=["Traffic"])
app.include_router(planner_router.router, prefix="/api/v1/planner", tags=["Group Planner"])
app.include_router(sos_router.router, prefix="/api/v1/sos", tags=["Emergency Services"])
app.include_router(deals_router.router, prefix="/api/v1/deals", tags=["Deals & Tickets"])
app.include_router(heatmap_router.router, prefix="/api/v1/heatmap", tags=["Heatmap"])


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="info"
    )
"""
Configuration settings for the Zurich Mobility App
"""

import os
from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # App settings
    APP_NAME: str = "Zurich Mobility App"
    DEBUG: bool = True
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALLOWED_HOSTS: List[str] = ["*"]
    
    # External APIs
    OPENTRANSPORT_API_BASE: str = "https://transport.opendata.ch/v1"
    ZURICH_EVENTS_API: str = "https://www.zuerich.com/en/api/v2/data"
    DISRUPTIONS_API: str = "https://data.opentransportdata.swiss/api/action/datastore_search"
    
    # API Keys (set these as environment variables)
    GOOGLE_MAPS_API_KEY: str = os.getenv("GOOGLE_MAPS_API_KEY", "")
    OPENWEATHER_API_KEY: str = os.getenv("OPENWEATHER_API_KEY", "")
    
    # Cache settings
    CACHE_TTL: int = 300  # 5 minutes
    
    # Rate limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    
    # Database (if needed for future expansion)
    DATABASE_URL: str = "sqlite:///./zurich_mobility.db"
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()
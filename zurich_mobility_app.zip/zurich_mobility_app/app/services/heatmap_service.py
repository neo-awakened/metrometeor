"""
Heatmap Service
Generates heatmap data for crowd density, traffic, and events
"""

import httpx
import logging
import random
import math
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import asyncio
from app.core.config import settings
from app.models import LocationModel, HeatmapPoint, HeatmapRequest, HeatmapResponse
from app.services.swiss_transport_service import swiss_transport_service
from app.services.zurich_events_service import zurich_events_service


logger = logging.getLogger(__name__)


class HeatmapService:
    """Service for generating heatmap data"""
    
    def __init__(self):
        self.timeout = 30.0
        
    async def generate_heatmap(self, request: HeatmapRequest) -> HeatmapResponse:
        """Generate heatmap data for given coordinates and parameters"""
        try:
            points = []
            data_sources = []
            
            # Calculate bounds
            bounds = self._calculate_bounds(request.coordinates)
            
            # Generate points for each data type
            for data_type in request.data_types:
                if data_type == "crowd":
                    crowd_points = await self._generate_crowd_heatmap(request)
                    points.extend(crowd_points)
                    data_sources.append("Event crowd data")
                    
                elif data_type == "traffic":
                    traffic_points = await self._generate_traffic_heatmap(request)
                    points.extend(traffic_points)
                    data_sources.append("Transport disruption data")
                    
                elif data_type == "events":
                    event_points = await self._generate_event_heatmap(request)
                    points.extend(event_points)
                    data_sources.append("Zurich events API")
            
            return HeatmapResponse(
                points=points,
                bounds=bounds,
                generated_at=datetime.now(),
                data_sources=data_sources
            )
            
        except Exception as e:
            logger.error(f"Error generating heatmap: {str(e)}")
            # Return empty heatmap on error
            return HeatmapResponse(
                points=[],
                bounds=self._calculate_bounds(request.coordinates),
                generated_at=datetime.now(),
                data_sources=[]
            )
    
    async def _generate_crowd_heatmap(self, request: HeatmapRequest) -> List[HeatmapPoint]:
        """Generate crowd density heatmap points"""
        points = []
        
        try:
            # Get events in the area to determine crowd concentrations
            for coord in request.coordinates:
                events = await zurich_events_service.get_events_near_location(
                    coord, 
                    radius_km=request.radius_meters / 1000.0
                )
                
                # Create heatmap points around events
                for event in events:
                    # Check if event is within time range
                    if request.time_range:
                        if event.start_time > request.time_range.end or event.end_time < request.time_range.start:
                            continue
                    
                    # Generate points around the event location
                    event_points = self._generate_points_around_location(
                        event.location,
                        intensity=self._crowd_density_to_intensity(event.crowd_density),
                        radius_meters=500,
                        data_type="crowd",
                        timestamp=event.start_time
                    )
                    points.extend(event_points)
            
            # Add general urban crowd patterns
            urban_points = await self._generate_urban_crowd_patterns(request.coordinates)
            points.extend(urban_points)
            
        except Exception as e:
            logger.error(f"Error generating crowd heatmap: {str(e)}")
        
        return points
    
    async def _generate_traffic_heatmap(self, request: HeatmapRequest) -> List[HeatmapPoint]:
        """Generate traffic density heatmap points"""
        points = []
        
        try:
            # Get traffic disruptions
            disruptions = await swiss_transport_service.get_disruptions()
            
            for disruption in disruptions:
                # Check if disruption is within time range
                if request.time_range:
                    if disruption.start_time > request.time_range.end:
                        continue
                    if disruption.end_time and disruption.end_time < request.time_range.start:
                        continue
                
                # Check if disruption is near any of the request coordinates
                is_nearby = False
                for coord in request.coordinates:
                    distance = self._calculate_distance(coord, disruption.location)
                    if distance <= request.radius_meters / 1000.0:
                        is_nearby = True
                        break
                
                if is_nearby:
                    # Generate points around the disruption
                    severity_intensity = self._severity_to_intensity(disruption.severity)
                    disruption_points = self._generate_points_around_location(
                        disruption.location,
                        intensity=severity_intensity,
                        radius_meters=300,
                        data_type="traffic",
                        timestamp=disruption.start_time
                    )
                    points.extend(disruption_points)
            
            # Add general traffic patterns around transport hubs
            transport_points = await self._generate_transport_hub_patterns(request.coordinates)
            points.extend(transport_points)
            
        except Exception as e:
            logger.error(f"Error generating traffic heatmap: {str(e)}")
        
        return points
    
    async def _generate_event_heatmap(self, request: HeatmapRequest) -> List[HeatmapPoint]:
        """Generate event density heatmap points"""
        points = []
        
        try:
            for coord in request.coordinates:
                events = await zurich_events_service.get_events_near_location(
                    coord,
                    radius_km=request.radius_meters / 1000.0
                )
                
                for event in events:
                    # Check time range
                    if request.time_range:
                        if event.start_time > request.time_range.end or event.end_time < request.time_range.start:
                            continue
                    
                    # Single point per event
                    point = HeatmapPoint(
                        latitude=event.location.latitude,
                        longitude=event.location.longitude,
                        intensity=0.8,  # High intensity for events
                        data_type="events",
                        timestamp=event.start_time
                    )
                    points.append(point)
            
        except Exception as e:
            logger.error(f"Error generating event heatmap: {str(e)}")
        
        return points
    
    def _generate_points_around_location(
        self,
        center: LocationModel,
        intensity: float,
        radius_meters: int,
        data_type: str,
        timestamp: datetime,
        num_points: int = 10
    ) -> List[HeatmapPoint]:
        """Generate points in a circle around a location"""
        points = []
        
        # Convert radius to degrees (approximate)
        radius_deg = radius_meters / 111000.0  # 1 degree ≈ 111km
        
        for i in range(num_points):
            # Random angle and distance
            angle = random.uniform(0, 2 * math.pi)
            distance = random.uniform(0, radius_deg) * random.uniform(0.3, 1.0)  # Bias towards center
            
            # Calculate new coordinates
            lat = center.latitude + distance * math.cos(angle)
            lng = center.longitude + distance * math.sin(angle)
            
            # Vary intensity based on distance from center
            distance_factor = 1 - (distance / radius_deg)
            point_intensity = intensity * distance_factor * random.uniform(0.7, 1.0)
            
            point = HeatmapPoint(
                latitude=lat,
                longitude=lng,
                intensity=min(1.0, max(0.0, point_intensity)),
                data_type=data_type,
                timestamp=timestamp
            )
            points.append(point)
        
        return points
    
    async def _generate_urban_crowd_patterns(self, coordinates: List[LocationModel]) -> List[HeatmapPoint]:
        """Generate general urban crowd patterns"""
        points = []
        
        # Known busy areas in Zurich (approximate coordinates)
        busy_areas = [
            {"lat": 47.3769, "lng": 8.5417, "name": "Bahnhofstrasse"},  # Main shopping street
            {"lat": 47.3738, "lng": 8.5410, "name": "Zurich HB"},       # Main train station
            {"lat": 47.3667, "lng": 8.5500, "name": "Old Town"},        # Historic center
            {"lat": 47.3656, "lng": 8.5435, "name": "Lake Zurich"},     # Lakefront
        ]
        
        current_time = datetime.now()
        
        # Generate points around busy areas if they're within range
        for area in busy_areas:
            area_location = LocationModel(latitude=area["lat"], longitude=area["lng"])
            
            # Check if this area is near any requested coordinates
            is_nearby = False
            for coord in coordinates:
                if self._calculate_distance(coord, area_location) <= 5.0:  # 5km radius
                    is_nearby = True
                    break
            
            if is_nearby:
                # Time-based intensity (busier during business hours)
                hour = current_time.hour
                if 8 <= hour <= 18:  # Business hours
                    base_intensity = 0.7
                elif 18 <= hour <= 22:  # Evening
                    base_intensity = 0.8
                else:  # Night/early morning
                    base_intensity = 0.3
                
                area_points = self._generate_points_around_location(
                    area_location,
                    intensity=base_intensity,
                    radius_meters=200,
                    data_type="crowd",
                    timestamp=current_time,
                    num_points=8
                )
                points.extend(area_points)
        
        return points
    
    async def _generate_transport_hub_patterns(self, coordinates: List[LocationModel]) -> List[HeatmapPoint]:
        """Generate traffic patterns around transport hubs"""
        points = []
        
        try:
            for coord in coordinates:
                # Get nearby stations
                stations = await swiss_transport_service.get_nearby_stations(coord, radius=2000)
                
                for station in stations[:5]:  # Limit to 5 nearest stations
                    try:
                        station_coord = LocationModel(
                            latitude=station.get("coordinate", {}).get("y", 0),
                            longitude=station.get("coordinate", {}).get("x", 0)
                        )
                        
                        if station_coord.latitude == 0:  # Invalid coordinates
                            continue
                        
                        # Generate traffic intensity around station
                        station_points = self._generate_points_around_location(
                            station_coord,
                            intensity=0.6,
                            radius_meters=150,
                            data_type="traffic",
                            timestamp=datetime.now(),
                            num_points=6
                        )
                        points.extend(station_points)
                        
                    except Exception as e:
                        logger.warning(f"Error processing station: {str(e)}")
                        continue
        
        except Exception as e:
            logger.error(f"Error generating transport hub patterns: {str(e)}")
        
        return points
    
    def _crowd_density_to_intensity(self, crowd_density: str) -> float:
        """Convert crowd density enum to intensity value"""
        density_map = {
            "low": 0.3,
            "medium": 0.5,
            "high": 0.8,
            "very_high": 1.0
        }
        return density_map.get(crowd_density.lower(), 0.5)
    
    def _severity_to_intensity(self, severity: str) -> float:
        """Convert disruption severity to intensity value"""
        severity_map = {
            "low": 0.3,
            "normal": 0.5,
            "high": 0.8,
            "severe": 1.0
        }
        return severity_map.get(severity.lower(), 0.5)
    
    def _calculate_distance(self, loc1: LocationModel, loc2: LocationModel) -> float:
        """Calculate distance between two locations in kilometers"""
        import math
        
        lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
        lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        return 6371 * c  # Earth radius in km
    
    def _calculate_bounds(self, coordinates: List[LocationModel]) -> Dict[str, float]:
        """Calculate bounding box for coordinates"""
        if not coordinates:
            return {"min_lat": 47.3, "max_lat": 47.4, "min_lng": 8.5, "max_lng": 8.6}
        
        lats = [coord.latitude for coord in coordinates]
        lngs = [coord.longitude for coord in coordinates]
        
        return {
            "min_lat": min(lats),
            "max_lat": max(lats),
            "min_lng": min(lngs),
            "max_lng": max(lngs)
        }


# Global service instance
heatmap_service = HeatmapService()
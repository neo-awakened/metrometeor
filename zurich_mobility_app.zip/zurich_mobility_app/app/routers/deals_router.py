"""
Deals Screen API Router
Provides endpoints for deals, tickets, and savings
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
import logging
from datetime import datetime, timedelta

from app.models import (
    DealModel,
    DealsResponse,
    APIResponse
)

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/", response_model=APIResponse)
async def get_deals(
    category: Optional[str] = Query(None, description="Deal category filter"),
    lat: Optional[float] = Query(None, ge=-90, le=90, description="User latitude"),
    lng: Optional[float] = Query(None, ge=-180, le=180, description="User longitude"),
    limit: int = Query(20, ge=1, le=100, description="Maximum deals to return")
):
    """Get available deals and offers"""
    try:
        # Mock deals data
        mock_deals = [
            DealModel(
                id="deal_1",
                title="Zurich 3-Day Transport Pass",
                description="Unlimited public transport for 3 days",
                original_price=45.0,
                discounted_price=29.0,
                discount_percentage=36,
                category="transport",
                valid_until=datetime.now() + timedelta(days=30),
                vendor="ZVV",
                image_url="https://example.com/transport-pass.jpg"
            ),
            DealModel(
                id="deal_2",
                title="Festival Weekend Package",
                description="Access to 5 music festivals + accommodation",
                original_price=150.0,
                discounted_price=89.0,
                discount_percentage=41,
                category="events",
                valid_until=datetime.now() + timedelta(days=14),
                vendor="Zurich Events",
                image_url="https://example.com/festival-package.jpg"
            ),
            DealModel(
                id="deal_3",
                title="City Center Hotel 2 Nights",
                description="Luxury hotel near Bahnhofstrasse",
                original_price=320.0,
                discounted_price=189.0,
                discount_percentage=41,
                category="accommodation",
                valid_until=datetime.now() + timedelta(days=7),
                vendor="Swiss Hotels",
                image_url="https://example.com/hotel.jpg"
            ),
            DealModel(
                id="deal_4",
                title="Food Festival Pass",
                description="All-day access to street food festival",
                original_price=25.0,
                discounted_price=15.0,
                discount_percentage=40,
                category="food",
                valid_until=datetime.now() + timedelta(days=5),
                vendor="Zurich Food Events",
                image_url="https://example.com/food-festival.jpg"
            )
        ]
        
        # Filter by category if provided
        if category:
            filtered_deals = [deal for deal in mock_deals if deal.category == category]
        else:
            filtered_deals = mock_deals
        
        # Limit results
        deals = filtered_deals[:limit]
        
        # Calculate total savings
        total_savings = sum(deal.original_price - deal.discounted_price for deal in deals)
        
        # Categories
        categories = list(set(deal.category for deal in mock_deals))
        
        deals_data = {
            "deals": [deal.dict() for deal in deals],
            "categories": categories,
            "total_savings": total_savings,
            "total_count": len(deals),
            "filters_applied": {"category": category}
        }
        
        return APIResponse(
            success=True,
            message=f"Found {len(deals)} deals",
            data=deals_data
        )
        
    except Exception as e:
        logger.error(f"Error getting deals: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get deals: {str(e)}")


@router.get("/categories", response_model=APIResponse)
async def get_deal_categories():
    """Get available deal categories"""
    try:
        categories = [
            {"value": "transport", "label": "Transport Passes", "icon": "train"},
            {"value": "events", "label": "Event Tickets", "icon": "event"},
            {"value": "accommodation", "label": "Hotels & Stays", "icon": "hotel"},
            {"value": "food", "label": "Food & Drinks", "icon": "restaurant"},
            {"value": "merchandise", "label": "Merchandise", "icon": "shopping"}
        ]
        
        return APIResponse(
            success=True,
            message="Deal categories retrieved successfully",
            data={"categories": categories}
        )
        
    except Exception as e:
        logger.error(f"Error getting deal categories: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get deal categories: {str(e)}")

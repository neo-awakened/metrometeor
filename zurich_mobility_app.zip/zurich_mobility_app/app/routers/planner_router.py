"""
Planner Screen API Router
Provides endpoints for group planning and coordination
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
import logging
from datetime import datetime
import uuid

from app.models import (
    LocationModel,
    PlannerGroup,
    GroupMember,
    APIResponse
)

logger = logging.getLogger(__name__)
router = APIRouter()

# Mock data store (in production, use a database)
groups_store = {}
members_store = {}


@router.get("/groups", response_model=APIResponse)
async def get_user_groups(
    user_id: str = Query(..., description="User ID")
):
    """Get groups for a user"""
    try:
        user_groups = [group for group in groups_store.values() 
                      if any(member.id == user_id for member in group.members)]
        
        groups_data = [group.dict() for group in user_groups]
        
        return APIResponse(
            success=True,
            message=f"Found {len(user_groups)} groups",
            data={"groups": groups_data}
        )
        
    except Exception as e:
        logger.error(f"Error getting user groups: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get groups: {str(e)}")


@router.post("/groups", response_model=APIResponse)
async def create_group(
    name: str = Query(..., description="Group name"),
    description: Optional[str] = Query(None, description="Group description"),
    creator_id: str = Query(..., description="Creator user ID")
):
    """Create a new group"""
    try:
        group_id = str(uuid.uuid4())
        
        # Create creator as first member
        creator = GroupMember(
            id=creator_id,
            name=f"User {creator_id}",
            is_online=True,
            location=None,
            last_seen=datetime.now()
        )
        
        group = PlannerGroup(
            id=group_id,
            name=name,
            description=description,
            created_by=creator_id,
            members=[creator],
            events=[],
            meeting_point=None,
            is_location_sharing_enabled=False,
            created_at=datetime.now()
        )
        
        groups_store[group_id] = group
        
        return APIResponse(
            success=True,
            message="Group created successfully",
            data=group.dict()
        )
        
    except Exception as e:
        logger.error(f"Error creating group: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to create group: {str(e)}")


@router.get("/groups/{group_id}", response_model=APIResponse)
async def get_group_details(
    group_id: str
):
    """Get detailed information about a group"""
    try:
        if group_id not in groups_store:
            raise HTTPException(status_code=404, detail="Group not found")
        
        group = groups_store[group_id]
        
        return APIResponse(
            success=True,
            message="Group details retrieved successfully",
            data=group.dict()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting group details: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get group details: {str(e)}")

"""
SOS Screen API Router
Provides endpoints for emergency services and safety features
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
import logging
from datetime import datetime

from app.models import (
    LocationModel,
    EmergencyContact,
    EmergencyInfo,
    APIResponse
)

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/emergency-info", response_model=APIResponse)
async def get_emergency_info(
    lat: Optional[float] = Query(None, ge=-90, le=90, description="User latitude"),
    lng: Optional[float] = Query(None, ge=-180, le=180, description="User longitude")
):
    """Get emergency information and contacts"""
    try:
        # Mock emergency contacts
        contacts = [
            EmergencyContact(
                id="contact_1",
                name="Emergency Services",
                phone_number="112",
                relationship="emergency",
                is_primary=True
            ),
            EmergencyContact(
                id="contact_2",
                name="Police",
                phone_number="117",
                relationship="police",
                is_primary=False
            ),
            EmergencyContact(
                id="contact_3",
                name="Fire Department",
                phone_number="118",
                relationship="fire",
                is_primary=False
            ),
            EmergencyContact(
                id="contact_4",
                name="Medical Emergency",
                phone_number="144",
                relationship="medical",
                is_primary=False
            )
        ]
        
        emergency_info = EmergencyInfo(
            emergency_contacts=contacts,
            medical_info={
                "blood_type": "Unknown",
                "allergies": [],
                "medications": [],
                "medical_conditions": []
            },
            location_sharing_enabled=True,
            emergency_services_number="112"
        )
        
        response_data = emergency_info.dict()
        
        # Add location-specific info if provided
        if lat is not None and lng is not None:
            response_data["current_location"] = {
                "latitude": lat,
                "longitude": lng,
                "timestamp": datetime.now().isoformat()
            }
            
            # Add nearby emergency services
            response_data["nearby_services"] = [
                {
                    "type": "hospital",
                    "name": "University Hospital Zurich",
                    "distance_km": 2.5,
                    "phone": "+41 44 255 11 11"
                },
                {
                    "type": "police_station",
                    "name": "Zurich City Police",
                    "distance_km": 1.2,
                    "phone": "117"
                }
            ]
        
        return APIResponse(
            success=True,
            message="Emergency information retrieved successfully",
            data=response_data
        )
        
    except Exception as e:
        logger.error(f"Error getting emergency info: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get emergency info: {str(e)}")


@router.post("/emergency-alert", response_model=APIResponse)
async def send_emergency_alert(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude"),
    alert_type: str = Query(..., description="Type of emergency alert"),
    message: Optional[str] = Query(None, description="Optional message")
):
    """Send an emergency alert"""
    try:
        location = LocationModel(latitude=lat, longitude=lng)
        
        alert_data = {
            "alert_id": f"alert_{datetime.now().timestamp()}",
            "alert_type": alert_type,
            "location": location.dict(),
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "status": "sent",
            "contacts_notified": [
                "Emergency Services (112)",
                "Zurich Police (117)"
            ]
        }
        
        return APIResponse(
            success=True,
            message="Emergency alert sent successfully",
            data=alert_data
        )
        
    except Exception as e:
        logger.error(f"Error sending emergency alert: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to send emergency alert: {str(e)}")

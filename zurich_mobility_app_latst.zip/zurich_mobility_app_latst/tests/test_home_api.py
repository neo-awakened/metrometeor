"""
Test the Home Screen API endpoints
"""

import pytest
from tests.conftest import ZURICH_CENTER


def test_health_check(test_client):
    """Test health check endpoint"""
    response = test_client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"


def test_root_endpoint(test_client):
    """Test root endpoint"""
    response = test_client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "version" in data


def test_home_dashboard(test_client):
    """Test home dashboard endpoint"""
    response = test_client.get(
        f"/api/v1/home/dashboard?lat={ZURICH_CENTER['lat']}&lng={ZURICH_CENTER['lng']}"
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "data" in data
    assert "user_location" in data["data"]
    assert "quick_stats" in data["data"]


def test_nearby_events(test_client):
    """Test nearby events endpoint"""
    response = test_client.get(
        f"/api/v1/home/nearby-events?lat={ZURICH_CENTER['lat']}&lng={ZURICH_CENTER['lng']}&radius_km=5"
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "events" in data["data"]


def test_traffic_status(test_client):
    """Test traffic status endpoint"""
    response = test_client.get(
        f"/api/v1/home/traffic-status?lat={ZURICH_CENTER['lat']}&lng={ZURICH_CENTER['lng']}"
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "current_traffic_level" in data["data"]


def test_quick_stats(test_client):
    """Test quick stats endpoint"""
    response = test_client.get(
        f"/api/v1/home/quick-stats?lat={ZURICH_CENTER['lat']}&lng={ZURICH_CENTER['lng']}"
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "events_nearby" in data["data"]


def test_search(test_client):
    """Test search endpoint"""
    response = test_client.get(
        f"/api/v1/home/search?query=festival&lat={ZURICH_CENTER['lat']}&lng={ZURICH_CENTER['lng']}"
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "events" in data["data"]


def test_invalid_coordinates(test_client):
    """Test with invalid coordinates"""
    response = test_client.get("/api/v1/home/dashboard?lat=100&lng=200")
    assert response.status_code == 422  # Validation error
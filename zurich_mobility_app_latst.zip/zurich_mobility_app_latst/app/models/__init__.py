"""
Pydantic models for the Zurich Mobility App
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


# Base models
class LocationModel(BaseModel):
    """Location coordinates model"""
    latitude: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude coordinate")
    address: Optional[str] = Field(None, description="Human readable address")


class TimeRange(BaseModel):
    """Time range model"""
    start: datetime
    end: datetime


# Enums
class EventType(str, Enum):
    MUSIC = "music"
    FOOD = "food"
    SPORTS = "sports"
    CULTURAL = "cultural"
    OTHER = "other"


class TrafficLevel(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    SEVERE = "severe"


class CrowdDensity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"


# Home Screen Models
class TrafficIndicator(BaseModel):
    """Traffic indicator model"""
    level: TrafficLevel
    color: str
    description: str


class QuickStats(BaseModel):
    """Quick stats model for home screen"""
    events_nearby: int
    traffic_level: TrafficLevel
    weather_temp: Optional[float] = None
    weather_condition: Optional[str] = None


class HomeScreenData(BaseModel):
    """Home screen data model"""
    user_location: LocationModel
    quick_stats: QuickStats
    nearby_events: List[Dict[str, Any]]
    traffic_indicators: List[TrafficIndicator]
    last_updated: datetime


# Event Models
class EventModel(BaseModel):
    """Event model"""
    id: str
    title: str
    description: Optional[str]
    event_type: EventType
    location: LocationModel
    start_time: datetime
    end_time: datetime
    image_url: Optional[str]
    price: Optional[float]
    crowd_density: CrowdDensity
    distance_from_user: Optional[float]
    organizer: Optional[str]
    website_url: Optional[str]


class EventsResponse(BaseModel):
    """Events API response model"""
    events: List[EventModel]
    total_count: int
    page: int
    per_page: int
    filters_applied: Dict[str, Any]


# Traffic Models
class RouteOption(BaseModel):
    """Route option model"""
    route_id: str
    duration_minutes: int
    distance_km: float
    traffic_level: TrafficLevel
    description: str
    waypoints: List[LocationModel]
    estimated_cost: Optional[float]


class Disruption(BaseModel):
    """Traffic disruption model"""
    id: str
    title: str
    description: str
    location: LocationModel
    severity: str
    start_time: datetime
    end_time: Optional[datetime]
    affected_routes: List[str]


class TrafficData(BaseModel):
    """Traffic data model"""
    current_conditions: TrafficLevel
    average_delay_minutes: int
    active_disruptions: List[Disruption]
    route_suggestions: List[RouteOption]
    last_updated: datetime


# Planner Models
class GroupMember(BaseModel):
    """Group member model"""
    id: str
    name: str
    avatar_url: Optional[str]
    is_online: bool
    location: Optional[LocationModel]
    last_seen: Optional[datetime]


class PlannerGroup(BaseModel):
    """Group planner model"""
    id: str
    name: str
    description: Optional[str]
    created_by: str
    members: List[GroupMember]
    events: List[str]  # Event IDs
    meeting_point: Optional[LocationModel]
    is_location_sharing_enabled: bool
    created_at: datetime


# SOS Models
class EmergencyContact(BaseModel):
    """Emergency contact model"""
    id: str
    name: str
    phone_number: str
    relationship: str
    is_primary: bool


class EmergencyInfo(BaseModel):
    """Emergency information model"""
    emergency_contacts: List[EmergencyContact]
    medical_info: Optional[Dict[str, Any]]
    location_sharing_enabled: bool
    emergency_services_number: str


# Deals Models
class DealModel(BaseModel):
    """Deal model"""
    id: str
    title: str
    description: str
    original_price: float
    discounted_price: float
    discount_percentage: int
    category: str
    valid_until: datetime
    vendor: str
    image_url: Optional[str]
    terms_conditions: Optional[str]


class DealsResponse(BaseModel):
    """Deals API response model"""
    deals: List[DealModel]
    categories: List[str]
    total_savings: float
    personalized_recommendations: List[DealModel]


# Heatmap Models
class HeatmapPoint(BaseModel):
    """Heatmap data point"""
    latitude: float
    longitude: float
    intensity: float = Field(..., ge=0.0, le=1.0, description="Intensity value between 0 and 1")
    data_type: str = Field(..., description="Type of data (crowd, traffic, events)")
    timestamp: datetime


class HeatmapRequest(BaseModel):
    """Heatmap API request model"""
    coordinates: List[LocationModel]
    radius_meters: int = Field(1000, ge=100, le=5000, description="Radius in meters")
    data_types: List[str] = Field(["crowd", "traffic"], description="Types of data to include")
    time_range: Optional[TimeRange] = None


class HeatmapResponse(BaseModel):
    """Heatmap API response model"""
    points: List[HeatmapPoint]
    bounds: Dict[str, float]  # min_lat, max_lat, min_lng, max_lng
    generated_at: datetime
    data_sources: List[str]


# Washroom Models
class WashroomType(str, Enum):
    FIXED = "fixed"
    MOBILE = "mobile"
    PISSOIR = "pissoir"


class AccessibilityLevel(str, Enum):
    WHEELCHAIR_ACCESSIBLE = "wheelchair_accessible"
    NOT_WHEELCHAIR_ACCESSIBLE = "not_wheelchair_accessible"
    PARTIALLY_ACCESSIBLE = "partially_accessible"


class WashroomModel(BaseModel):
    """Washroom model"""
    id: str
    name: str
    address: str
    location: LocationModel
    washroom_type: WashroomType
    accessibility: AccessibilityLevel
    is_free: bool
    is_open_24h: bool
    opening_hours: Optional[str] = None
    description: Optional[str] = None
    contact_info: Optional[str] = None
    district: Optional[str] = None
    postal_code: Optional[str] = None
    distance_from_user: Optional[float] = None
    last_updated: Optional[datetime] = None


class WashroomSearchRequest(BaseModel):
    """Washroom search request model"""
    location: LocationModel
    radius_meters: int = Field(1000, ge=100, le=5000, description="Search radius in meters")
    washroom_type: Optional[WashroomType] = None
    accessibility_required: bool = False
    free_only: bool = False
    open_24h_only: bool = False


class WashroomResponse(BaseModel):
    """Washroom API response model"""
    washrooms: List[WashroomModel]
    total_count: int
    search_radius: int
    center_location: LocationModel
    filters_applied: Dict[str, Any]


# Generic Response Models
class APIResponse(BaseModel):
    """Generic API response wrapper"""
    success: bool
    message: str
    data: Optional[Any] = None
    error: Optional[str] = None


class PaginationInfo(BaseModel):
    """Pagination information"""
    page: int
    per_page: int
    total_count: int
    total_pages: int
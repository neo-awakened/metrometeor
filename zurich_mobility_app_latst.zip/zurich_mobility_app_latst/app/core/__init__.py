"""
Core package initialization
"""
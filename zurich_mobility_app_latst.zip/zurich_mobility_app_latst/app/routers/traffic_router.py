"""
Traffic Screen API Router
Provides endpoints for traffic analysis, route prediction, and disruptions
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
import logging
from datetime import datetime, timedelta

from app.models import (
    LocationModel,
    TrafficData,
    RouteOption,
    Disruption,
    TrafficLevel,
    APIResponse
)
from app.services.swiss_transport_service import swiss_transport_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/status", response_model=APIResponse)
async def get_traffic_status(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude"),
    radius_km: float = Query(10.0, ge=0.1, le=50.0, description="Search radius")
):
    """Get current traffic status and analysis"""
    try:
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        # Get traffic level
        traffic_level = await swiss_transport_service.analyze_traffic_level(user_location)
        
        # Get disruptions
        disruptions = await swiss_transport_service.get_disruptions()
        
        # Filter nearby disruptions
        nearby_disruptions = []
        for disruption in disruptions:
            distance = _calculate_distance(user_location, disruption.location)
            if distance <= radius_km:
                disruption_data = disruption.dict()
                disruption_data["distance_km"] = round(distance, 2)
                nearby_disruptions.append(disruption_data)
        
        # Calculate average delay
        avg_delay = len(nearby_disruptions) * 5  # Simple estimation
        
        traffic_data = {
            "current_conditions": traffic_level.value,
            "average_delay_minutes": avg_delay,
            "active_disruptions": nearby_disruptions,
            "disruption_count": len(nearby_disruptions),
            "last_updated": datetime.now().isoformat()
        }
        
        return APIResponse(
            success=True,
            message="Traffic status retrieved successfully",
            data=traffic_data
        )
        
    except Exception as e:
        logger.error(f"Error getting traffic status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get traffic status: {str(e)}")


@router.get("/routes", response_model=APIResponse)
async def get_route_predictions(
    from_lat: float = Query(..., ge=-90, le=90),
    from_lng: float = Query(..., ge=-180, le=180),
    to_lat: float = Query(..., ge=-90, le=90),
    to_lng: float = Query(..., ge=-180, le=180),
    departure_time: Optional[str] = Query(None, description="Departure time (ISO format)")
):
    """Get route predictions between two points"""
    try:
        from_location = LocationModel(latitude=from_lat, longitude=from_lng)
        to_location = LocationModel(latitude=to_lat, longitude=to_lng)
        
        departure_dt = None
        if departure_time:
            try:
                departure_dt = datetime.fromisoformat(departure_time)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid departure_time format")
        
        # Get route options
        routes = await swiss_transport_service.get_route_options(from_location, to_location)
        
        routes_data = [route.dict() for route in routes]
        
        return APIResponse(
            success=True,
            message=f"Found {len(routes)} route options",
            data={
                "routes": routes_data,
                "from_location": from_location.dict(),
                "to_location": to_location.dict(),
                "departure_time": departure_time
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting route predictions: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get route predictions: {str(e)}")


def _calculate_distance(loc1: LocationModel, loc2: LocationModel) -> float:
    """Calculate distance between two locations"""
    import math
    lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
    lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    return 6371 * 2 * math.asin(math.sqrt(a))

"""
Washroom API Router
FastAPI router for washroom-related endpoints
"""

from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List, Optional
import logging

from app.models import (
    WashroomModel,
    WashroomSearchRequest,
    WashroomResponse,
    WashroomType,
    LocationModel,
    APIResponse
)
from app.services.zurich_washroom_service import zurich_washroom_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/search", response_model=WashroomResponse)
async def search_washrooms(
    latitude: float = Query(..., ge=-90, le=90, description="User latitude"),
    longitude: float = Query(..., ge=-180, le=180, description="User longitude"),
    radius: int = Query(1000, ge=100, le=5000, description="Search radius in meters"),
    washroom_type: Optional[WashroomType] = Query(None, description="Filter by washroom type"),
    accessibility_required: bool = Query(False, description="Require wheelchair accessibility"),
    free_only: bool = Query(False, description="Show only free washrooms"),
    open_24h_only: bool = Query(False, description="Show only 24h washrooms")
):
    """
    Search for washrooms near a location
    
    Returns a list of washrooms within the specified radius, with optional filters.
    Results are sorted by distance from the search location.
    """
    try:
        # Create search request
        search_request = WashroomSearchRequest(
            location=LocationModel(latitude=latitude, longitude=longitude),
            radius_meters=radius,
            washroom_type=washroom_type,
            accessibility_required=accessibility_required,
            free_only=free_only,
            open_24h_only=open_24h_only
        )
        
        # Execute search
        result = await zurich_washroom_service.search_washrooms(search_request)
        
        logger.info(f"Found {result.total_count} washrooms near ({latitude}, {longitude})")
        return result
        
    except Exception as e:
        logger.error(f"Error searching washrooms: {str(e)}")
        raise HTTPException(status_code=500, detail="Error searching washrooms")


@router.post("/search", response_model=WashroomResponse)
async def search_washrooms_post(request: WashroomSearchRequest):
    """
    Search for washrooms near a location (POST version for complex requests)
    
    Accepts a JSON request body with detailed search criteria.
    """
    try:
        result = await zurich_washroom_service.search_washrooms(request)
        
        logger.info(f"Found {result.total_count} washrooms for POST search")
        return result
        
    except Exception as e:
        logger.error(f"Error in POST washroom search: {str(e)}")
        raise HTTPException(status_code=500, detail="Error searching washrooms")


@router.get("/nearby", response_model=List[WashroomModel])
async def get_nearby_washrooms(
    latitude: float = Query(..., ge=-90, le=90, description="User latitude"),
    longitude: float = Query(..., ge=-180, le=180, description="User longitude"),
    limit: int = Query(10, ge=1, le=50, description="Maximum number of results")
):
    """
    Get the nearest washrooms to a location
    
    Returns a simple list of the closest washrooms, limited by the specified count.
    """
    try:
        # Create search request with default radius
        search_request = WashroomSearchRequest(
            location=LocationModel(latitude=latitude, longitude=longitude),
            radius_meters=2000  # 2km default radius
        )
        
        # Execute search
        result = await zurich_washroom_service.search_washrooms(search_request)
        
        # Return limited results
        nearest_washrooms = result.washrooms[:limit]
        
        logger.info(f"Returning {len(nearest_washrooms)} nearest washrooms")
        return nearest_washrooms
        
    except Exception as e:
        logger.error(f"Error getting nearby washrooms: {str(e)}")
        raise HTTPException(status_code=500, detail="Error getting nearby washrooms")


@router.get("/{washroom_id}", response_model=WashroomModel)
async def get_washroom_details(washroom_id: str):
    """
    Get detailed information about a specific washroom
    
    Returns complete information about a washroom including location, type, 
    accessibility, and operational details.
    """
    try:
        washroom = await zurich_washroom_service.get_washroom_by_id(washroom_id)
        
        if not washroom:
            raise HTTPException(status_code=404, detail="Washroom not found")
        
        logger.info(f"Retrieved details for washroom: {washroom_id}")
        return washroom
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting washroom details: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving washroom details")


@router.get("/", response_model=List[WashroomModel])
async def get_all_washrooms(
    washroom_type: Optional[WashroomType] = Query(None, description="Filter by washroom type"),
    accessibility_required: bool = Query(False, description="Require wheelchair accessibility"),
    limit: int = Query(100, ge=1, le=500, description="Maximum number of results"),
    skip: int = Query(0, ge=0, description="Number of records to skip")
):
    """
    Get all washrooms with optional filtering
    
    Returns a paginated list of all washrooms in the system with optional filters.
    Useful for getting comprehensive data or building maps.
    """
    try:
        # Load all washrooms
        all_washrooms = await zurich_washroom_service.load_washroom_data()
        
        # Apply filters
        filtered_washrooms = all_washrooms
        
        if washroom_type:
            filtered_washrooms = [w for w in filtered_washrooms if w.washroom_type == washroom_type]
        
        if accessibility_required:
            from app.models import AccessibilityLevel
            filtered_washrooms = [w for w in filtered_washrooms 
                                if w.accessibility == AccessibilityLevel.WHEELCHAIR_ACCESSIBLE]
        
        # Apply pagination
        paginated_washrooms = filtered_washrooms[skip:skip + limit]
        
        logger.info(f"Returning {len(paginated_washrooms)} washrooms (filtered from {len(all_washrooms)})")
        return paginated_washrooms
        
    except Exception as e:
        logger.error(f"Error getting all washrooms: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving washrooms")


@router.get("/stats/summary", response_model=dict)
async def get_washroom_statistics():
    """
    Get statistics about the washroom dataset
    
    Returns summary statistics including counts by type, accessibility, 
    and operational characteristics.
    """
    try:
        stats = await zurich_washroom_service.get_washroom_statistics()
        
        logger.info("Retrieved washroom statistics")
        return {
            "success": True,
            "data": stats,
            "message": "Washroom statistics retrieved successfully"
        }
        
    except Exception as e:
        logger.error(f"Error getting washroom statistics: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving statistics")


@router.get("/types", response_model=List[str])
async def get_washroom_types():
    """
    Get all available washroom types
    
    Returns a list of all washroom types available in the system.
    """
    try:
        types = [t.value for t in WashroomType]
        
        logger.info(f"Returning {len(types)} washroom types")
        return types
        
    except Exception as e:
        logger.error(f"Error getting washroom types: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving washroom types")


@router.get("/districts/{district}/washrooms", response_model=List[WashroomModel])
async def get_washrooms_by_district(
    district: str,
    limit: int = Query(50, ge=1, le=200, description="Maximum number of results")
):
    """
    Get washrooms in a specific district
    
    Returns washrooms located in the specified Zurich district.
    """
    try:
        # Load all washrooms
        all_washrooms = await zurich_washroom_service.load_washroom_data()
        
        # Filter by district
        district_washrooms = [w for w in all_washrooms 
                            if w.district and w.district.strip() == district.strip()]
        
        # Apply limit
        limited_washrooms = district_washrooms[:limit]
        
        logger.info(f"Found {len(limited_washrooms)} washrooms in district {district}")
        return limited_washrooms
        
    except Exception as e:
        logger.error(f"Error getting washrooms by district: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving washrooms by district")


@router.get("/accessibility/wheelchair", response_model=List[WashroomModel])
async def get_wheelchair_accessible_washrooms(
    latitude: Optional[float] = Query(None, ge=-90, le=90, description="User latitude for distance calculation"),
    longitude: Optional[float] = Query(None, ge=-180, le=180, description="User longitude for distance calculation"),
    radius: int = Query(5000, ge=100, le=10000, description="Search radius in meters"),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of results")
):
    """
    Get wheelchair accessible washrooms
    
    Returns washrooms that are specifically wheelchair accessible, optionally 
    filtered by distance from a location.
    """
    try:
        if latitude is not None and longitude is not None:
            # Search with location
            search_request = WashroomSearchRequest(
                location=LocationModel(latitude=latitude, longitude=longitude),
                radius_meters=radius,
                accessibility_required=True
            )
            
            result = await zurich_washroom_service.search_washrooms(search_request)
            washrooms = result.washrooms[:limit]
        else:
            # Get all accessible washrooms
            all_washrooms = await zurich_washroom_service.load_washroom_data()
            from app.models import AccessibilityLevel
            washrooms = [w for w in all_washrooms 
                        if w.accessibility == AccessibilityLevel.WHEELCHAIR_ACCESSIBLE][:limit]
        
        logger.info(f"Found {len(washrooms)} wheelchair accessible washrooms")
        return washrooms
        
    except Exception as e:
        logger.error(f"Error getting wheelchair accessible washrooms: {str(e)}")
        raise HTTPException(status_code=500, detail="Error retrieving accessible washrooms")
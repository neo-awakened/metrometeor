"""
Home Screen API Router
Provides endpoints for the main dashboard/map interface
"""

from fastapi import APIRouter, HTTPException, Query, Depends
from typing import Optional, List
import logging
from datetime import datetime

from app.models import (
    LocationModel, 
    HomeScreenData, 
    QuickStats, 
    TrafficIndicator,
    TrafficLevel,
    APIResponse
)
from app.services.swiss_transport_service import swiss_transport_service
from app.services.zurich_events_service import zurich_events_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/dashboard", response_model=APIResponse)
async def get_home_dashboard(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude"),
    radius_km: float = Query(5.0, ge=0.1, le=20.0, description="Search radius in kilometers")
):
    """
    Get home screen dashboard data including map info, events, and traffic
    """
    try:
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        # Get nearby events
        nearby_events = await zurich_events_service.get_events_near_location(
            user_location, 
            radius_km=radius_km,
            limit=10
        )
        
        # Analyze traffic level
        current_traffic_level = await swiss_transport_service.analyze_traffic_level(user_location)
        
        # Get disruptions for traffic indicators
        disruptions = await swiss_transport_service.get_disruptions()
        
        # Create traffic indicators
        traffic_indicators = []
        for disruption in disruptions[:5]:  # Limit to 5 most relevant
            distance = _calculate_distance(user_location, disruption.location)
            if distance <= radius_km:
                indicator = TrafficIndicator(
                    level=_severity_to_traffic_level(disruption.severity),
                    color=_traffic_level_to_color(_severity_to_traffic_level(disruption.severity)),
                    description=disruption.title
                )
                traffic_indicators.append(indicator)
        
        # Create quick stats
        quick_stats = QuickStats(
            events_nearby=len(nearby_events),
            traffic_level=current_traffic_level,
            weather_temp=None,  # Could integrate weather API
            weather_condition=None
        )
        
        # Prepare events data for response
        events_data = []
        for event in nearby_events:
            event_data = {
                "id": event.id,
                "title": event.title,
                "location": {
                    "latitude": event.location.latitude,
                    "longitude": event.location.longitude,
                    "address": event.location.address
                },
                "start_time": event.start_time.isoformat(),
                "event_type": event.event_type.value,
                "crowd_density": event.crowd_density.value,
                "distance_km": event.distance_from_user
            }
            events_data.append(event_data)
        
        # Create home screen data
        home_data = HomeScreenData(
            user_location=user_location,
            quick_stats=quick_stats,
            nearby_events=events_data,
            traffic_indicators=traffic_indicators,
            last_updated=datetime.now()
        )
        
        return APIResponse(
            success=True,
            message="Home dashboard data retrieved successfully",
            data=home_data.dict()
        )
        
    except Exception as e:
        logger.error(f"Error getting home dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get dashboard data: {str(e)}")


@router.get("/nearby-events", response_model=APIResponse)
async def get_nearby_events(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude"),
    radius_km: float = Query(5.0, ge=0.1, le=20.0, description="Search radius in kilometers"),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of events to return")
):
    """
    Get events near user location
    """
    try:
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        events = await zurich_events_service.get_events_near_location(
            user_location, 
            radius_km=radius_km,
            limit=limit
        )
        
        events_data = [event.dict() for event in events]
        
        return APIResponse(
            success=True,
            message=f"Found {len(events)} events within {radius_km}km",
            data={
                "events": events_data,
                "user_location": user_location.dict(),
                "search_radius_km": radius_km,
                "total_found": len(events)
            }
        )
        
    except Exception as e:
        logger.error(f"Error getting nearby events: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get nearby events: {str(e)}")


@router.get("/traffic-status", response_model=APIResponse)
async def get_traffic_status(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude"),
    radius_km: float = Query(10.0, ge=0.1, le=50.0, description="Search radius in kilometers")
):
    """
    Get current traffic status and disruptions
    """
    try:
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        # Get traffic level
        traffic_level = await swiss_transport_service.analyze_traffic_level(user_location)
        
        # Get disruptions
        all_disruptions = await swiss_transport_service.get_disruptions()
        
        # Filter disruptions by distance
        nearby_disruptions = []
        for disruption in all_disruptions:
            distance = _calculate_distance(user_location, disruption.location)
            if distance <= radius_km:
                disruption_data = disruption.dict()
                disruption_data["distance_km"] = round(distance, 2)
                nearby_disruptions.append(disruption_data)
        
        # Sort by distance
        nearby_disruptions.sort(key=lambda x: x["distance_km"])
        
        return APIResponse(
            success=True,
            message=f"Traffic status retrieved for {radius_km}km radius",
            data={
                "current_traffic_level": traffic_level.value,
                "disruptions": nearby_disruptions,
                "disruption_count": len(nearby_disruptions),
                "user_location": user_location.dict(),
                "search_radius_km": radius_km,
                "last_updated": datetime.now().isoformat()
            }
        )
        
    except Exception as e:
        logger.error(f"Error getting traffic status: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get traffic status: {str(e)}")


@router.get("/quick-stats", response_model=APIResponse)
async def get_quick_stats(
    lat: float = Query(..., ge=-90, le=90, description="User latitude"),
    lng: float = Query(..., ge=-180, le=180, description="User longitude")
):
    """
    Get quick statistics for the home screen bottom sheet
    """
    try:
        user_location = LocationModel(latitude=lat, longitude=lng)
        
        # Get counts and status
        nearby_events = await zurich_events_service.get_events_near_location(
            user_location, radius_km=5.0, limit=50
        )
        
        traffic_level = await swiss_transport_service.analyze_traffic_level(user_location)
        
        # Get real-time departures for transport info
        departures = await swiss_transport_service.get_realtime_departures(user_location)
        
        stats = {
            "events_nearby": len(nearby_events),
            "traffic_level": traffic_level.value,
            "traffic_description": _get_traffic_description(traffic_level),
            "next_departures": len(departures),
            "upcoming_events_today": len([e for e in nearby_events if e.start_time.date() == datetime.now().date()]),
            "location": user_location.dict()
        }
        
        return APIResponse(
            success=True,
            message="Quick stats retrieved successfully",
            data=stats
        )
        
    except Exception as e:
        logger.error(f"Error getting quick stats: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get quick stats: {str(e)}")


@router.get("/search", response_model=APIResponse)
async def search_locations_and_events(
    query: str = Query(..., min_length=2, description="Search query"),
    lat: Optional[float] = Query(None, ge=-90, le=90, description="User latitude for proximity"),
    lng: Optional[float] = Query(None, ge=-180, le=180, description="User longitude for proximity"),
    limit: int = Query(10, ge=1, le=50, description="Maximum results to return")
):
    """
    Search for events and locations based on query
    """
    try:
        results = {
            "events": [],
            "locations": [],
            "query": query
        }
        
        # Search events
        all_events = await zurich_events_service.get_events(limit=100)
        matching_events = []
        
        query_lower = query.lower()
        for event in all_events:
            if (query_lower in event.title.lower() or 
                (event.description and query_lower in event.description.lower()) or
                (event.location.address and query_lower in event.location.address.lower())):
                matching_events.append(event)
        
        # Sort by relevance (simple title match first)
        matching_events.sort(key=lambda x: 0 if query_lower in x.title.lower() else 1)
        
        # Limit results
        results["events"] = [event.dict() for event in matching_events[:limit]]
        
        # If user location provided, calculate distances
        if lat is not None and lng is not None:
            user_location = LocationModel(latitude=lat, longitude=lng)
            for event_data in results["events"]:
                event_location = LocationModel(
                    latitude=event_data["location"]["latitude"],
                    longitude=event_data["location"]["longitude"]
                )
                distance = _calculate_distance(user_location, event_location)
                event_data["distance_km"] = round(distance, 2)
            
            # Re-sort by distance if user location provided
            results["events"].sort(key=lambda x: x.get("distance_km", float('inf')))
        
        return APIResponse(
            success=True,
            message=f"Found {len(results['events'])} results for '{query}'",
            data=results
        )
        
    except Exception as e:
        logger.error(f"Error searching: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


# Helper functions
def _calculate_distance(loc1: LocationModel, loc2: LocationModel) -> float:
    """Calculate distance between two locations in kilometers"""
    import math
    
    lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
    lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
    
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return 6371 * c  # Earth radius in km


def _severity_to_traffic_level(severity: str) -> TrafficLevel:
    """Convert disruption severity to traffic level"""
    severity_map = {
        "low": TrafficLevel.LOW,
        "normal": TrafficLevel.MODERATE,
        "high": TrafficLevel.HIGH,
        "severe": TrafficLevel.SEVERE
    }
    return severity_map.get(severity.lower(), TrafficLevel.MODERATE)


def _traffic_level_to_color(level: TrafficLevel) -> str:
    """Convert traffic level to color code"""
    color_map = {
        TrafficLevel.LOW: "#4CAF50",      # Green
        TrafficLevel.MODERATE: "#FFC107", # Yellow
        TrafficLevel.HIGH: "#FF5722",     # Orange
        TrafficLevel.SEVERE: "#F44336"    # Red
    }
    return color_map.get(level, "#FFC107")


def _get_traffic_description(level: TrafficLevel) -> str:
    """Get human-readable traffic description"""
    descriptions = {
        TrafficLevel.LOW: "Traffic is flowing smoothly",
        TrafficLevel.MODERATE: "Some delays expected",
        TrafficLevel.HIGH: "Heavy traffic, plan extra time",
        TrafficLevel.SEVERE: "Severe delays, consider alternatives"
    }
    return descriptions.get(level, "Traffic information unavailable")
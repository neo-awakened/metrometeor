"""
Swiss Transport API Service
Integrates with transport.opendata.ch and opentransportdata.swiss
"""

import httpx
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import asyncio
from app.core.config import settings
from app.models import LocationModel, TrafficLevel, Disruption, RouteOption


logger = logging.getLogger(__name__)


class SwissTransportService:
    """Service for Swiss transport data integration"""
    
    def __init__(self):
        self.base_url = settings.OPENTRANSPORT_API_BASE
        self.disruptions_url = settings.DISRUPTIONS_API
        self.timeout = 30.0
        
    async def get_connections(
        self, 
        from_location: str, 
        to_location: str, 
        departure_time: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """Get connections between two locations"""
        try:
            params = {
                "from": from_location,
                "to": to_location,
                "limit": 5
            }
            
            if departure_time:
                params["date"] = departure_time.strftime("%Y-%m-%d")
                params["time"] = departure_time.strftime("%H:%M")
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/connections", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("connections", [])
                
        except Exception as e:
            logger.error(f"Error fetching connections: {str(e)}")
            return []
    
    async def get_nearby_stations(self, location: LocationModel, radius: int = 1000) -> List[Dict[str, Any]]:
        """Get nearby public transport stations"""
        try:
            params = {
                "x": location.longitude,
                "y": location.latitude,
                "limit": 10
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/locations", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("stations", [])
                
        except Exception as e:
            logger.error(f"Error fetching nearby stations: {str(e)}")
            return []
    
    async def get_station_board(self, station_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get departures from a station"""
        try:
            params = {
                "id": station_id,
                "limit": limit
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/stationboard", params=params)
                response.raise_for_status()
                
                data = response.json()
                return data.get("stationboard", [])
                
        except Exception as e:
            logger.error(f"Error fetching station board: {str(e)}")
            return []
    
    async def get_disruptions(self) -> List[Disruption]:
        """Get traffic disruptions from SIRI-SX data"""
        try:
            # Query the disruptions API
            params = {
                "resource_id": "siri-sx",
                "limit": 50
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(self.disruptions_url, params=params)
                response.raise_for_status()
                
                data = response.json()
                disruptions = []
                
                # Parse SIRI-SX data
                records = data.get("result", {}).get("records", [])
                for record in records:
                    try:
                        disruption = Disruption(
                            id=record.get("RecordedAtTime", str(datetime.now().timestamp())),
                            title=record.get("Summary", "Traffic Disruption"),
                            description=record.get("Description", ""),
                            location=LocationModel(
                                latitude=float(record.get("Latitude", 47.3769)),  # Default to Zurich
                                longitude=float(record.get("Longitude", 8.5417))
                            ),
                            severity=record.get("Severity", "normal"),
                            start_time=datetime.fromisoformat(
                                record.get("ValidityPeriod", {}).get("StartTime", datetime.now().isoformat())
                            ),
                            end_time=datetime.fromisoformat(
                                record.get("ValidityPeriod", {}).get("EndTime", 
                                (datetime.now() + timedelta(hours=1)).isoformat())
                            ) if record.get("ValidityPeriod", {}).get("EndTime") else None,
                            affected_routes=record.get("AffectedLines", [])
                        )
                        disruptions.append(disruption)
                    except Exception as e:
                        logger.warning(f"Error parsing disruption record: {str(e)}")
                        continue
                
                return disruptions
                
        except Exception as e:
            logger.error(f"Error fetching disruptions: {str(e)}")
            return []
    
    async def analyze_traffic_level(self, location: LocationModel) -> TrafficLevel:
        """Analyze traffic level based on nearby disruptions and transport data"""
        try:
            # Get nearby stations to assess congestion
            stations = await self.get_nearby_stations(location)
            disruptions = await self.get_disruptions()
            
            # Simple traffic level calculation
            nearby_disruptions = 0
            for disruption in disruptions:
                # Calculate distance (simple approximation)
                lat_diff = abs(disruption.location.latitude - location.latitude)
                lng_diff = abs(disruption.location.longitude - location.longitude)
                if lat_diff < 0.01 and lng_diff < 0.01:  # Roughly 1km
                    nearby_disruptions += 1
            
            # Determine traffic level
            if nearby_disruptions == 0:
                return TrafficLevel.LOW
            elif nearby_disruptions <= 2:
                return TrafficLevel.MODERATE
            elif nearby_disruptions <= 5:
                return TrafficLevel.HIGH
            else:
                return TrafficLevel.SEVERE
                
        except Exception as e:
            logger.error(f"Error analyzing traffic level: {str(e)}")
            return TrafficLevel.MODERATE
    
    async def get_route_options(
        self, 
        from_location: LocationModel, 
        to_location: LocationModel
    ) -> List[RouteOption]:
        """Get route options between two locations"""
        try:
            # Convert coordinates to location strings
            from_str = f"{from_location.latitude},{from_location.longitude}"
            to_str = f"{to_location.latitude},{to_location.longitude}"
            
            connections = await self.get_connections(from_str, to_str)
            
            route_options = []
            for i, connection in enumerate(connections[:3]):  # Limit to 3 options
                try:
                    duration = connection.get("duration", "00:30:00")
                    duration_parts = duration.split(":")
                    duration_minutes = int(duration_parts[1]) + (int(duration_parts[0]) * 60)
                    
                    route_option = RouteOption(
                        route_id=f"route_{i}",
                        duration_minutes=duration_minutes,
                        distance_km=connection.get("distance", 10.0),
                        traffic_level=await self.analyze_traffic_level(from_location),
                        description=f"Public transport via {connection.get('products', ['train'])[0] if connection.get('products') else 'public transport'}",
                        waypoints=[from_location, to_location],
                        estimated_cost=connection.get("price", 5.0)
                    )
                    route_options.append(route_option)
                except Exception as e:
                    logger.warning(f"Error parsing route option: {str(e)}")
                    continue
            
            return route_options
            
        except Exception as e:
            logger.error(f"Error getting route options: {str(e)}")
            return []
    
    async def get_realtime_departures(self, location: LocationModel) -> List[Dict[str, Any]]:
        """Get real-time departures near a location"""
        try:
            # Get nearby stations
            stations = await self.get_nearby_stations(location)
            
            if not stations:
                return []
            
            # Get departures from the closest station
            closest_station = stations[0]
            station_id = closest_station.get("id")
            
            if station_id:
                departures = await self.get_station_board(station_id)
                return departures
            
            return []
            
        except Exception as e:
            logger.error(f"Error getting real-time departures: {str(e)}")
            return []


# Global service instance
swiss_transport_service = SwissTransportService()
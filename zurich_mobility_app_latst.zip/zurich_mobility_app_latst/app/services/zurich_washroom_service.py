"""
Zurich Washroom Service
Service for managing and querying Zurich washroom data from CSV files
"""

import csv
import logging
import os
import re
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import math
import asyncio
from pathlib import Path

from app.models import (
    WashroomModel, 
    LocationModel, 
    WashroomType, 
    AccessibilityLevel,
    WashroomSearchRequest,
    WashroomResponse
)


logger = logging.getLogger(__name__)


class ZurichWashroomService:
    """Service for Zurich washroom data management"""
    
    def __init__(self):
        self.data_dir = Path(__file__).parent.parent.parent / "data"
        self.fixed_washrooms_file = "stzh.poi_zueriwc_view.csv"
        self.mobile_washrooms_file = "stzh.poi_zueriwc_mobil_view.csv"
        self._washrooms_cache: List[WashroomModel] = []
        self._cache_loaded = False
        
    async def load_washroom_data(self) -> List[WashroomModel]:
        """Load washroom data from CSV files"""
        if self._cache_loaded and self._washrooms_cache:
            return self._washrooms_cache
        
        try:
            washrooms = []
            
            # Load fixed washrooms
            fixed_washrooms = await self._load_fixed_washrooms()
            washrooms.extend(fixed_washrooms)
            
            # Load mobile washrooms
            mobile_washrooms = await self._load_mobile_washrooms()
            washrooms.extend(mobile_washrooms)
            
            self._washrooms_cache = washrooms
            self._cache_loaded = True
            
            logger.info(f"Loaded {len(washrooms)} washrooms from CSV files")
            return washrooms
            
        except Exception as e:
            logger.error(f"Error loading washroom data: {str(e)}")
            return []
    
    async def _load_fixed_washrooms(self) -> List[WashroomModel]:
        """Load fixed washrooms from CSV"""
        washrooms = []
        file_path = self.data_dir / self.fixed_washrooms_file
        
        if not file_path.exists():
            logger.warning(f"Fixed washrooms file not found: {file_path}")
            return washrooms
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    washroom = self._parse_fixed_washroom_row(row)
                    if washroom:
                        washrooms.append(washroom)
        
        except Exception as e:
            logger.error(f"Error reading fixed washrooms CSV: {str(e)}")
        
        return washrooms
    
    async def _load_mobile_washrooms(self) -> List[WashroomModel]:
        """Load mobile washrooms from CSV"""
        washrooms = []
        file_path = self.data_dir / self.mobile_washrooms_file
        
        if not file_path.exists():
            logger.warning(f"Mobile washrooms file not found: {file_path}")
            return washrooms
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                for row in reader:
                    washroom = self._parse_mobile_washroom_row(row)
                    if washroom:
                        washrooms.append(washroom)
        
        except Exception as e:
            logger.error(f"Error reading mobile washrooms CSV: {str(e)}")
        
        return washrooms
    
    def _parse_fixed_washroom_row(self, row: Dict[str, str]) -> Optional[WashroomModel]:
        """Parse a fixed washroom row from CSV"""
        try:
            # Extract coordinates from geometry
            geometry = row.get('geometry', '')
            lat, lng = self._extract_coordinates_from_geometry(geometry)
            
            if lat is None or lng is None:
                logger.warning(f"Invalid coordinates for washroom: {row.get('name', 'Unknown')}")
                return None
            
            # Determine washroom type
            washroom_type = self._determine_washroom_type(row.get('typ', ''), row.get('kategorie', ''))
            
            # Determine accessibility
            accessibility = self._determine_accessibility(row.get('typ', ''), row.get('hindernisfreiheit', ''))
            
            # Parse fees
            is_free = 'gebührenfrei' in row.get('gebuehren', '').lower()
            
            # Parse opening hours
            opening_hours = row.get('oeffnungsz', '')
            is_open_24h = '24' in opening_hours
            
            washroom = WashroomModel(
                id=row.get('poi_id', row.get('objectid', f"fixed_{len(self._washrooms_cache)}")),
                name=row.get('name', 'Unnamed Washroom'),
                address=row.get('adresse', ''),
                location=LocationModel(
                    latitude=lat,
                    longitude=lng,
                    address=row.get('adresse', '')
                ),
                washroom_type=washroom_type,
                accessibility=accessibility,
                is_free=is_free,
                is_open_24h=is_open_24h,
                opening_hours=opening_hours if opening_hours and opening_hours != 'n.a.' else None,
                description=row.get('bemerkung', '') or row.get('kommentar', ''),
                contact_info=row.get('tel', ''),
                district=row.get('kreis', ''),
                postal_code=row.get('plz', ''),
                last_updated=datetime.now()
            )
            
            return washroom
            
        except Exception as e:
            logger.warning(f"Error parsing fixed washroom row: {str(e)}")
            return None
    
    def _parse_mobile_washroom_row(self, row: Dict[str, str]) -> Optional[WashroomModel]:
        """Parse a mobile washroom row from CSV"""
        try:
            # Extract coordinates from geometry
            geometry = row.get('geometry', '')
            lat, lng = self._extract_coordinates_from_geometry(geometry)
            
            if lat is None or lng is None:
                logger.warning(f"Invalid coordinates for mobile washroom: {row.get('name', 'Unknown')}")
                return None
            
            # Mobile washrooms are typically not wheelchair accessible
            accessibility = AccessibilityLevel.NOT_WHEELCHAIR_ACCESSIBLE
            if 'rollstuhl' in row.get('kategorie', '').lower():
                accessibility = AccessibilityLevel.WHEELCHAIR_ACCESSIBLE
            
            # Determine mobile washroom type
            name = row.get('name', '').lower()
            if 'pissoir' in name:
                washroom_type = WashroomType.PISSOIR
            else:
                washroom_type = WashroomType.MOBILE
            
            # Mobile washrooms are typically free
            is_free = True
            
            # Parse seasonal information
            description = row.get('bemerkung', '')
            is_seasonal = 'april' in description.lower() and 'oktober' in description.lower()
            
            washroom = WashroomModel(
                id=row.get('poi_id', f"mobile_{row.get('objectid', len(self._washrooms_cache))}"),
                name=row.get('name', 'Mobile Washroom'),
                address=row.get('name', ''),  # Mobile washrooms use name as address
                location=LocationModel(
                    latitude=lat,
                    longitude=lng,
                    address=row.get('name', '')
                ),
                washroom_type=washroom_type,
                accessibility=accessibility,
                is_free=is_free,
                is_open_24h=not is_seasonal,  # Seasonal ones are not 24h
                opening_hours="Seasonal (April - October)" if is_seasonal else "24h",
                description=description,
                contact_info=row.get('tel', ''),
                district=None,  # Mobile washrooms don't have fixed districts
                postal_code=row.get('plz', ''),
                last_updated=datetime.now()
            )
            
            return washroom
            
        except Exception as e:
            logger.warning(f"Error parsing mobile washroom row: {str(e)}")
            return None
    
    def _extract_coordinates_from_geometry(self, geometry: str) -> Tuple[Optional[float], Optional[float]]:
        """Extract latitude and longitude from geometry string"""
        try:
            # Extract coordinates from POINT (x y) format
            match = re.search(r'POINT \(([0-9.]+) ([0-9.]+)\)', geometry)
            if match:
                x, y = float(match.group(1)), float(match.group(2))
                # Convert Swiss coordinates (CH1903+) to WGS84
                lat, lng = self._convert_swiss_to_wgs84(x, y)
                return lat, lng
        except Exception as e:
            logger.warning(f"Error extracting coordinates: {str(e)}")
        
        return None, None
    
    def _convert_swiss_to_wgs84(self, x: float, y: float) -> Tuple[float, float]:
        """Convert Swiss CH1903+ coordinates to WGS84 (approximate conversion)"""
        try:
            # Simplified conversion for Swiss coordinates
            # For precise conversion, use pyproj library
            
            # Convert from meters to decimal degrees (approximate)
            # Swiss coordinate system origin
            x_origin = 2600000
            y_origin = 1200000
            
            # Approximate conversion factors
            lat = 46.95 + (y - y_origin) / 111320.0
            lng = 7.44 + (x - x_origin) / (111320.0 * math.cos(math.radians(lat)))
            
            return lat, lng
            
        except Exception as e:
            logger.warning(f"Error converting coordinates: {str(e)}")
            return 47.3769, 8.5417  # Default to Zurich center
    
    def _determine_washroom_type(self, typ: str, kategorie: str) -> WashroomType:
        """Determine washroom type from CSV data"""
        typ_lower = typ.lower()
        kategorie_lower = kategorie.lower()
        
        if 'pissoir' in typ_lower or 'pissoir' in kategorie_lower:
            return WashroomType.PISSOIR
        elif 'mobil' in kategorie_lower:
            return WashroomType.MOBILE
        else:
            return WashroomType.FIXED
    
    def _determine_accessibility(self, typ: str, hindernisfreiheit: str) -> AccessibilityLevel:
        """Determine accessibility level"""
        text = f"{typ} {hindernisfreiheit}".lower()
        
        if 'nicht rollstuhl' in text or 'nicht rollstuhlgängig' in text:
            return AccessibilityLevel.NOT_WHEELCHAIR_ACCESSIBLE
        elif 'rollstuhl' in text:
            return AccessibilityLevel.WHEELCHAIR_ACCESSIBLE
        else:
            return AccessibilityLevel.NOT_WHEELCHAIR_ACCESSIBLE  # Default assumption
    
    async def search_washrooms(self, request: WashroomSearchRequest) -> WashroomResponse:
        """Search for washrooms based on criteria"""
        try:
            # Load data if not cached
            all_washrooms = await self.load_washroom_data()
            
            # Filter washrooms based on search criteria
            filtered_washrooms = []
            
            for washroom in all_washrooms:
                # Calculate distance
                distance = self._calculate_distance(request.location, washroom.location)
                
                # Check if within radius
                if distance > request.radius_meters / 1000.0:  # Convert to km
                    continue
                
                # Apply filters
                if request.washroom_type and washroom.washroom_type != request.washroom_type:
                    continue
                
                if request.accessibility_required and washroom.accessibility != AccessibilityLevel.WHEELCHAIR_ACCESSIBLE:
                    continue
                
                if request.free_only and not washroom.is_free:
                    continue
                
                if request.open_24h_only and not washroom.is_open_24h:
                    continue
                
                # Add distance to washroom
                washroom.distance_from_user = distance
                filtered_washrooms.append(washroom)
            
            # Sort by distance
            filtered_washrooms.sort(key=lambda w: w.distance_from_user or float('inf'))
            
            # Create response
            filters_applied = {
                "radius_meters": request.radius_meters,
                "washroom_type": request.washroom_type.value if request.washroom_type else None,
                "accessibility_required": request.accessibility_required,
                "free_only": request.free_only,
                "open_24h_only": request.open_24h_only
            }
            
            response = WashroomResponse(
                washrooms=filtered_washrooms,
                total_count=len(filtered_washrooms),
                search_radius=request.radius_meters,
                center_location=request.location,
                filters_applied=filters_applied
            )
            
            return response
            
        except Exception as e:
            logger.error(f"Error searching washrooms: {str(e)}")
            return WashroomResponse(
                washrooms=[],
                total_count=0,
                search_radius=request.radius_meters,
                center_location=request.location,
                filters_applied={}
            )
    
    def _calculate_distance(self, loc1: LocationModel, loc2: LocationModel) -> float:
        """Calculate distance between two locations in kilometers"""
        # Haversine formula
        lat1, lon1 = math.radians(loc1.latitude), math.radians(loc1.longitude)
        lat2, lon2 = math.radians(loc2.latitude), math.radians(loc2.longitude)
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        # Radius of Earth in kilometers
        r = 6371
        
        return c * r
    
    async def get_washroom_by_id(self, washroom_id: str) -> Optional[WashroomModel]:
        """Get a specific washroom by ID"""
        try:
            all_washrooms = await self.load_washroom_data()
            for washroom in all_washrooms:
                if washroom.id == washroom_id:
                    return washroom
            return None
        except Exception as e:
            logger.error(f"Error getting washroom by ID: {str(e)}")
            return None
    
    async def get_washroom_statistics(self) -> Dict[str, int]:
        """Get statistics about washrooms"""
        try:
            all_washrooms = await self.load_washroom_data()
            
            stats = {
                "total": len(all_washrooms),
                "fixed": len([w for w in all_washrooms if w.washroom_type == WashroomType.FIXED]),
                "mobile": len([w for w in all_washrooms if w.washroom_type == WashroomType.MOBILE]),
                "pissoir": len([w for w in all_washrooms if w.washroom_type == WashroomType.PISSOIR]),
                "wheelchair_accessible": len([w for w in all_washrooms if w.accessibility == AccessibilityLevel.WHEELCHAIR_ACCESSIBLE]),
                "free": len([w for w in all_washrooms if w.is_free]),
                "open_24h": len([w for w in all_washrooms if w.is_open_24h])
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting washroom statistics: {str(e)}")
            return {}


# Global service instance
zurich_washroom_service = ZurichWashroomService()
"""
Services package initialization
"""
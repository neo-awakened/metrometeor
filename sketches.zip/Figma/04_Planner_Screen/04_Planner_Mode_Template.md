# Planner Mode - Group Organization & Event Planning

## Screen Overview
Comprehensive group planning interface for organizing festival visits, coordinating with friends, managing group activities, and real-time location sharing.

## Layout Structure

### Header Bar
- **Height**: 96px
- **Back arrow** (left)
- **Title**: "Group Planner" or Group name
- **Group settings** (right, gear icon)
- **Invite members** (right, plus icon)

### Tab Navigation
- **Height**: 56px
- **4 tabs**:
  1. "My Groups" (active)
  2. "Create Event"
  3. "Invitations"
  4. "Shared Plans"

## My Groups Tab

### Create New Group Card
- **Height**: 120px
- **Prominent placement** at top
- **Background**: Gradient blue
- **Content**:
  - "Create New Group" (white text, 18sp)
  - "Plan your next festival adventure" (subtitle)
  - Plus icon (large, white)

### Active Groups List
Each group card (Height: 100px):
- **Group avatar/image** (left, 60x60px, circular)
- **Group details** (center):
  - Group name (16sp, bold)
  - Member count (14sp, gray)
  - Next event/meetup (14sp, blue)
  - Last activity (12sp, light gray)
- **Status indicator** (right):
  - Active members count
  - Notification badge (if updates)

## Create Event Tab

### Event Type Selection
- **Grid layout** (2x2):
  - "Festival/Concert" (music icon)
  - "Food Event" (utensils icon)
  - "Sports Event" (sports icon)
  - "Custom Event" (calendar icon)

### Event Details Form
- **Event name** input field
- **Date & time** picker (with calendar widget)
- **Location** input with map selection
- **Description** text area (expandable)
- **Privacy settings**:
  - "Public" (anyone can join)
  - "Friends only"
  - "Private" (invite only)

### Group Features Setup
- **Organizer tools** toggle switches:
  - Real-time location sharing
  - Group chat
  - Expense splitting
  - Meeting point coordination
  - Emergency contact sharing

## Group Detail View (When Group Selected)

### Group Header
- **Cover image** (full width, 160px height)
- **Group info overlay**:
  - Group name (24sp, white text with shadow)
  - Member count + "See all members" link
  - Group description (expandable)

### Member Management Section

#### Active Members List
- **Horizontal scroll** member avatars
- **Online status indicators** (green dot)
- **Tap to view member profile**

#### Member Actions Bar
- **"Add Members"** button (primary blue)
- **"Manage Roles"** (organizers only)
- **"Group Settings"** (organizers only)

### Real-time Location Sharing

#### Map View (Interactive)
- **Height**: 240px
- **Group members' locations** (colored pins)
- **Meeting points** (star icons)
- **Suggested gathering spots** (based on member locations)
- **Privacy controls** (who can see your location)

#### Location Controls
- **Share location toggle** (on/off switch)
- **Sharing duration** dropdown:
  - "For this event only"
  - "Next 4 hours"
  - "Until I turn it off"
- **Accuracy level**: Exact vs. Approximate area

### Event Planning Tools

#### Shared Itinerary
- **Timeline view** of planned activities
- **Collaborative editing** (multiple people can add items)
- **Vote on activities** (thumbs up/down)
- **Time blocks**:
  - Travel time to venue
  - Event sessions/performances
  - Meal breaks
  - Meeting points

#### Group Chat Integration
- **Chat panel** (expandable from bottom)
- **Quick message templates**:
  - "I'm running late"
  - "Meet at main entrance"
  - "Emergency - need help"
- **Location sharing buttons** in chat
- **Photo/video sharing** from event

### Coordination Features

#### Meeting Points
- **Set primary meeting point** (with photo/description)
- **Backup meeting locations**
- **"Find my group" button** (shows distance/direction to meeting point)
- **Check-in system** (members mark when they arrive)

#### Emergency Features
- **Emergency contact list** (shared among group)
- **"Send location to all"** quick button
- **Group emergency protocol** (predefined actions)
- **One-tap "I'm safe"** broadcast

### Expense Tracking (Optional Module)
- **Shared expenses** (tickets, food, transport)
- **Bill splitting calculator**
- **Payment tracking** (who owes what)
- **Receipt photo uploads**

## Organizer-Specific Features

### Group Management Dashboard
- **Member overview** with status indicators
- **Event timeline** management
- **Announcement broadcast** tools
- **Group statistics** (attendance, engagement)

### Advanced Planning Tools
- **Group size optimization** for venues
- **Transport coordination** (carpooling, bus booking)
- **Accommodation planning** (shared rooms/houses)
- **Ticket group buying** coordination

## Invitations Tab

### Pending Invitations
- **Invitation cards** with event previews
- **Accept/Decline** buttons
- **"Maybe"** option with notification settings
- **View group details** before joining

### Sent Invitations
- **Track invitation status**:
  - Sent (gray)
  - Delivered (blue)
  - Opened (yellow)
  - Responded (green)

## Interactive Elements & Actions

### Contextual Actions
- **Long-press member**: Quick actions (message, call, remove)
- **Swipe group card**: Quick settings, leave group
- **Tap location pin**: Member info, send message, get directions

### Real-time Updates
- **Live location updates** (every 30 seconds when sharing)
- **Member status changes** (online/offline, arrived/left)
- **New messages/announcements** (push notifications)
- **Group activity feed** (joined, left, location shared)

## Privacy & Security

### Privacy Controls
- **Location sharing granularity**:
  - Exact location
  - General area (500m radius)
  - Venue only
  - Off
- **Who can find your group** settings
- **Member invitation permissions**

### Safety Features
- **Block/report members**
- **Group moderator tools**
- **Location history** (only you can see)
- **Emergency contact integration**

## States & Animations

### Loading States
- **Skeleton placeholders** for group cards
- **Map loading** with animated pins
- **Member status** loading indicators

### Empty States
- **No groups**: Illustration with "Create your first group"
- **No active members**: "Invite friends to get started"
- **No location data**: "Enable location to see group members"

### Error States
- **Network error**: Retry with cached data
- **Location permission denied**: Settings redirect
- **Group full**: Waitlist option

## Color Scheme
- **Organizer elements**: #FF5722 (Orange)
- **Member elements**: #2196F3 (Blue)
- **Online status**: #4CAF50 (Green)
- **Offline status**: #9E9E9E (Gray)
- **Emergency elements**: #F44336 (Red)
- **Meeting points**: #9C27B0 (Purple)

## Typography
- **Group names**: Roboto Medium 18sp
- **Member names**: Roboto Regular 14sp
- **Event titles**: Roboto Medium 16sp
- **Status text**: Roboto Regular 12sp
- **Emergency text**: Roboto Bold 14sp

## Spacing & Layout
- **Card padding**: 16dp
- **Member avatar spacing**: 8dp horizontal
- **Section margins**: 20dp vertical
- **Map controls**: 12dp from edges
- **Button spacing**: 12dp between action buttons
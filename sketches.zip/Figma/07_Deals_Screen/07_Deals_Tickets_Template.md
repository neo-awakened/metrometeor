# Deals & Tickets Screen - Saver Passes, Tickets & Hotel Suggestions

## Screen Overview
Comprehensive deals and booking interface that suggests money-saving passes, event tickets, accommodation options, and travel deals based on user's planned events and location.

## Layout Structure

### Header Bar
- **Height**: 96px
- **Back arrow** (left)
- **Title**: "Deals & Savings"
- **Wishlist icon** (right, heart)
- **Filter icon** (right, filter funnel)

### Personalized Deals Banner
- **Height**: 140px
- **Background**: Gradient (purple to blue)
- **Content**:
  - "Save up to 40% on your festival trip"
  - User's upcoming events counter: "3 events this month"
  - "See personalized deals" CTA button

### Deal Categories (Horizontal Scroll)
- **Height**: 60px
- **Category chips**:
  - "All Deals" (selected)
  - "Event Tickets"
  - "Transport Passes"
  - "Accommodation"
  - "Food & Drinks"
  - "Merchandise"

## Main Content Areas

### Smart Suggestions Section

#### AI-Powered Recommendations
- **Header**: "Recommended for You" (18sp, bold)
- **Based on**: User's saved events, location, travel history

#### Multi-Day Pass Cards
Each pass card (Height: 180px):
- **Card background**: Event-themed gradient
- **Pass image** (left, 100x120px)
- **Pass details** (right):
  - Pass name (16sp, bold) - "Festival Weekend Pass"
  - Validity period (14sp) - "Valid for 3 days"
  - Included events (12sp) - "Access to 5 festivals"
  - **Original price** (strikethrough): $150
  - **Deal price** (large, bold): $89
  - **Savings badge**: "Save $61 (41%)"
  - "Limited time" urgency indicator

### Event Tickets Section

#### Upcoming Events You're Attending
- **Header**: "Your Events" (16sp, bold)
- **Connected to saved/planned events**

#### Event Ticket Cards
Each ticket card (Height: 140px):
- **Event image** (left, 80x100px)
- **Event info** (center):
  - Event name (16sp, bold)
  - Date & time (14sp)
  - Venue name (14sp, gray)
  - Ticket type options dropdown
- **Pricing** (right):
  - Early bird price (if available)
  - Regular price
  - VIP options
  - Group discounts indicator

#### Ticket Comparison Tool
- **Side-by-side** price comparison
- **Different vendors** (official, resellers, marketplace)
- **Price history** graph (past 30 days)
- **Price alerts** toggle for each event

### Transportation Deals

#### Public Transport Passes
- **City transport cards**:
  - "3-Day Metro Pass - $25" (vs. individual rides $45)
  - "Festival Shuttle Package - $15"
  - "Airport Express Bundle - $30"
- **Multi-city passes** for festival tours
- **Group booking discounts**

#### Ride-sharing & Car Rentals
- **Promotional codes** for ride-sharing apps
- **Car rental deals** for multi-day events
- **Parking pass** discounts near venues
- **Carpooling** coordination with other attendees

### Accommodation Suggestions

#### Hotel Deals Near Events
Each hotel card (Height: 160px):
- **Hotel image** (left, 100x120px)
- **Hotel details** (center):
  - Hotel name & star rating
  - Distance from event venue
  - Check-in/out dates (auto-filled from events)
  - Room type options
  - Amenities icons (WiFi, breakfast, pool)
- **Pricing** (right):
  - **Deal price** (large, bold)
  - Original price (strikethrough)
  - "Book now" button
  - Cancellation policy

#### Alternative Accommodations
- **Hostels** (budget option)
- **Vacation rentals** (Airbnb style)
- **Festival camping** packages
- **Group accommodation** (for large groups)

#### Smart Booking Features
- **Price tracking** for selected hotels
- **Bundle deals** (hotel + ticket packages)
- **Last-minute deals** notifications
- **Group booking** coordination tools

### Food & Beverage Deals

#### Festival Food Passes
- **Pre-paid meal credits** at discounted rates
- **VIP dining** packages
- **Local restaurant** deals near venues
- **Group meal** bookings with discounts

#### Drink Packages
- **Festival beverage** packages
- **Bar crawl** deals in event areas
- **Coffee shop** chains near venues
- **Happy hour** specials timing

### Package Deals & Bundles

#### Complete Festival Packages
- **All-inclusive** deals combining:
  - Event tickets
  - Accommodation (2-3 nights)
  - Transportation passes
  - Meal credits
  - Merchandise vouchers
- **Savings breakdown** showing individual vs. bundle pricing
- **Customizable packages** (add/remove components)

#### Group Packages
- **Friends group** discounts (4+ people)
- **Family packages** (age-appropriate pricing)
- **Corporate group** rates
- **Student discounts** with verification

### Loyalty & Rewards

#### Loyalty Program Integration
- **Points earning** from purchases
- **Tier benefits** (Bronze, Silver, Gold)
- **Exclusive deals** for members
- **Referral bonuses** for inviting friends

#### Cashback & Credits
- **Cashback percentage** on different categories
- **App credits** for future purchases
- **Partner loyalty programs** integration
- **Credit card** reward optimization

## Deal Discovery Features

### Price Alerts & Notifications
- **Price drop** alerts for saved items
- **Deal expiration** warnings
- **New deal** notifications based on interests
- **Group member** sharing (when someone finds a deal)

### Comparison Tools
- **Price comparison** across multiple vendors
- **Review aggregation** from different sources
- **Photo galleries** from multiple angles
- **Cancellation policy** comparison

### Social Features
- **Friend recommendations** - "John saved $50 on this hotel"
- **Group deals** - coordinate purchases with friends
- **Deal sharing** - send deals to group members
- **Review system** - rate deals and vendors

## Interactive Elements

### Search & Filters
- **Advanced filters**:
  - Price range slider
  - Date range picker
  - Distance from events
  - Rating threshold
  - Amenities checkboxes
  - Deal type (percentage off, fixed amount, bundle)

### Booking Flow
- **Quick booking** for simple purchases
- **Detailed booking** with customization
- **Group booking** coordinator
- **Split payment** options for groups

### Wishlist & Favorites
- **Save deals** for later
- **Price tracking** on saved items
- **Wishlist sharing** with friends
- **Auto-purchase** when price drops below threshold

## Payment & Security

### Payment Options
- **Multiple payment methods** (cards, digital wallets, bank transfer)
- **Split payment** among group members
- **Payment scheduling** (pay now vs. pay later)
- **Currency conversion** for international events

### Security Features
- **Secure payment** processing
- **Purchase protection** guarantees
- **Refund policies** clearly displayed
- **Fraud protection** monitoring

## Visual Design

### Color Scheme
- **Deal highlights**: #FF5722 (Orange)
- **Savings badges**: #4CAF50 (Green)
- **Price**: #F44336 (Red for discounts)
- **Original price**: #9E9E9E (Gray strikethrough)
- **Premium/VIP**: #9C27B0 (Purple)
- **Limited time**: #FF9800 (Amber)

### Deal Indicators
- **Savings percentage**: Green circular badge
- **Limited time**: Pulsing orange indicator
- **Almost sold out**: Red warning badge
- **New deal**: Blue "NEW" badge
- **Exclusive**: Gold "EXCLUSIVE" badge

### Price Display
- **Deal price**: Large, bold, colored text
- **Original price**: Smaller, strikethrough, gray
- **Savings amount**: Green text with "Save $X"
- **Percentage off**: Green badge with "X% OFF"

## States & Behaviors

### Loading States
- **Skeleton cards** while fetching deals
- **Price loading** indicators
- **Image lazy loading** with placeholders

### Empty States
- **No deals found**: Illustration with filter suggestions
- **No saved deals**: "Start browsing to save deals"
- **Expired deals**: Option to find similar current deals

### Error States
- **Network error**: Retry with cached deals
- **Booking error**: Alternative options
- **Payment failed**: Multiple retry options

## Accessibility Features

### Visual Accessibility
- **High contrast** for price information
- **Large text** support
- **Color-blind friendly** savings indicators
- **Screen reader** optimized content

### Motor Accessibility
- **Large touch targets** for booking buttons
- **Voice search** for deals
- **Switch control** support
- **Gesture shortcuts** for common actions

## Typography
- **Deal titles**: Roboto Medium 16sp
- **Prices**: Roboto Bold 18sp
- **Savings**: Roboto Bold 14sp (green)
- **Details**: Roboto Regular 14sp
- **Captions**: Roboto Regular 12sp

## Spacing & Layout
- **Card padding**: 16dp
- **Price section**: 12dp margins
- **Button spacing**: 16dp minimum
- **Section spacing**: 24dp vertical
- **Deal badges**: 8dp margin from corners
- **Touch targets**: Minimum 48dp for all interactive elements
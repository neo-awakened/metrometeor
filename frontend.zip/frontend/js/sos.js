// SOS module for handling emergency services functionality
class SOSManager {
    constructor() {
        this.emergencyContacts = [];
        this.locationSharingEnabled = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadEmergencyContacts();
        this.loadEmergencyInfo();
    }

    setupEventListeners() {
        // Emergency service buttons
        const policeBtn = document.getElementById('call-police');
        const medicalBtn = document.getElementById('call-medical');
        const fireBtn = document.getElementById('call-fire');
        
        if (policeBtn) {
            policeBtn.addEventListener('click', () => this.callEmergencyService('police'));
        }
        
        if (medicalBtn) {
            medicalBtn.addEventListener('click', () => this.callEmergencyService('medical'));
        }
        
        if (fireBtn) {
            fireBtn.addEventListener('click', () => this.callEmergencyService('fire'));
        }
        
        // Add contact button
        const addContactBtn = document.getElementById('add-contact-btn');
        if (addContactBtn) {
            addContactBtn.addEventListener('click', () => this.showAddContactModal());
        }
        
        // Location sharing toggle
        const locationToggle = document.getElementById('location-sharing-toggle');
        if (locationToggle) {
            locationToggle.addEventListener('change', (e) => {
                this.updateLocationSharing(e.target.checked);
            });
        }
    }

    callEmergencyService(serviceType) {
        const service = CONFIG.EMERGENCY_SERVICES[serviceType];
        if (!service) return;
        
        const serviceName = serviceType.charAt(0).toUpperCase() + serviceType.slice(1);
        
        if (confirm(`Call ${serviceName} (${service.number})?\n\nThis will dial the emergency number for ${serviceName} services.`)) {
            // In a real app, this would actually place the call
            // For web apps, we can't directly dial, but we can provide the number
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(service.number).then(() => {
                    ToastManager.show(`${serviceName} number (${service.number}) copied to clipboard`, 'success');
                }).catch(() => {
                    this.showEmergencyNumberModal(serviceName, service.number);
                });
            } else {
                this.showEmergencyNumberModal(serviceName, service.number);
            }
            
            // Log emergency call attempt
            console.log(`Emergency call attempted: ${serviceName} (${service.number})`);
            
            // If location sharing is enabled, share current location
            if (this.locationSharingEnabled && mapService.userLocation) {
                this.shareLocationWithContacts('emergency');
            }
        }
    }

    showEmergencyNumberModal(serviceName, number) {
        const modalHTML = `
            <div class="modal active" id="emergency-number-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Emergency Contact</h3>
                        <button class="modal-close" onclick="ModalManager.hide('emergency-number-modal')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="emergency-number-display">
                            <h2>${serviceName}</h2>
                            <div class="number-display">
                                <span class="emergency-number">${number}</span>
                                <button class="copy-btn" onclick="sosManager.copyToClipboard('${number}')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                            <p>Please dial this number for ${serviceName.toLowerCase()} emergency services.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                ToastManager.show('Number copied to clipboard', 'success');
                ModalManager.hide('emergency-number-modal');
            }).catch((error) => {
                console.error('Failed to copy to clipboard:', error);
                ToastManager.show('Failed to copy number', 'error');
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                ToastManager.show('Number copied to clipboard', 'success');
                ModalManager.hide('emergency-number-modal');
            } catch (error) {
                console.error('Failed to copy to clipboard:', error);
                ToastManager.show('Failed to copy number', 'error');
            }
            document.body.removeChild(textArea);
        }
    }

    async loadEmergencyContacts() {
        try {
            const data = await apiService.getEmergencyContacts();
            this.emergencyContacts = data.contacts || [];
        } catch (error) {
            console.error('Failed to load emergency contacts:', error);
            // Load mock contacts for demonstration
            this.emergencyContacts = [
                {
                    id: 'contact1',
                    name: 'John Doe',
                    phone_number: '+41 79 123 4567',
                    relationship: 'Family',
                    is_primary: true
                },
                {
                    id: 'contact2', 
                    name: 'Jane Smith',
                    phone_number: '+41 79 987 6543',
                    relationship: 'Friend',
                    is_primary: false
                }
            ];
        }
        
        this.renderEmergencyContacts();
    }

    async loadEmergencyInfo() {
        try {
            const data = await apiService.getEmergencyInfo();
            this.locationSharingEnabled = data.location_sharing_enabled || false;
            
            // Update location sharing toggle
            const toggle = document.getElementById('location-sharing-toggle');
            if (toggle) {
                toggle.checked = this.locationSharingEnabled;
            }
        } catch (error) {
            console.error('Failed to load emergency info:', error);
        }
    }

    renderEmergencyContacts() {
        const container = document.getElementById('emergency-contacts-list');
        if (!container) return;

        if (this.emergencyContacts.length === 0) {
            container.innerHTML = `
                <div class="no-contacts">
                    <i class="fas fa-address-book"></i>
                    <p>No emergency contacts added yet.</p>
                    <p>Add trusted contacts who can be reached in case of emergency.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.emergencyContacts.map(contact => this.createContactItem(contact)).join('');
    }

    createContactItem(contact) {
        return `
            <div class="contact-item" data-contact-id="${contact.id}">
                <div class="contact-info">
                    <h4>
                        ${contact.name}
                        ${contact.is_primary ? '<span class="primary-badge"><i class="fas fa-star"></i> Primary</span>' : ''}
                    </h4>
                    <p class="contact-phone">
                        <i class="fas fa-phone"></i>
                        ${contact.phone_number}
                    </p>
                    <p class="contact-relationship">
                        <i class="fas fa-heart"></i>
                        ${contact.relationship}
                    </p>
                </div>
                <div class="contact-actions">
                    <button class="contact-btn" onclick="sosManager.callContact('${contact.id}')" title="Call">
                        <i class="fas fa-phone"></i>
                    </button>
                    <button class="contact-btn" onclick="sosManager.messageContact('${contact.id}')" title="Message">
                        <i class="fas fa-sms"></i>
                    </button>
                    <button class="contact-btn" onclick="sosManager.shareLocationWithContact('${contact.id}')" title="Share Location">
                        <i class="fas fa-map-marker-alt"></i>
                    </button>
                    <button class="contact-btn danger" onclick="sosManager.removeContact('${contact.id}')" title="Remove">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }

    showAddContactModal() {
        const modalHTML = `
            <div class="modal active" id="add-contact-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Add Emergency Contact</h3>
                        <button class="modal-close" onclick="ModalManager.hide('add-contact-modal')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="add-contact-form">
                            <div class="form-group">
                                <label for="contact-name">Name *</label>
                                <input type="text" id="contact-name" required maxlength="50" placeholder="Enter contact name">
                            </div>
                            
                            <div class="form-group">
                                <label for="contact-phone">Phone Number *</label>
                                <input type="tel" id="contact-phone" required placeholder="+41 79 123 4567">
                            </div>
                            
                            <div class="form-group">
                                <label for="contact-relationship">Relationship *</label>
                                <select id="contact-relationship" required>
                                    <option value="">Select relationship</option>
                                    <option value="Family">Family</option>
                                    <option value="Friend">Friend</option>
                                    <option value="Colleague">Colleague</option>
                                    <option value="Neighbor">Neighbor</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" id="contact-primary">
                                    Set as primary emergency contact
                                </label>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="secondary-btn" onclick="ModalManager.hide('add-contact-modal')">
                                    Cancel
                                </button>
                                <button type="submit" class="primary-btn">
                                    <i class="fas fa-plus"></i>
                                    Add Contact
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Setup form submission
        const form = document.getElementById('add-contact-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addContact();
            });
        }
    }

    async addContact() {
        const nameInput = document.getElementById('contact-name');
        const phoneInput = document.getElementById('contact-phone');
        const relationshipInput = document.getElementById('contact-relationship');
        const primaryInput = document.getElementById('contact-primary');
        
        if (!nameInput?.value.trim() || !phoneInput?.value.trim() || !relationshipInput?.value) {
            ToastManager.show('Please fill in all required fields', 'error');
            return;
        }
        
        if (!Utils.isValidPhone(phoneInput.value)) {
            ToastManager.show('Please enter a valid phone number', 'error');
            return;
        }
        
        const contactData = {
            name: nameInput.value.trim(),
            phone_number: phoneInput.value.trim(),
            relationship: relationshipInput.value,
            is_primary: primaryInput?.checked || false
        };
        
        try {
            LoadingManager.show('Adding contact...');
            
            // In a real app, this would call the API
            // const newContact = await apiService.addEmergencyContact(contactData);
            
            // For demo, create a mock contact
            const newContact = {
                id: 'contact' + Date.now(),
                ...contactData
            };
            
            this.emergencyContacts.push(newContact);
            this.renderEmergencyContacts();
            
            ModalManager.hide('add-contact-modal');
            ToastManager.show('Emergency contact added successfully!', 'success');
            
        } catch (error) {
            console.error('Failed to add contact:', error);
            Utils.handleError(error, 'Adding emergency contact');
        } finally {
            LoadingManager.hide();
        }
    }

    callContact(contactId) {
        const contact = this.emergencyContacts.find(c => c.id === contactId);
        if (!contact) return;
        
        if (confirm(`Call ${contact.name} (${contact.phone_number})?`)) {
            // Copy number to clipboard since web apps can't directly dial
            if (navigator.clipboard) {
                navigator.clipboard.writeText(contact.phone_number).then(() => {
                    ToastManager.show(`${contact.name}'s number copied to clipboard`, 'success');
                }).catch(() => {
                    ToastManager.show(`Call ${contact.name} at ${contact.phone_number}`, 'info');
                });
            } else {
                ToastManager.show(`Call ${contact.name} at ${contact.phone_number}`, 'info');
            }
        }
    }

    messageContact(contactId) {
        const contact = this.emergencyContacts.find(c => c.id === contactId);
        if (!contact) return;
        
        // In a real app, this would open SMS app or messaging interface
        ToastManager.show(`SMS feature for ${contact.name} coming soon!`, 'info');
    }

    shareLocationWithContact(contactId) {
        const contact = this.emergencyContacts.find(c => c.id === contactId);
        if (!contact) return;
        
        if (!mapService.userLocation) {
            ToastManager.show('Location not available. Please enable location services.', 'error');
            return;
        }
        
        const location = mapService.userLocation;
        const message = `My current location: https://maps.google.com/?q=${location.latitude},${location.longitude}`;
        
        if (navigator.clipboard) {
            navigator.clipboard.writeText(message).then(() => {
                ToastManager.show(`Location shared with ${contact.name}`, 'success');
            }).catch(() => {
                ToastManager.show(`Share this location with ${contact.name}: ${message}`, 'info');
            });
        } else {
            ToastManager.show(`Share this location with ${contact.name}: ${message}`, 'info');
        }
    }

    async removeContact(contactId) {
        const contact = this.emergencyContacts.find(c => c.id === contactId);
        if (!contact) return;
        
        if (confirm(`Remove ${contact.name} from emergency contacts?`)) {
            try {
                // In a real app, this would call the API
                // await apiService.deleteEmergencyContact(contactId);
                
                this.emergencyContacts = this.emergencyContacts.filter(c => c.id !== contactId);
                this.renderEmergencyContacts();
                
                ToastManager.show('Emergency contact removed', 'success');
                
            } catch (error) {
                console.error('Failed to remove contact:', error);
                Utils.handleError(error, 'Removing emergency contact');
            }
        }
    }

    async updateLocationSharing(enabled) {
        try {
            // In a real app, this would update the server
            // await apiService.updateEmergencyInfo({ location_sharing_enabled: enabled });
            
            this.locationSharingEnabled = enabled;
            
            ToastManager.show(
                enabled ? 'Location sharing enabled' : 'Location sharing disabled',
                'success'
            );
            
            if (enabled && !mapService.userLocation) {
                // Request location permission
                mapService.getUserLocation().catch(() => {
                    ToastManager.show('Please enable location services to share your location', 'warning');
                });
            }
            
        } catch (error) {
            console.error('Failed to update location sharing:', error);
            Utils.handleError(error, 'Updating location sharing');
            
            // Revert toggle state
            const toggle = document.getElementById('location-sharing-toggle');
            if (toggle) {
                toggle.checked = this.locationSharingEnabled;
            }
        }
    }

    shareLocationWithContacts(reason = 'manual') {
        if (!this.locationSharingEnabled || !mapService.userLocation) {
            return;
        }
        
        const location = mapService.userLocation;
        const message = reason === 'emergency' 
            ? `EMERGENCY - My current location: https://maps.google.com/?q=${location.latitude},${location.longitude}`
            : `My current location: https://maps.google.com/?q=${location.latitude},${location.longitude}`;
        
        // In a real app, this would automatically send location to all emergency contacts
        console.log('Sharing location with emergency contacts:', message);
        
        ToastManager.show(
            reason === 'emergency' 
                ? 'Emergency location shared with contacts'
                : 'Location shared with emergency contacts',
            'success'
        );
    }
}

// Create global SOS manager instance
const sosManager = new SOSManager();
// Main application controller
class ZurichMobilityApp {
    constructor() {
        this.currentTab = 'home';
        this.isInitialized = false;
        this.refreshIntervals = new Map();
        this.init();
    }

    async init() {
        try {
            // Show loading screen
            this.showLoadingScreen();

            // Initialize core components
            await this.initializeApp();
            
            // Setup navigation and event listeners
            this.setupNavigation();
            this.setupGlobalEventListeners();
            
            // Initialize tab content
            await this.initializeHomeTab();
            
            // Start auto-refresh for active data
            this.startAutoRefresh();
            
            this.isInitialized = true;
            
            // Hide loading screen and show app
            await this.hideLoadingScreen();
            
            ToastManager.show('Welcome to Zurich Mobility!', 'success');
            
        } catch (error) {
            console.error('Failed to initialize app:', error);
            this.handleInitializationError(error);
        }
    }

    showLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        const app = document.getElementById('app');
        
        if (loadingScreen) {
            loadingScreen.style.display = 'flex';
        }
        
        if (app) {
            app.style.display = 'none';
        }
    }

    async hideLoadingScreen() {
        return new Promise(resolve => {
            // Ensure minimum loading time for better UX
            setTimeout(() => {
                const loadingScreen = document.getElementById('loading-screen');
                const app = document.getElementById('app');
                
                if (loadingScreen) {
                    Utils.fadeOut(loadingScreen, 500);
                    setTimeout(() => {
                        loadingScreen.style.display = 'none';
                    }, 500);
                }
                
                if (app) {
                    app.style.display = 'flex';
                    Utils.fadeIn(app, 500);
                }
                
                resolve();
            }, CONFIG.UI.LOADING_MIN_TIME);
        });
    }

    async initializeApp() {
        // Initialize map service
        mapService.initializeMap('map');
        
        // Get user location
        try {
            await mapService.getUserLocation();
        } catch (error) {
            console.warn('User location not available:', error);
            ToastManager.show(CONFIG.ERRORS.LOCATION_DENIED, 'warning');
        }

        // Initialize all tab managers
        // (They're already initialized as global instances)
        
        console.log('App components initialized');
    }

    setupNavigation() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // Setup modal close handlers
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-close')) {
                const modal = e.target.closest('.modal');
                if (modal) {
                    ModalManager.hide(modal.id);
                }
            }
            
            // Close modals when clicking overlay
            if (e.target.classList.contains('modal')) {
                ModalManager.hide(e.target.id);
            }
        });

        // Setup search functionality
        this.setupSearchModal();
    }

    setupSearchModal() {
        const searchBtn = document.getElementById('search-btn');
        const searchModal = document.getElementById('search-modal');
        const searchClose = document.getElementById('search-close');
        const searchInput = document.getElementById('search-input');
        const searchSubmit = document.getElementById('search-submit');
        const searchResults = document.getElementById('search-results');

        if (searchBtn) {
            searchBtn.addEventListener('click', () => {
                ModalManager.show('search-modal');
                if (searchInput) {
                    searchInput.focus();
                }
            });
        }

        if (searchClose) {
            searchClose.addEventListener('click', () => {
                ModalManager.hide('search-modal');
            });
        }

        // Search functionality
        let searchTimeout;
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                const query = e.target.value.trim();
                
                if (query.length >= 2) {
                    searchTimeout = setTimeout(() => {
                        this.performSearch(query);
                    }, 300);
                } else {
                    if (searchResults) {
                        searchResults.innerHTML = '';
                    }
                }
            });
        }

        if (searchSubmit) {
            searchSubmit.addEventListener('click', () => {
                if (searchInput) {
                    const query = searchInput.value.trim();
                    if (query) {
                        this.performSearch(query);
                    }
                }
            });
        }

        // Submit on Enter
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const query = e.target.value.trim();
                    if (query) {
                        this.performSearch(query);
                    }
                }
            });
        }
    }

    async performSearch(query) {
        const searchResults = document.getElementById('search-results');
        if (!searchResults) return;

        try {
            searchResults.innerHTML = '<div class="searching">Searching...</div>';
            
            const results = await apiService.search(query);
            
            if (results.events.length === 0 && results.locations.length === 0) {
                searchResults.innerHTML = `
                    <div class="no-search-results">
                        <i class="fas fa-search"></i>
                        <p>No results found for "${query}"</p>
                        <p>Try searching for events, places, or addresses.</p>
                    </div>
                `;
                return;
            }

            let resultsHTML = '';
            
            // Events results
            if (results.events.length > 0) {
                resultsHTML += '<h4>Events</h4>';
                results.events.forEach(event => {
                    const distance = event.distance_km ? ` • ${Utils.formatDistance(event.distance_km)}` : '';
                    resultsHTML += `
                        <div class="search-result-item" data-type="event" data-id="${event.id}">
                            <i class="fas fa-calendar-alt"></i>
                            <div class="result-info">
                                <h5>${event.title}</h5>
                                <p>${Utils.formatDateTime(event.start_time)}${distance}</p>
                            </div>
                        </div>
                    `;
                });
            }
            
            // Locations results (if any)
            if (results.locations && results.locations.length > 0) {
                resultsHTML += '<h4>Locations</h4>';
                results.locations.forEach(location => {
                    resultsHTML += `
                        <div class="search-result-item" data-type="location" data-lat="${location.latitude}" data-lng="${location.longitude}">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="result-info">
                                <h5>${location.name}</h5>
                                <p>${location.address}</p>
                            </div>
                        </div>
                    `;
                });
            }
            
            searchResults.innerHTML = resultsHTML;
            
            // Add click handlers
            searchResults.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', () => {
                    this.handleSearchResultClick(item);
                });
            });
            
        } catch (error) {
            console.error('Search failed:', error);
            searchResults.innerHTML = `
                <div class="search-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Search failed. Please try again.</p>
                </div>
            `;
        }
    }

    handleSearchResultClick(item) {
        const type = item.dataset.type;
        
        if (type === 'event') {
            const eventId = item.dataset.id;
            ModalManager.hide('search-modal');
            eventsManager.showEventDetails(eventId);
        } else if (type === 'location') {
            const lat = parseFloat(item.dataset.lat);
            const lng = parseFloat(item.dataset.lng);
            
            ModalManager.hide('search-modal');
            
            // Switch to home tab and center map
            this.switchTab('home');
            setTimeout(() => {
                mapService.setView([lat, lng], 15);
                ToastManager.show('Location found on map', 'success');
            }, 300);
        }
    }

    setupGlobalEventListeners() {
        // Header button handlers
        const locationBtn = document.getElementById('location-btn');
        const refreshBtn = document.getElementById('refresh-btn');

        if (locationBtn) {
            locationBtn.addEventListener('click', () => {
                this.centerOnUserLocation();
            });
        }

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.refreshCurrentTab();
            });
        }

        // Map control handlers
        const centerLocationBtn = document.getElementById('center-location');
        const toggleTrafficBtn = document.getElementById('toggle-traffic');
        const toggleEventsBtn = document.getElementById('toggle-events');
        const toggleWashroomsBtn = document.getElementById('toggle-washrooms');

        if (centerLocationBtn) {
            centerLocationBtn.addEventListener('click', () => {
                this.centerOnUserLocation();
            });
        }

        if (toggleTrafficBtn) {
            toggleTrafficBtn.addEventListener('click', () => {
                this.toggleTrafficLayer();
            });
        }

        if (toggleEventsBtn) {
            toggleEventsBtn.addEventListener('click', () => {
                this.toggleEventsLayer();
            });
        }

        if (toggleWashroomsBtn) {
            toggleWashroomsBtn.addEventListener('click', () => {
                this.toggleWashroomsLayer();
            });
        }

        // Window resize handler
        window.addEventListener('resize', Utils.debounce(() => {
            this.handleWindowResize();
        }, 250));

        // Visibility change handler for auto-refresh
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.isInitialized) {
                this.refreshCurrentTab();
            }
        });

        // Close event detail modal handler
        const eventDetailClose = document.getElementById('event-detail-close');
        if (eventDetailClose) {
            eventDetailClose.addEventListener('click', () => {
                ModalManager.hide('event-detail-modal');
            });
        }
    }

    async switchTab(tabName) {
        if (this.currentTab === tabName) return;

        // Remove active class from current tab and content
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Add active class to new tab
        const newTabBtn = document.querySelector(`[data-tab="${tabName}"]`);
        const newTabContent = document.getElementById(`${tabName}-tab`);

        if (newTabBtn) {
            newTabBtn.classList.add('active');
        }
        
        if (newTabContent) {
            newTabContent.classList.add('active');
        }

        this.currentTab = tabName;

        // Initialize tab content if needed
        await this.initializeTabContent(tabName);

        console.log(`Switched to ${tabName} tab`);
    }

    async initializeTabContent(tabName) {
        try {
            switch (tabName) {
                case 'home':
                    await this.initializeHomeTab();
                    break;
                case 'events':
                    await eventsManager.loadEvents();
                    break;
                case 'traffic':
                    await trafficManager.loadTrafficData();
                    trafficManager.startAutoRefresh();
                    break;
                case 'planner':
                    await plannerManager.loadGroups();
                    break;
                case 'deals':
                    await dealsManager.loadDeals();
                    break;
                case 'heatmap':
                    heatmapManager.initializeHeatmapTab();
                    break;
                case 'sos':
                    // SOS tab is already initialized
                    break;
                case 'washrooms':
                    if (typeof washroomsManager !== 'undefined') {
                        await washroomsManager.loadWashrooms();
                    }
                    break;
            }
        } catch (error) {
            console.error(`Failed to initialize ${tabName} tab:`, error);
            Utils.handleError(error, `Initializing ${tabName} tab`);
        }
    }

    async initializeHomeTab() {
        try {
            // Load dashboard data
            const dashboardData = await apiService.getDashboard();
            
            // Update quick stats
            await this.updateQuickStats();
            
            // Load nearby events for the list
            const nearbyEvents = await eventsManager.updateNearbyEvents();
            
            // Load traffic indicators
            await trafficManager.updateQuickStats();
            
            // Load nearby washrooms for the map
            await this.loadNearbyWashrooms();
            
            // Update map markers
            if (nearbyEvents.length > 0) {
                mapService.addEventMarkers(nearbyEvents);
            }
            
            // Update last updated time
            this.updateLastUpdatedTime();
            
        } catch (error) {
            console.error('Failed to initialize home tab:', error);
            Utils.handleError(error, 'Loading dashboard');
        }
    }

    async loadNearbyWashrooms() {
        try {
            if (typeof apiService.getNearbyWashrooms === 'function') {
                const washrooms = await apiService.getNearbyWashrooms(10);
                if (washrooms && washrooms.length > 0) {
                    // Hide washroom markers by default, user can toggle them
                    mapService.addWashroomMarkers(washrooms);
                    mapService.toggleWashroomMarkers(false);
                }
            }
        } catch (error) {
            console.warn('Could not load nearby washrooms:', error);
            // Don't show error to user as this is optional functionality
        }
    }

    async updateQuickStats() {
        try {
            const stats = await apiService.getQuickStats();
            
            // Update events count
            const eventsCount = document.getElementById('events-count');
            if (eventsCount) {
                const valueElement = eventsCount.querySelector('.stat-value');
                if (valueElement) {
                    valueElement.textContent = stats.events_nearby || 0;
                }
            }
            
            // Traffic status is updated by trafficManager
            
        } catch (error) {
            console.error('Failed to update quick stats:', error);
        }
    }

    updateLastUpdatedTime() {
        const lastUpdatedElement = document.getElementById('last-updated');
        if (lastUpdatedElement) {
            lastUpdatedElement.textContent = `Updated ${Utils.formatTime(new Date().toISOString())}`;
        }
    }

    centerOnUserLocation() {
        if (mapService.userLocation) {
            mapService.centerOnUser();
            ToastManager.show('Centered on your location', 'success');
        } else {
            // Try to get location
            mapService.getUserLocation()
                .then(() => {
                    mapService.centerOnUser();
                    ToastManager.show('Location found and centered', 'success');
                })
                .catch(() => {
                    ToastManager.show(CONFIG.ERRORS.LOCATION_DENIED, 'error');
                });
        }
    }

    toggleTrafficLayer() {
        const toggleBtn = document.getElementById('toggle-traffic');
        if (!toggleBtn) return;

        const isActive = toggleBtn.classList.contains('active');
        
        if (isActive) {
            toggleBtn.classList.remove('active');
            mapService.toggleTrafficMarkers(false);
            ToastManager.show('Traffic layer hidden', 'info');
        } else {
            toggleBtn.classList.add('active');
            mapService.toggleTrafficMarkers(true);
            ToastManager.show('Traffic layer shown', 'info');
            
            // Load traffic data if not already loaded
            trafficManager.loadTrafficData();
        }
    }

    toggleEventsLayer() {
        const toggleBtn = document.getElementById('toggle-events');
        if (!toggleBtn) return;

        const isActive = toggleBtn.classList.contains('active');
        
        if (isActive) {
            toggleBtn.classList.remove('active');
            mapService.toggleEventMarkers(false);
            ToastManager.show('Events layer hidden', 'info');
        } else {
            toggleBtn.classList.add('active');
            mapService.toggleEventMarkers(true);
            ToastManager.show('Events layer shown', 'info');
        }
    }

    toggleWashroomsLayer() {
        const toggleBtn = document.getElementById('toggle-washrooms');
        if (!toggleBtn) return;

        const isActive = toggleBtn.classList.contains('active');
        
        if (isActive) {
            toggleBtn.classList.remove('active');
            mapService.toggleWashroomMarkers(false);
            ToastManager.show('Washrooms layer hidden', 'info');
        } else {
            toggleBtn.classList.add('active');
            mapService.toggleWashroomMarkers(true);
            ToastManager.show('Washrooms layer shown', 'info');
        }
    }

    async refreshCurrentTab() {
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.style.animation = 'spin 1s linear';
            setTimeout(() => {
                refreshBtn.style.animation = '';
            }, 1000);
        }

        try {
            await this.initializeTabContent(this.currentTab);
            ToastManager.show('Data refreshed', 'success');
        } catch (error) {
            console.error('Failed to refresh tab:', error);
            Utils.handleError(error, 'Refreshing data');
        }
    }

    startAutoRefresh() {
        // Clear existing intervals
        this.stopAutoRefresh();

        // Dashboard auto-refresh
        this.refreshIntervals.set('dashboard', setInterval(() => {
            if (this.currentTab === 'home' && !document.hidden) {
                this.updateQuickStats();
                this.updateLastUpdatedTime();
            }
        }, CONFIG.UPDATE_INTERVALS.DASHBOARD));

        // Traffic auto-refresh
        this.refreshIntervals.set('traffic', setInterval(() => {
            if (this.currentTab === 'traffic' && !document.hidden) {
                trafficManager.loadTrafficData();
            }
        }, CONFIG.UPDATE_INTERVALS.TRAFFIC));
    }

    stopAutoRefresh() {
        this.refreshIntervals.forEach((interval, key) => {
            clearInterval(interval);
        });
        this.refreshIntervals.clear();
    }

    handleWindowResize() {
        // Invalidate map size
        if (mapService.map) {
            mapService.map.invalidateSize();
        }
        
        // Handle heatmap resize
        heatmapManager.onWindowResize();
    }

    handleInitializationError(error) {
        console.error('App initialization failed:', error);
        
        // Hide loading screen
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.innerHTML = `
                <div class="loading-spinner">
                    <i class="fas fa-exclamation-triangle" style="color: #F44336;"></i>
                    <h2>Failed to Load</h2>
                    <p>Unable to initialize the app. Please refresh the page.</p>
                    <button onclick="window.location.reload()" class="primary-btn" style="margin-top: 1rem;">
                        <i class="fas fa-sync-alt"></i>
                        Reload App
                    </button>
                </div>
            `;
        }
    }

    // Cleanup when app is destroyed
    destroy() {
        this.stopAutoRefresh();
        mapService.destroy();
        heatmapManager.cleanup();
        
        // Remove global event listeners
        window.removeEventListener('resize', this.handleWindowResize);
        document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    }
}

// Additional CSS for animations
const additionalStyles = `
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .map-control-btn.active {
        background: var(--primary-color) !important;
        color: var(--white) !important;
    }
    
    .searching {
        text-align: center;
        padding: 2rem;
        color: #666;
    }
    
    .no-search-results, .search-error {
        text-align: center;
        padding: 2rem;
    }
    
    .no-search-results i, .search-error i {
        font-size: 2rem;
        margin-bottom: 1rem;
        color: #666;
    }
    
    .search-error i {
        color: var(--danger-color);
    }
    
    .search-results h4 {
        margin: 1rem 0 0.5rem 0;
        color: var(--dark-color);
        font-size: 1rem;
        font-weight: 600;
    }
    
    .search-results h4:first-child {
        margin-top: 0;
    }
    
    .result-info h5 {
        margin-bottom: 0.25rem;
        color: var(--dark-color);
    }
    
    .result-info p {
        color: #666;
        font-size: 0.875rem;
    }
    
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        color: var(--white);
    }
    
    .loading-content {
        text-align: center;
        background: var(--white);
        padding: 2rem;
        border-radius: var(--border-radius);
        color: var(--dark-color);
        box-shadow: var(--shadow-hover);
    }
    
    .loading-content .spinner {
        margin: 1rem auto;
    }
`;

// Add additional styles to document
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Create global app instance
    window.zurichMobilityApp = new ZurichMobilityApp();
});

// Handle page unload
window.addEventListener('beforeunload', () => {
    if (window.zurichMobilityApp) {
        window.zurichMobilityApp.destroy();
    }
});
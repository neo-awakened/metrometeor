// Map service for handling Leaflet map functionality
class MapService {
    constructor() {
        this.map = null;
        this.markers = {
            events: new Map(),
            traffic: new Map(),
            washrooms: new Map(),
            user: null
        };
        this.layers = {
            events: null,
            traffic: null,
            washrooms: null,
            heatmap: null
        };
        this.userLocation = null;
        this.watchId = null;
        this.eventListeners = new Map();
    }

    // Initialize the main map
    initializeMap(containerId, center = CONFIG.MAP.DEFAULT_CENTER, zoom = CONFIG.MAP.DEFAULT_ZOOM) {
        try {
            // Create map instance
            this.map = L.map(containerId, {
                center: center,
                zoom: zoom,
                minZoom: CONFIG.MAP.MIN_ZOOM,
                maxZoom: CONFIG.MAP.MAX_ZOOM,
                zoomControl: true,
                attributionControl: true
            });

            // Add tile layer
            L.tileLayer(CONFIG.MAP.TILE_LAYER, {
                attribution: CONFIG.MAP.ATTRIBUTION,
                maxZoom: CONFIG.MAP.MAX_ZOOM,
            }).addTo(this.map);

            // Create layer groups
            this.layers.events = L.layerGroup().addTo(this.map);
            this.layers.traffic = L.layerGroup().addTo(this.map);
            this.layers.washrooms = L.layerGroup().addTo(this.map);

            // Set up map event listeners
            this.setupMapEvents();

            // Request user location
            this.getUserLocation();

            console.log('Map initialized successfully');
            return this.map;
        } catch (error) {
            console.error('Failed to initialize map:', error);
            throw error;
        }
    }

    // Initialize heatmap
    initializeHeatmap(containerId) {
        try {
            const heatmapMap = L.map(containerId, {
                center: CONFIG.MAP.DEFAULT_CENTER,
                zoom: CONFIG.MAP.DEFAULT_ZOOM,
                minZoom: CONFIG.MAP.MIN_ZOOM,
                maxZoom: CONFIG.MAP.MAX_ZOOM
            });

            L.tileLayer(CONFIG.MAP.TILE_LAYER, {
                attribution: CONFIG.MAP.ATTRIBUTION,
                maxZoom: CONFIG.MAP.MAX_ZOOM,
            }).addTo(heatmapMap);

            return heatmapMap;
        } catch (error) {
            console.error('Failed to initialize heatmap:', error);
            throw error;
        }
    }

    // Set up map event listeners
    setupMapEvents() {
        this.map.on('click', (e) => {
            this.triggerEvent('mapClick', e);
        });

        this.map.on('moveend', () => {
            this.triggerEvent('mapMoveEnd', {
                center: this.map.getCenter(),
                zoom: this.map.getZoom(),
                bounds: this.map.getBounds()
            });
        });

        this.map.on('zoomend', () => {
            this.triggerEvent('mapZoomEnd', {
                zoom: this.map.getZoom()
            });
        });
    }

    // Event system
    addEventListener(eventType, callback) {
        if (!this.eventListeners.has(eventType)) {
            this.eventListeners.set(eventType, []);
        }
        this.eventListeners.get(eventType).push(callback);
    }

    removeEventListener(eventType, callback) {
        if (this.eventListeners.has(eventType)) {
            const listeners = this.eventListeners.get(eventType);
            const index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        }
    }

    triggerEvent(eventType, data) {
        if (this.eventListeners.has(eventType)) {
            this.eventListeners.get(eventType).forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in event listener for ${eventType}:`, error);
                }
            });
        }
    }

    // User location methods
    async getUserLocation() {
        if (!navigator.geolocation) {
            throw new Error('Geolocation is not supported by this browser');
        }

        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userLocation = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    };
                    
                    this.setUserLocation(userLocation);
                    resolve(userLocation);
                },
                (error) => {
                    console.error('Error getting user location:', error);
                    reject(error);
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        });
    }

    setUserLocation(location) {
        this.userLocation = location;
        apiService.setUserLocation(location.latitude, location.longitude);
        
        // Remove existing user marker
        if (this.markers.user) {
            this.map.removeLayer(this.markers.user);
        }

        // Add user location marker
        const userIcon = L.divIcon({
            className: 'user-location-marker',
            html: '<i class="fas fa-circle" style="color: #2196F3; font-size: 16px;"></i>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        this.markers.user = L.marker([location.latitude, location.longitude], {
            icon: userIcon,
            title: 'Your Location'
        }).addTo(this.map);

        // Add accuracy circle
        const accuracy = 50; // Default accuracy in meters
        L.circle([location.latitude, location.longitude], {
            radius: accuracy,
            color: '#2196F3',
            fillColor: '#2196F3',
            fillOpacity: 0.1,
            weight: 2
        }).addTo(this.map);

        this.triggerEvent('userLocationUpdate', location);
    }

    // Center map on user location
    centerOnUser() {
        if (this.userLocation) {
            this.map.setView([this.userLocation.latitude, this.userLocation.longitude], CONFIG.MAP.DEFAULT_ZOOM);
        }
    }

    // Watch user location for real-time updates
    startLocationWatch() {
        if (!navigator.geolocation) {
            console.warn('Geolocation not supported');
            return;
        }

        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                const newLocation = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                };
                this.setUserLocation(newLocation);
            },
            (error) => {
                console.error('Location watch error:', error);
            },
            {
                enableHighAccuracy: true,
                timeout: 30000,
                maximumAge: 60000
            }
        );
    }

    stopLocationWatch() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }
    }

    // Event markers
    addEventMarkers(events) {
        // Clear existing event markers
        this.clearEventMarkers();

        events.forEach(event => {
            const eventLocation = event.location;
            const categoryInfo = CONFIG.EVENT_CATEGORIES[event.event_type] || CONFIG.EVENT_CATEGORIES.other;
            
            const eventIcon = L.divIcon({
                className: 'event-marker',
                html: `<div class="event-marker-icon" style="background-color: ${categoryInfo.color}">
                        <i class="${categoryInfo.icon}" style="color: white; font-size: 14px;"></i>
                       </div>`,
                iconSize: [30, 30],
                iconAnchor: [15, 15]
            });

            const marker = L.marker([eventLocation.latitude, eventLocation.longitude], {
                icon: eventIcon,
                title: event.title
            });

            // Create popup content
            const popupContent = this.createEventPopup(event);
            marker.bindPopup(popupContent, {
                maxWidth: 300,
                className: 'event-popup'
            });

            // Add click event
            marker.on('click', () => {
                this.triggerEvent('eventMarkerClick', event);
            });

            this.markers.events.set(event.id, marker);
            this.layers.events.addLayer(marker);
        });
    }

    createEventPopup(event) {
        const categoryInfo = CONFIG.EVENT_CATEGORIES[event.event_type] || CONFIG.EVENT_CATEGORIES.other;
        const startTime = new Date(event.start_time).toLocaleString();
        const distance = event.distance_km ? `${event.distance_km.toFixed(1)} km away` : '';
        
        return `
            <div class="event-popup-content">
                <h4>${event.title}</h4>
                <p class="event-category">
                    <i class="${categoryInfo.icon}"></i>
                    ${categoryInfo.label}
                </p>
                <p class="event-time">
                    <i class="fas fa-clock"></i>
                    ${startTime}
                </p>
                ${distance ? `<p class="event-distance"><i class="fas fa-map-marker-alt"></i> ${distance}</p>` : ''}
                ${event.description ? `<p class="event-description">${event.description}</p>` : ''}
                <button class="popup-btn" onclick="eventDetailModal.show('${event.id}')">
                    View Details
                </button>
            </div>
        `;
    }

    clearEventMarkers() {
        this.markers.events.forEach(marker => {
            this.layers.events.removeLayer(marker);
        });
        this.markers.events.clear();
    }

    toggleEventMarkers(show = true) {
        if (show) {
            this.map.addLayer(this.layers.events);
        } else {
            this.map.removeLayer(this.layers.events);
        }
    }

    // Traffic markers
    addTrafficMarkers(disruptions) {
        // Clear existing traffic markers
        this.clearTrafficMarkers();

        disruptions.forEach(disruption => {
            const severityColors = {
                low: '#4CAF50',
                normal: '#FFC107',
                high: '#FF5722',
                severe: '#F44336'
            };

            const color = severityColors[disruption.severity] || severityColors.normal;
            
            const trafficIcon = L.divIcon({
                className: 'traffic-marker',
                html: `<div class="traffic-marker-icon" style="background-color: ${color}">
                        <i class="fas fa-exclamation-triangle" style="color: white; font-size: 14px;"></i>
                       </div>`,
                iconSize: [25, 25],
                iconAnchor: [12, 12]
            });

            const marker = L.marker([disruption.location.latitude, disruption.location.longitude], {
                icon: trafficIcon,
                title: disruption.title
            });

            // Create popup content
            const popupContent = this.createTrafficPopup(disruption);
            marker.bindPopup(popupContent, {
                maxWidth: 250,
                className: 'traffic-popup'
            });

            this.markers.traffic.set(disruption.id, marker);
            this.layers.traffic.addLayer(marker);
        });
    }

    createTrafficPopup(disruption) {
        const severityLabels = {
            low: 'Low Impact',
            normal: 'Moderate Impact',
            high: 'High Impact',
            severe: 'Severe Impact'
        };

        const severityLabel = severityLabels[disruption.severity] || 'Unknown';
        const distance = disruption.distance_km ? `${disruption.distance_km.toFixed(1)} km away` : '';
        
        return `
            <div class="traffic-popup-content">
                <h4>${disruption.title}</h4>
                <p class="traffic-severity severity-${disruption.severity}">
                    <i class="fas fa-exclamation-triangle"></i>
                    ${severityLabel}
                </p>
                ${distance ? `<p class="traffic-distance"><i class="fas fa-map-marker-alt"></i> ${distance}</p>` : ''}
                <p class="traffic-description">${disruption.description}</p>
                ${disruption.affected_routes.length > 0 ? 
                    `<p class="affected-routes">
                        <strong>Affected Routes:</strong> ${disruption.affected_routes.join(', ')}
                    </p>` : ''
                }
            </div>
        `;
    }

    clearTrafficMarkers() {
        this.markers.traffic.forEach(marker => {
            this.layers.traffic.removeLayer(marker);
        });
        this.markers.traffic.clear();
    }

    toggleTrafficMarkers(show = true) {
        if (show) {
            this.map.addLayer(this.layers.traffic);
        } else {
            this.map.removeLayer(this.layers.traffic);
        }
    }

    // Washroom markers
    addWashroomMarkers(washrooms) {
        // Clear existing washroom markers
        this.clearWashroomMarkers();

        washrooms.forEach(washroom => {
            if (!washroom.location || !washroom.location.latitude || !washroom.location.longitude) {
                return;
            }

            // Determine marker style based on washroom type
            let iconClass = 'fas fa-restroom';
            let markerColor = '#2196F3';
            
            switch (washroom.washroom_type) {
                case 'fixed':
                    iconClass = 'fas fa-restroom';
                    markerColor = '#2196F3';
                    break;
                case 'mobile':
                    iconClass = 'fas fa-trailer';
                    markerColor = '#FF9800';
                    break;
                case 'pissoir':
                    iconClass = 'fas fa-male';
                    markerColor = '#4CAF50';
                    break;
            }

            const washroomIcon = L.divIcon({
                className: 'washroom-marker-map',
                html: `<div class="washroom-marker-icon" style="background-color: ${markerColor}">
                        <i class="${iconClass}" style="color: white; font-size: 12px;"></i>
                        ${washroom.accessibility === 'wheelchair_accessible' ? 
                            '<i class="fas fa-wheelchair accessibility-indicator"></i>' : ''}
                       </div>`,
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            });

            const marker = L.marker([washroom.location.latitude, washroom.location.longitude], {
                icon: washroomIcon,
                title: washroom.name
            });

            // Create popup content
            const popupContent = this.createWashroomPopup(washroom);
            marker.bindPopup(popupContent, {
                maxWidth: 250,
                className: 'washroom-popup'
            });

            // Add click event
            marker.on('click', () => {
                this.triggerEvent('washroomMarkerClick', washroom);
            });

            this.markers.washrooms.set(washroom.id, marker);
            this.layers.washrooms.addLayer(marker);
        });
    }

    createWashroomPopup(washroom) {
        const distance = washroom.distance_from_user ? 
            `<p class="washroom-distance"><i class="fas fa-map-marker-alt"></i> ${(washroom.distance_from_user * 1000).toFixed(0)}m away</p>` : '';
        
        const accessibility = washroom.accessibility === 'wheelchair_accessible' ? 
            '<i class="fas fa-wheelchair" title="Wheelchair Accessible" style="color: #4CAF50;"></i>' : '';
        
        const typeLabel = this.formatWashroomType(washroom.washroom_type);
        
        return `
            <div class="washroom-popup-content">
                <h4>${washroom.name} ${accessibility}</h4>
                <p class="washroom-type">
                    <i class="fas fa-restroom"></i>
                    ${typeLabel}
                </p>
                <p class="washroom-address">${washroom.address}</p>
                ${distance}
                <div class="washroom-tags">
                    ${washroom.is_free ? '<span class="tag free">Free</span>' : '<span class="tag paid">Paid</span>'}
                    ${washroom.is_open_24h ? '<span class="tag hours">24h</span>' : '<span class="tag hours">Limited</span>'}
                </div>
                ${washroom.opening_hours ? `<p class="opening-hours">${washroom.opening_hours}</p>` : ''}
                <button class="popup-btn" onclick="washroomsManager?.showWashroomDetails('${washroom.id}')">
                    View Details
                </button>
            </div>
        `;
    }

    formatWashroomType(type) {
        switch (type) {
            case 'fixed':
                return 'Fixed Washroom';
            case 'mobile':
                return 'Mobile Washroom';
            case 'pissoir':
                return 'Pissoir';
            default:
                return 'Washroom';
        }
    }

    clearWashroomMarkers() {
        this.markers.washrooms.forEach(marker => {
            this.layers.washrooms.removeLayer(marker);
        });
        this.markers.washrooms.clear();
    }

    toggleWashroomMarkers(show = true) {
        if (show) {
            this.map.addLayer(this.layers.washrooms);
        } else {
            this.map.removeLayer(this.layers.washrooms);
        }
    }

    // Heatmap functionality
    addHeatmapLayer(heatmapMap, points) {
        // Remove existing heatmap layer
        if (this.layers.heatmap) {
            heatmapMap.removeLayer(this.layers.heatmap);
        }

        // Convert points to Leaflet heat format
        const heatPoints = points.map(point => [
            point.latitude,
            point.longitude,
            point.intensity
        ]);

        // Create heatmap layer
        this.layers.heatmap = L.heatLayer(heatPoints, {
            radius: 20,
            blur: 15,
            maxZoom: 17,
            max: 1.0,
            gradient: {
                0.2: '#4CAF50',
                0.4: '#FFC107',
                0.6: '#FF9800',
                0.8: '#FF5722',
                1.0: '#F44336'
            }
        }).addTo(heatmapMap);
    }

    // Route visualization
    addRoute(coordinates, options = {}) {
        const defaultOptions = {
            color: '#2196F3',
            weight: 5,
            opacity: 0.7
        };

        const routeOptions = { ...defaultOptions, ...options };
        
        const route = L.polyline(coordinates, routeOptions);
        route.addTo(this.map);
        
        // Fit map to route bounds
        this.map.fitBounds(route.getBounds(), { padding: [20, 20] });
        
        return route;
    }

    // Utility methods
    getMapBounds() {
        return this.map ? this.map.getBounds() : null;
    }

    getMapCenter() {
        return this.map ? this.map.getCenter() : null;
    }

    getMapZoom() {
        return this.map ? this.map.getZoom() : null;
    }

    fitBounds(bounds, options = {}) {
        if (this.map) {
            this.map.fitBounds(bounds, options);
        }
    }

    setView(center, zoom, options = {}) {
        if (this.map) {
            this.map.setView(center, zoom, options);
        }
    }

    // Cleanup
    destroy() {
        this.stopLocationWatch();
        
        if (this.map) {
            this.map.remove();
            this.map = null;
        }
        
        this.markers.events.clear();
        this.markers.traffic.clear();
        this.eventListeners.clear();
    }
}

// Create global map service instance
const mapService = new MapService();
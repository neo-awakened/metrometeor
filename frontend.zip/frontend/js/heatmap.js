// Heatmap module for handling crowd and traffic density visualization
class HeatmapManager {
    constructor() {
        this.heatmapMap = null;
        this.currentDataType = 'crowd';
        this.currentRadius = 1000;
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        const dataTypeSelect = document.getElementById('heatmap-data-type');
        const radiusSlider = document.getElementById('heatmap-radius');
        const radiusValue = document.getElementById('radius-value');
        
        if (dataTypeSelect) {
            dataTypeSelect.addEventListener('change', (e) => {
                this.currentDataType = e.target.value;
                this.generateHeatmap();
            });
        }
        
        if (radiusSlider) {
            radiusSlider.addEventListener('input', (e) => {
                this.currentRadius = parseInt(e.target.value);
                if (radiusValue) {
                    radiusValue.textContent = `${this.currentRadius}m`;
                }
            });
            
            radiusSlider.addEventListener('change', () => {
                this.generateHeatmap();
            });
        }
    }

    initializeHeatmapTab() {
        if (!this.heatmapMap) {
            this.heatmapMap = mapService.initializeHeatmap('heatmap');
            this.loadDataTypes();
            this.generateHeatmap();
        }
    }

    async loadDataTypes() {
        try {
            const data = await apiService.getHeatmapDataTypes();
            this.populateDataTypeSelect(data.data_types);
        } catch (error) {
            console.error('Failed to load heatmap data types:', error);
            // Use default data types
            this.populateDataTypeSelect([
                {
                    value: 'crowd',
                    label: 'Crowd Density',
                    description: 'Shows areas with high people concentration',
                    color: '#FF5722'
                },
                {
                    value: 'traffic',
                    label: 'Traffic Density', 
                    description: 'Shows traffic congestion areas',
                    color: '#F44336'
                },
                {
                    value: 'events',
                    label: 'Event Locations',
                    description: 'Shows locations of active events',
                    color: '#9C27B0'
                }
            ]);
        }
    }

    populateDataTypeSelect(dataTypes) {
        const select = document.getElementById('heatmap-data-type');
        if (!select) return;

        select.innerHTML = '';
        dataTypes.forEach(type => {
            const option = document.createElement('option');
            option.value = type.value;
            option.textContent = type.label;
            select.appendChild(option);
        });
    }

    async generateHeatmap() {
        if (!this.heatmapMap) return;
        
        try {
            LoadingManager.show('Generating heatmap...');
            
            // Get current map center as coordinates
            const center = this.heatmapMap.getCenter();
            const coordinates = [{
                latitude: center.lat,
                longitude: center.lng
            }];
            
            const request = {
                coordinates: coordinates,
                radius_meters: this.currentRadius,
                data_types: [this.currentDataType]
            };
            
            // Try to get real heatmap data from API
            let heatmapData;
            try {
                heatmapData = await apiService.generateHeatmap(request);
            } catch (error) {
                console.warn('API heatmap generation failed, using mock data:', error);
                heatmapData = this.generateMockHeatmapData(center, this.currentRadius, this.currentDataType);
            }
            
            // Add heatmap layer to map
            mapService.addHeatmapLayer(this.heatmapMap, heatmapData.points);
            
            ToastManager.show('Heatmap updated', 'success');
            
        } catch (error) {
            console.error('Failed to generate heatmap:', error);
            Utils.handleError(error, 'Generating heatmap');
        } finally {
            LoadingManager.hide();
        }
    }

    generateMockHeatmapData(center, radius, dataType) {
        const points = [];
        const numPoints = 50 + Math.floor(Math.random() * 50); // 50-100 points
        
        for (let i = 0; i < numPoints; i++) {
            // Generate random points within radius
            const angle = Math.random() * 2 * Math.PI;
            const distance = Math.random() * radius;
            
            // Convert to lat/lng offset
            const latOffset = (distance * Math.cos(angle)) / 111320; // roughly 111320 meters per degree lat
            const lngOffset = (distance * Math.sin(angle)) / (111320 * Math.cos(center.lat * Math.PI / 180));
            
            const intensity = this.generateIntensityByDataType(dataType);
            
            points.push({
                latitude: center.lat + latOffset,
                longitude: center.lng + lngOffset,
                intensity: intensity,
                data_type: dataType,
                timestamp: new Date().toISOString()
            });
        }
        
        return {
            points: points,
            bounds: {
                min_lat: center.lat - 0.01,
                max_lat: center.lat + 0.01,
                min_lng: center.lng - 0.01,
                max_lng: center.lng + 0.01
            },
            generated_at: new Date().toISOString(),
            data_sources: [dataType]
        };
    }

    generateIntensityByDataType(dataType) {
        switch (dataType) {
            case 'crowd':
                // Crowd density tends to cluster around events and transport hubs
                return Math.random() > 0.7 ? Math.random() * 0.4 + 0.6 : Math.random() * 0.5;
            
            case 'traffic':
                // Traffic tends to be higher on main roads
                return Math.random() > 0.6 ? Math.random() * 0.5 + 0.5 : Math.random() * 0.4;
            
            case 'events':
                // Events are binary - either there's an event (high intensity) or not
                return Math.random() > 0.9 ? Math.random() * 0.3 + 0.7 : Math.random() * 0.2;
            
            default:
                return Math.random();
        }
    }

    // Update heatmap when user moves map
    onMapMove() {
        if (this.heatmapMap) {
            // Debounce the heatmap generation to avoid too many API calls
            clearTimeout(this.moveTimeout);
            this.moveTimeout = setTimeout(() => {
                this.generateHeatmap();
            }, 1000);
        }
    }

    // Resize heatmap map when window resizes
    onWindowResize() {
        if (this.heatmapMap) {
            setTimeout(() => {
                this.heatmapMap.invalidateSize();
            }, 100);
        }
    }

    // Clean up resources
    cleanup() {
        if (this.moveTimeout) {
            clearTimeout(this.moveTimeout);
        }
        
        if (this.heatmapMap) {
            this.heatmapMap.remove();
            this.heatmapMap = null;
        }
    }
}

// Create global heatmap manager instance
const heatmapManager = new HeatmapManager();
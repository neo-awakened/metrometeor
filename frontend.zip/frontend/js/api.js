// API service for communicating with the FastAPI backend
class ApiService {
    constructor() {
        this.baseURL = CONFIG.API_BASE_URL;
        this.userLocation = null;
        this.cache = new Map();
        this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    }

    // Set user location for API calls
    setUserLocation(latitude, longitude) {
        this.userLocation = { latitude, longitude };
    }

    // Generic API request method
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const finalOptions = { ...defaultOptions, ...options };

        try {
            const response = await fetch(url, finalOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.error || 'API request failed');
            }

            return data.data;
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    // Cache management
    getCacheKey(endpoint, params) {
        const paramString = params ? new URLSearchParams(params).toString() : '';
        return `${endpoint}?${paramString}`;
    }

    getFromCache(key) {
        const cached = this.cache.get(key);
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }
        return null;
    }

    setCache(key, data) {
        this.cache.set(key, {
            data,
            timestamp: Date.now()
        });
    }

    // Home/Dashboard API calls
    async getDashboard(radius = CONFIG.DEFAULT_RADIUS) {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude,
            radius_km: radius
        };

        const cacheKey = this.getCacheKey('/api/v1/home/dashboard', params);
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = `/api/v1/home/dashboard?${new URLSearchParams(params)}`;
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    async getNearbyEvents(radius = CONFIG.DEFAULT_RADIUS, limit = 20) {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude,
            radius_km: radius,
            limit
        };

        const endpoint = `/api/v1/home/nearby-events?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getTrafficStatus(radius = CONFIG.DEFAULT_RADIUS) {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude,
            radius_km: radius
        };

        const endpoint = `/api/v1/home/traffic-status?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getQuickStats() {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude
        };

        const endpoint = `/api/v1/home/quick-stats?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async search(query, limit = 10) {
        const params = { query, limit };
        
        if (this.userLocation) {
            params.lat = this.userLocation.latitude;
            params.lng = this.userLocation.longitude;
        }

        const endpoint = `/api/v1/home/search?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    // Events API calls
    async getEvents(filters = {}) {
        const params = {
            page: filters.page || 1,
            per_page: filters.per_page || CONFIG.PAGINATION.EVENTS_PER_PAGE,
            sort_by: filters.sort_by || 'date'
        };

        if (filters.event_type) params.event_type = filters.event_type;
        if (filters.start_date) params.start_date = filters.start_date;
        if (filters.end_date) params.end_date = filters.end_date;
        if (filters.radius_km) params.radius_km = filters.radius_km;

        if (this.userLocation) {
            params.lat = this.userLocation.latitude;
            params.lng = this.userLocation.longitude;
        }

        const endpoint = `/api/v1/events/?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getEventDetails(eventId) {
        const params = {};
        
        if (this.userLocation) {
            params.lat = this.userLocation.latitude;
            params.lng = this.userLocation.longitude;
        }

        const queryString = Object.keys(params).length ? `?${new URLSearchParams(params)}` : '';
        const endpoint = `/api/v1/events/${eventId}${queryString}`;
        return await this.request(endpoint);
    }

    async getEventRoutes(eventId) {
        if (!this.userLocation) {
            throw new Error('User location required for route planning');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude
        };

        const endpoint = `/api/v1/events/${eventId}/routes?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getEventCategories() {
        const cacheKey = 'event-categories';
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = '/api/v1/events/categories/list';
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    // Traffic API calls  
    async getTrafficData() {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            lat: this.userLocation.latitude,
            lng: this.userLocation.longitude
        };

        const endpoint = `/api/v1/traffic/?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    // Group Planner API calls
    async getGroups() {
        const endpoint = '/api/v1/planner/groups';
        return await this.request(endpoint);
    }

    async createGroup(groupData) {
        const endpoint = '/api/v1/planner/groups';
        const options = {
            method: 'POST',
            body: JSON.stringify(groupData)
        };
        return await this.request(endpoint, options);
    }

    async getGroupDetails(groupId) {
        const endpoint = `/api/v1/planner/groups/${groupId}`;
        return await this.request(endpoint);
    }

    async updateGroup(groupId, updateData) {
        const endpoint = `/api/v1/planner/groups/${groupId}`;
        const options = {
            method: 'PUT',
            body: JSON.stringify(updateData)
        };
        return await this.request(endpoint, options);
    }

    async addGroupMember(groupId, memberData) {
        const endpoint = `/api/v1/planner/groups/${groupId}/members`;
        const options = {
            method: 'POST',
            body: JSON.stringify(memberData)
        };
        return await this.request(endpoint, options);
    }

    async removeGroupMember(groupId, memberId) {
        const endpoint = `/api/v1/planner/groups/${groupId}/members/${memberId}`;
        const options = {
            method: 'DELETE'
        };
        return await this.request(endpoint, options);
    }

    // Deals API calls
    async getDeals(filters = {}) {
        const params = {
            limit: filters.limit || CONFIG.PAGINATION.DEALS_PER_PAGE
        };

        if (filters.category) params.category = filters.category;
        
        if (this.userLocation) {
            params.lat = this.userLocation.latitude;
            params.lng = this.userLocation.longitude;
        }

        const endpoint = `/api/v1/deals/?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getDealCategories() {
        const cacheKey = 'deal-categories';
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = '/api/v1/deals/categories';
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    // Heatmap API calls
    async generateHeatmap(request) {
        const endpoint = '/api/v1/heatmap/generate';
        const options = {
            method: 'POST',
            body: JSON.stringify(request)
        };
        return await this.request(endpoint, options);
    }

    async getHeatmapDataTypes() {
        const cacheKey = 'heatmap-data-types';
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = '/api/v1/heatmap/data-types';
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    // SOS API calls
    async getEmergencyContacts() {
        const endpoint = '/api/v1/sos/contacts';
        return await this.request(endpoint);
    }

    async addEmergencyContact(contactData) {
        const endpoint = '/api/v1/sos/contacts';
        const options = {
            method: 'POST',
            body: JSON.stringify(contactData)
        };
        return await this.request(endpoint, options);
    }

    async updateEmergencyContact(contactId, contactData) {
        const endpoint = `/api/v1/sos/contacts/${contactId}`;
        const options = {
            method: 'PUT',
            body: JSON.stringify(contactData)
        };
        return await this.request(endpoint, options);
    }

    async deleteEmergencyContact(contactId) {
        const endpoint = `/api/v1/sos/contacts/${contactId}`;
        const options = {
            method: 'DELETE'
        };
        return await this.request(endpoint, options);
    }

    async getEmergencyInfo() {
        const endpoint = '/api/v1/sos/emergency-info';
        return await this.request(endpoint);
    }

    async updateEmergencyInfo(info) {
        const endpoint = '/api/v1/sos/emergency-info';
        const options = {
            method: 'PUT',
            body: JSON.stringify(info)
        };
        return await this.request(endpoint, options);
    }

    // Washroom API calls
    async searchWashrooms(searchParams = {}) {
        if (!this.userLocation && !searchParams.latitude) {
            throw new Error('User location not set');
        }

        const params = {
            latitude: searchParams.latitude || this.userLocation.latitude,
            longitude: searchParams.longitude || this.userLocation.longitude,
            radius: searchParams.radius || CONFIG.DEFAULT_RADIUS * 1000, // Convert to meters
            ...(searchParams.washroom_type && { washroom_type: searchParams.washroom_type }),
            ...(searchParams.accessibility_required && { accessibility_required: searchParams.accessibility_required }),
            ...(searchParams.free_only && { free_only: searchParams.free_only }),
            ...(searchParams.open_24h_only && { open_24h_only: searchParams.open_24h_only })
        };

        const endpoint = `/api/v1/washrooms/search?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async searchWashroomsPost(searchRequest) {
        const endpoint = '/api/v1/washrooms/search';
        const options = {
            method: 'POST',
            body: JSON.stringify(searchRequest)
        };
        return await this.request(endpoint, options);
    }

    async getNearbyWashrooms(limit = 10) {
        if (!this.userLocation) {
            throw new Error('User location not set');
        }

        const params = {
            latitude: this.userLocation.latitude,
            longitude: this.userLocation.longitude,
            limit
        };

        const endpoint = `/api/v1/washrooms/nearby?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getWashroomById(id) {
        const endpoint = `/api/v1/washrooms/${id}`;
        return await this.request(endpoint);
    }

    async getAllWashrooms(filters = {}) {
        const params = {
            limit: filters.limit || 100,
            skip: filters.skip || 0,
            ...(filters.washroom_type && { washroom_type: filters.washroom_type }),
            ...(filters.accessibility_required && { accessibility_required: filters.accessibility_required })
        };

        const endpoint = `/api/v1/washrooms/?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getWashroomStatistics() {
        const cacheKey = 'washroom-statistics';
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = '/api/v1/washrooms/stats/summary';
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    async getWashroomTypes() {
        const cacheKey = 'washroom-types';
        const cached = this.getFromCache(cacheKey);
        if (cached) return cached;

        const endpoint = '/api/v1/washrooms/types';
        const data = await this.request(endpoint);
        this.setCache(cacheKey, data);
        return data;
    }

    async getWashroomsByDistrict(district, limit = 50) {
        const params = { limit };
        const endpoint = `/api/v1/washrooms/districts/${encodeURIComponent(district)}/washrooms?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    async getWheelchairAccessibleWashrooms(searchParams = {}) {
        const params = {
            limit: searchParams.limit || 20,
            radius: searchParams.radius || 5000
        };

        if (this.userLocation) {
            params.latitude = this.userLocation.latitude;
            params.longitude = this.userLocation.longitude;
        }

        const endpoint = `/api/v1/washrooms/accessibility/wheelchair?${new URLSearchParams(params)}`;
        return await this.request(endpoint);
    }

    // Clear cache
    clearCache() {
        this.cache.clear();
    }

    // Clear expired cache entries
    clearExpiredCache() {
        const now = Date.now();
        for (const [key, value] of this.cache.entries()) {
            if (now - value.timestamp >= this.cacheTimeout) {
                this.cache.delete(key);
            }
        }
    }
}

// Create global API service instance
const apiService = new ApiService();

// Clear expired cache periodically
setInterval(() => {
    apiService.clearExpiredCache();
}, 5 * 60 * 1000); // Every 5 minutes
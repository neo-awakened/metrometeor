// Washrooms management module
class WashroomsManager {
    constructor() {
        this.washrooms = [];
        this.filteredWashrooms = [];
        this.washroomMap = null;
        this.washroomMarkers = [];
        this.userMarker = null;
        this.currentFilters = {
            type: '',
            accessibility: false,
            freeOnly: false,
            open24h: false,
            radius: 1000
        };
        this.statistics = {};
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeMap();
        this.loadWashrooms();
    }

    setupEventListeners() {
        // Filter controls
        const typeFilter = document.getElementById('washroom-type-filter');
        const accessibilityFilter = document.getElementById('accessibility-filter');
        const freeOnlyFilter = document.getElementById('free-only-filter');
        const open24hFilter = document.getElementById('open-24h-filter');
        const radiusSlider = document.getElementById('washroom-radius');
        const radiusValue = document.getElementById('washroom-radius-value');

        if (typeFilter) {
            typeFilter.addEventListener('change', () => {
                this.currentFilters.type = typeFilter.value;
                this.filterWashrooms();
            });
        }

        if (accessibilityFilter) {
            accessibilityFilter.addEventListener('change', () => {
                this.currentFilters.accessibility = accessibilityFilter.checked;
                this.filterWashrooms();
            });
        }

        if (freeOnlyFilter) {
            freeOnlyFilter.addEventListener('change', () => {
                this.currentFilters.freeOnly = freeOnlyFilter.checked;
                this.filterWashrooms();
            });
        }

        if (open24hFilter) {
            open24hFilter.addEventListener('change', () => {
                this.currentFilters.open24h = open24hFilter.checked;
                this.filterWashrooms();
            });
        }

        if (radiusSlider) {
            radiusSlider.addEventListener('input', () => {
                this.currentFilters.radius = parseInt(radiusSlider.value);
                if (radiusValue) {
                    radiusValue.textContent = `${this.currentFilters.radius}m`;
                }
                this.filterWashrooms();
            });
        }

        // Modal close
        const modalClose = document.getElementById('washroom-detail-close');
        if (modalClose) {
            modalClose.addEventListener('click', () => {
                this.closeWashroomModal();
            });
        }
    }

    initializeMap() {
        const mapContainer = document.getElementById('washrooms-map');
        if (!mapContainer) return;

        // Initialize the washroom map
        this.washroomMap = L.map('washrooms-map').setView([47.3769, 8.5417], 13);

        // Add tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(this.washroomMap);

        // Add user location if available
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                
                // Add user marker
                this.userMarker = L.marker([userLat, userLng], {
                    icon: L.divIcon({
                        className: 'user-location-marker',
                        html: '<i class="fas fa-user"></i>',
                        iconSize: [20, 20]
                    })
                }).addTo(this.washroomMap);

                // Center map on user location
                this.washroomMap.setView([userLat, userLng], 15);
                
                // Set API service location
                apiService.setUserLocation(userLat, userLng);
                
                // Reload washrooms with user location
                this.loadWashrooms();
            });
        }
    }

    async loadWashrooms() {
        try {
            Utils.showLoading();
            
            // Search for washrooms with current filters
            const searchParams = {
                radius: this.currentFilters.radius,
                washroom_type: this.currentFilters.type || undefined,
                accessibility_required: this.currentFilters.accessibility,
                free_only: this.currentFilters.freeOnly,
                open_24h_only: this.currentFilters.open24h
            };

            const response = await apiService.searchWashrooms(searchParams);
            
            if (response && response.success) {
                this.washrooms = response.data.washrooms || [];
                this.filteredWashrooms = [...this.washrooms];
                this.displayWashrooms();
                this.updateStatistics();
            } else {
                // Fallback: try to get nearby washrooms
                const nearbyResponse = await apiService.getNearbyWashrooms(50);
                if (nearbyResponse && nearbyResponse.success) {
                    this.washrooms = nearbyResponse.data || [];
                    this.filteredWashrooms = [...this.washrooms];
                    this.filterWashrooms(); // Apply current filters
                }
            }
            
        } catch (error) {
            console.error('Error loading washrooms:', error);
            Utils.showToast('Failed to load washrooms', 'error');
            
            // Show sample data as fallback
            this.showSampleWashrooms();
        } finally {
            Utils.hideLoading();
        }
    }

    filterWashrooms() {
        this.filteredWashrooms = this.washrooms.filter(washroom => {
            // Type filter
            if (this.currentFilters.type && washroom.washroom_type !== this.currentFilters.type) {
                return false;
            }

            // Accessibility filter
            if (this.currentFilters.accessibility && washroom.accessibility !== 'wheelchair_accessible') {
                return false;
            }

            // Free only filter
            if (this.currentFilters.freeOnly && !washroom.is_free) {
                return false;
            }

            // 24h open filter
            if (this.currentFilters.open24h && !washroom.is_open_24h) {
                return false;
            }

            // Distance filter (if distance is available)
            if (washroom.distance_from_user && washroom.distance_from_user * 1000 > this.currentFilters.radius) {
                return false;
            }

            return true;
        });

        this.displayWashrooms();
        this.updateStatistics();
    }

    displayWashrooms() {
        this.displayWashroomsOnMap();
        this.displayWashroomsList();
    }

    displayWashroomsOnMap() {
        if (!this.washroomMap) return;

        // Clear existing markers
        this.washroomMarkers.forEach(marker => {
            this.washroomMap.removeLayer(marker);
        });
        this.washroomMarkers = [];

        // Add washroom markers
        this.filteredWashrooms.forEach(washroom => {
            const marker = this.createWashroomMarker(washroom);
            if (marker) {
                marker.addTo(this.washroomMap);
                this.washroomMarkers.push(marker);
            }
        });

        // Fit map to show all markers if there are any
        if (this.washroomMarkers.length > 0) {
            const group = new L.featureGroup(this.washroomMarkers);
            
            // Include user marker if available
            if (this.userMarker) {
                group.addLayer(this.userMarker);
            }
            
            this.washroomMap.fitBounds(group.getBounds().pad(0.1));
        }
    }

    createWashroomMarker(washroom) {
        if (!washroom.location || !washroom.location.latitude || !washroom.location.longitude) {
            return null;
        }

        // Determine marker icon based on washroom type
        let iconClass = 'fas fa-restroom';
        let markerClass = 'washroom-marker';
        
        switch (washroom.washroom_type) {
            case 'fixed':
                iconClass = 'fas fa-restroom';
                markerClass += ' fixed';
                break;
            case 'mobile':
                iconClass = 'fas fa-trailer';
                markerClass += ' mobile';
                break;
            case 'pissoir':
                iconClass = 'fas fa-male';
                markerClass += ' pissoir';
                break;
        }

        // Add accessibility indicator
        if (washroom.accessibility === 'wheelchair_accessible') {
            markerClass += ' accessible';
        }

        const marker = L.marker([washroom.location.latitude, washroom.location.longitude], {
            icon: L.divIcon({
                className: markerClass,
                html: `<i class="${iconClass}"></i>${washroom.accessibility === 'wheelchair_accessible' ? '<i class="fas fa-wheelchair"></i>' : ''}`,
                iconSize: [30, 30]
            })
        });

        // Add popup
        const popupContent = this.createWashroomPopup(washroom);
        marker.bindPopup(popupContent);

        // Add click event to show details
        marker.on('click', () => {
            this.showWashroomDetails(washroom);
        });

        return marker;
    }

    createWashroomPopup(washroom) {
        const distance = washroom.distance_from_user ? 
            `<div class="popup-distance">${(washroom.distance_from_user * 1000).toFixed(0)}m away</div>` : '';
        
        const accessibility = washroom.accessibility === 'wheelchair_accessible' ? 
            '<i class="fas fa-wheelchair" title="Wheelchair Accessible"></i>' : '';
        
        const freeStatus = washroom.is_free ? 
            '<span class="free-tag">Free</span>' : 
            '<span class="paid-tag">Paid</span>';
        
        const hours = washroom.is_open_24h ? 
            '<span class="hours-tag">24h</span>' : 
            '<span class="hours-tag">Limited hours</span>';

        return `
            <div class="washroom-popup">
                <div class="popup-header">
                    <h4>${washroom.name}</h4>
                    ${accessibility}
                </div>
                <div class="popup-address">${washroom.address}</div>
                ${distance}
                <div class="popup-tags">
                    ${freeStatus}
                    ${hours}
                </div>
                <div class="popup-type">${this.formatWashroomType(washroom.washroom_type)}</div>
            </div>
        `;
    }

    displayWashroomsList() {
        const container = document.getElementById('washrooms-list-container');
        if (!container) return;

        if (this.filteredWashrooms.length === 0) {
            container.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <p>No washrooms found with current filters</p>
                    <button class="secondary-btn" onclick="washroomsManager.clearFilters()">Clear Filters</button>
                </div>
            `;
            return;
        }

        const washroomsHtml = this.filteredWashrooms.map(washroom => {
            const distance = washroom.distance_from_user ? 
                `<span class="distance">${(washroom.distance_from_user * 1000).toFixed(0)}m</span>` : '';
            
            const accessibility = washroom.accessibility === 'wheelchair_accessible' ? 
                '<i class="fas fa-wheelchair" title="Wheelchair Accessible"></i>' : '';
            
            return `
                <div class="washroom-item" onclick="washroomsManager.showWashroomDetails('${washroom.id}')">
                    <div class="washroom-header">
                        <h4>${washroom.name} ${accessibility}</h4>
                        ${distance}
                    </div>
                    <div class="washroom-address">${washroom.address}</div>
                    <div class="washroom-details">
                        <span class="washroom-type">${this.formatWashroomType(washroom.washroom_type)}</span>
                        ${washroom.is_free ? '<span class="free-tag">Free</span>' : '<span class="paid-tag">Paid</span>'}
                        ${washroom.is_open_24h ? '<span class="hours-tag">24h</span>' : '<span class="hours-tag">Limited</span>'}
                    </div>
                    ${washroom.opening_hours ? `<div class="opening-hours">${washroom.opening_hours}</div>` : ''}
                </div>
            `;
        }).join('');

        container.innerHTML = washroomsHtml;
    }

    async showWashroomDetails(washroomId) {
        const washroom = typeof washroomId === 'string' ? 
            this.filteredWashrooms.find(w => w.id === washroomId) : 
            washroomId;

        if (!washroom) return;

        const modal = document.getElementById('washroom-detail-modal');
        const title = document.getElementById('washroom-detail-title');
        const content = document.getElementById('washroom-detail-content');

        if (!modal || !title || !content) return;

        title.textContent = washroom.name;

        const accessibility = washroom.accessibility === 'wheelchair_accessible' ? 
            '<div class="detail-badge accessible"><i class="fas fa-wheelchair"></i> Wheelchair Accessible</div>' : 
            '<div class="detail-badge not-accessible">Not Wheelchair Accessible</div>';

        const distance = washroom.distance_from_user ? 
            `<div class="detail-distance">${(washroom.distance_from_user * 1000).toFixed(0)}m from your location</div>` : '';

        content.innerHTML = `
            <div class="washroom-details-content">
                <div class="detail-header">
                    <div class="detail-type">${this.formatWashroomType(washroom.washroom_type)}</div>
                    ${accessibility}
                </div>
                
                <div class="detail-section">
                    <h4><i class="fas fa-map-marker-alt"></i> Location</h4>
                    <div class="detail-address">${washroom.address}</div>
                    ${washroom.district ? `<div class="detail-district">District: ${washroom.district}</div>` : ''}
                    ${distance}
                </div>

                <div class="detail-section">
                    <h4><i class="fas fa-clock"></i> Availability</h4>
                    <div class="detail-tags">
                        ${washroom.is_free ? '<span class="detail-tag free">Free</span>' : '<span class="detail-tag paid">Paid</span>'}
                        ${washroom.is_open_24h ? '<span class="detail-tag hours">24 Hours</span>' : '<span class="detail-tag hours">Limited Hours</span>'}
                    </div>
                    ${washroom.opening_hours ? `<div class="opening-hours">${washroom.opening_hours}</div>` : ''}
                </div>

                ${washroom.description ? `
                    <div class="detail-section">
                        <h4><i class="fas fa-info-circle"></i> Additional Information</h4>
                        <div class="detail-description">${washroom.description}</div>
                    </div>
                ` : ''}

                ${washroom.contact_info ? `
                    <div class="detail-section">
                        <h4><i class="fas fa-phone"></i> Contact</h4>
                        <div class="detail-contact">${washroom.contact_info}</div>
                    </div>
                ` : ''}

                <div class="detail-actions">
                    <button class="primary-btn" onclick="washroomsManager.getDirections('${washroom.id}')">
                        <i class="fas fa-directions"></i> Get Directions
                    </button>
                    <button class="secondary-btn" onclick="washroomsManager.centerMapOnWashroom('${washroom.id}')">
                        <i class="fas fa-map"></i> Show on Map
                    </button>
                </div>
            </div>
        `;

        modal.style.display = 'block';
    }

    closeWashroomModal() {
        const modal = document.getElementById('washroom-detail-modal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    centerMapOnWashroom(washroomId) {
        const washroom = this.filteredWashrooms.find(w => w.id === washroomId);
        if (!washroom || !washroom.location || !this.washroomMap) return;

        this.washroomMap.setView([washroom.location.latitude, washroom.location.longitude], 18);
        this.closeWashroomModal();
        
        // Switch to washrooms tab if not already active
        const washroomsTab = document.querySelector('[data-tab="washrooms"]');
        if (washroomsTab && !washroomsTab.classList.contains('active')) {
            washroomsTab.click();
        }
    }

    getDirections(washroomId) {
        const washroom = this.filteredWashrooms.find(w => w.id === washroomId);
        if (!washroom || !washroom.location) return;

        const destination = `${washroom.location.latitude},${washroom.location.longitude}`;
        const url = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
        window.open(url, '_blank');
    }

    updateStatistics() {
        const foundCount = document.getElementById('washrooms-found');
        const accessibleCount = document.getElementById('washrooms-accessible');
        const freeCount = document.getElementById('washrooms-free');

        if (foundCount) {
            foundCount.textContent = this.filteredWashrooms.length;
        }

        if (accessibleCount) {
            const accessible = this.filteredWashrooms.filter(w => w.accessibility === 'wheelchair_accessible').length;
            accessibleCount.textContent = accessible;
        }

        if (freeCount) {
            const free = this.filteredWashrooms.filter(w => w.is_free).length;
            freeCount.textContent = free;
        }
    }

    clearFilters() {
        // Reset filter controls
        const typeFilter = document.getElementById('washroom-type-filter');
        const accessibilityFilter = document.getElementById('accessibility-filter');
        const freeOnlyFilter = document.getElementById('free-only-filter');
        const open24hFilter = document.getElementById('open-24h-filter');
        const radiusSlider = document.getElementById('washroom-radius');

        if (typeFilter) typeFilter.value = '';
        if (accessibilityFilter) accessibilityFilter.checked = false;
        if (freeOnlyFilter) freeOnlyFilter.checked = false;
        if (open24hFilter) open24hFilter.checked = false;
        if (radiusSlider) radiusSlider.value = 1000;

        // Reset filter state
        this.currentFilters = {
            type: '',
            accessibility: false,
            freeOnly: false,
            open24h: false,
            radius: 1000
        };

        // Update radius display
        const radiusValue = document.getElementById('washroom-radius-value');
        if (radiusValue) radiusValue.textContent = '1000m';

        // Apply filters
        this.filterWashrooms();
    }

    formatWashroomType(type) {
        switch (type) {
            case 'fixed':
                return 'Fixed Washroom';
            case 'mobile':
                return 'Mobile Washroom';
            case 'pissoir':
                return 'Pissoir';
            default:
                return 'Washroom';
        }
    }

    showSampleWashrooms() {
        // Show sample data when API is not available
        this.washrooms = [
            {
                id: 'sample1',
                name: 'Zurich Main Station',
                address: 'Bahnhofplatz, 8001 Zürich',
                location: { latitude: 47.3781, longitude: 8.5402 },
                washroom_type: 'fixed',
                accessibility: 'wheelchair_accessible',
                is_free: false,
                is_open_24h: true,
                opening_hours: '24 hours',
                description: 'Clean washrooms located in the main train station',
                district: 'Kreis 1'
            },
            {
                id: 'sample2',
                name: 'Lindenhof Park',
                address: 'Lindenhof, 8001 Zürich',
                location: { latitude: 47.3722, longitude: 8.5420 },
                washroom_type: 'fixed',
                accessibility: 'not_wheelchair_accessible',
                is_free: true,
                is_open_24h: false,
                opening_hours: '6:00 - 22:00',
                description: 'Public washroom in the historic park',
                district: 'Kreis 1'
            }
        ];
        
        this.filteredWashrooms = [...this.washrooms];
        this.displayWashrooms();
        this.updateStatistics();
    }
}

// Initialize washrooms manager when the page loads
let washroomsManager;

document.addEventListener('DOMContentLoaded', function() {
    washroomsManager = new WashroomsManager();
});
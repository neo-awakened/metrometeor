// Traffic module for handling traffic-related functionality
class TrafficManager {
    constructor() {
        this.currentTrafficData = null;
        this.refreshInterval = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Auto-refresh traffic data when tab becomes active
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.isTrafficTabActive()) {
                this.loadTrafficData();
            }
        });
    }

    isTrafficTabActive() {
        const trafficTab = document.getElementById('traffic-tab');
        return trafficTab && trafficTab.classList.contains('active');
    }

    async loadTrafficData() {
        try {
            LoadingManager.show('Loading traffic data...');
            
            const data = await apiService.getTrafficStatus();
            this.currentTrafficData = data;
            
            this.renderTrafficLevel(data.current_traffic_level);
            this.renderDisruptions(data.disruptions);
            this.renderTrafficIndicators(data.disruptions);
            
            // Update map markers
            if (mapService.map) {
                mapService.addTrafficMarkers(data.disruptions);
            }
            
            ToastManager.show('Traffic data updated', 'success');
            
        } catch (error) {
            console.error('Failed to load traffic data:', error);
            Utils.handleError(error, 'Loading traffic data');
        } finally {
            LoadingManager.hide();
        }
    }

    renderTrafficLevel(level) {
        const levelElement = document.getElementById('current-traffic-level');
        if (!levelElement) return;

        const trafficInfo = CONFIG.TRAFFIC_LEVELS[level] || CONFIG.TRAFFIC_LEVELS.moderate;
        
        levelElement.innerHTML = `
            <span class="level-indicator ${level}"></span>
            <span class="level-text">${trafficInfo.label} Traffic</span>
        `;
        
        levelElement.setAttribute('title', trafficInfo.description);
    }

    renderDisruptions(disruptions) {
        const container = document.getElementById('disruptions-list');
        if (!container) return;

        if (disruptions.length === 0) {
            container.innerHTML = `
                <div class="no-disruptions">
                    <i class="fas fa-check-circle" style="color: #4CAF50; font-size: 2rem;"></i>
                    <h4>All Clear!</h4>
                    <p>No traffic disruptions reported in your area.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = disruptions.map(disruption => this.createDisruptionItem(disruption)).join('');
    }

    createDisruptionItem(disruption) {
        const severityColors = {
            low: '#4CAF50',
            normal: '#FFC107', 
            high: '#FF5722',
            severe: '#F44336'
        };

        const color = severityColors[disruption.severity] || severityColors.normal;
        const startTime = Utils.formatRelativeTime(disruption.start_time);
        const endTime = disruption.end_time ? Utils.formatRelativeTime(disruption.end_time) : 'Unknown';
        const distance = disruption.distance_km ? Utils.formatDistance(disruption.distance_km) : '';
        
        return `
            <div class="disruption-item">
                <div class="disruption-header">
                    <h4>${disruption.title}</h4>
                    <span class="traffic-severity ${disruption.severity}" style="background: ${color}">
                        ${Utils.capitalize(disruption.severity)}
                    </span>
                </div>
                <p class="disruption-description">${disruption.description}</p>
                <div class="disruption-details">
                    <div class="detail-item">
                        <i class="fas fa-clock"></i>
                        <span>Started ${startTime}</span>
                    </div>
                    ${disruption.end_time ? `
                        <div class="detail-item">
                            <i class="fas fa-hourglass-end"></i>
                            <span>Expected end: ${endTime}</span>
                        </div>
                    ` : ''}
                    ${distance ? `
                        <div class="detail-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${distance}</span>
                        </div>
                    ` : ''}
                </div>
                ${disruption.affected_routes.length > 0 ? `
                    <div class="affected-routes">
                        <strong>Affected Routes:</strong>
                        <div class="route-tags">
                            ${disruption.affected_routes.map(route => `
                                <span class="route-tag">${route}</span>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    renderTrafficIndicators(disruptions) {
        const container = document.getElementById('traffic-indicators-list');
        if (!container) return;

        // Show only most relevant disruptions for dashboard
        const relevantDisruptions = disruptions.slice(0, 3);
        
        if (relevantDisruptions.length === 0) {
            container.innerHTML = `
                <div class="no-traffic-issues">
                    <p><i class="fas fa-check-circle"></i> No traffic issues in your area</p>
                </div>
            `;
            return;
        }

        container.innerHTML = relevantDisruptions.map(disruption => {
            const distance = disruption.distance_km ? Utils.formatDistance(disruption.distance_km) : '';
            return `
                <div class="traffic-item">
                    <h5>${disruption.title}</h5>
                    <p>${Utils.truncateText(disruption.description, 80)}</p>
                    ${distance ? `<span class="traffic-severity ${disruption.severity}">${distance}</span>` : ''}
                </div>
            `;
        }).join('');
    }

    startAutoRefresh() {
        this.stopAutoRefresh();
        this.refreshInterval = setInterval(() => {
            if (this.isTrafficTabActive()) {
                this.loadTrafficData();
            }
        }, CONFIG.UPDATE_INTERVALS.TRAFFIC);
    }

    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    async updateQuickStats() {
        try {
            const data = await apiService.getQuickStats();
            
            // Update traffic status in quick stats
            const trafficStat = document.getElementById('traffic-status');
            if (trafficStat) {
                const trafficInfo = CONFIG.TRAFFIC_LEVELS[data.traffic_level] || CONFIG.TRAFFIC_LEVELS.moderate;
                const valueElement = trafficStat.querySelector('.stat-value');
                const labelElement = trafficStat.querySelector('.stat-label');
                
                if (valueElement) valueElement.textContent = trafficInfo.label;
                if (labelElement) labelElement.textContent = 'Traffic';
                
                trafficStat.style.borderLeft = `4px solid ${trafficInfo.color}`;
                trafficStat.setAttribute('title', trafficInfo.description);
            }
            
            return data;
        } catch (error) {
            console.error('Failed to update quick stats:', error);
            return null;
        }
    }
}

// Create global traffic manager instance
const trafficManager = new TrafficManager();
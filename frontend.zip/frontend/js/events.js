// Events module for handling event-related functionality
class EventsManager {
    constructor() {
        this.currentEvents = [];
        this.currentPage = 1;
        this.currentFilters = {
            event_type: '',
            sort_by: 'date',
            per_page: CONFIG.PAGINATION.EVENTS_PER_PAGE
        };
        this.isLoading = false;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadEventCategories();
    }

    setupEventListeners() {
        // Filter change handlers
        const typeFilter = document.getElementById('event-type-filter');
        const sortSelect = document.getElementById('event-sort');

        if (typeFilter) {
            typeFilter.addEventListener('change', (e) => {
                this.currentFilters.event_type = e.target.value;
                this.currentPage = 1;
                this.loadEvents();
            });
        }

        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.currentFilters.sort_by = e.target.value;
                this.currentPage = 1;
                this.loadEvents();
            });
        }

        // Event card click handlers will be attached dynamically
    }

    async loadEventCategories() {
        try {
            const data = await apiService.getEventCategories();
            this.populateEventTypeFilter(data.categories);
        } catch (error) {
            console.error('Failed to load event categories:', error);
        }
    }

    populateEventTypeFilter(categories) {
        const select = document.getElementById('event-type-filter');
        if (!select) return;

        // Clear existing options except the first one
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }

        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.value;
            option.textContent = category.label;
            select.appendChild(option);
        });
    }

    async loadEvents(showLoading = true) {
        if (this.isLoading) return;
        
        this.isLoading = true;
        
        if (showLoading) {
            LoadingManager.show('Loading events...');
        }

        try {
            const filters = {
                ...this.currentFilters,
                page: this.currentPage
            };

            const data = await apiService.getEvents(filters);
            this.currentEvents = data.events;
            
            this.renderEvents(data.events);
            this.renderPagination(data.pagination);
            
            // Update map markers if on home tab
            if (document.getElementById('home-tab').classList.contains('active')) {
                mapService.addEventMarkers(data.events);
            }

        } catch (error) {
            console.error('Failed to load events:', error);
            Utils.handleError(error, 'Loading events');
        } finally {
            this.isLoading = false;
            if (showLoading) {
                LoadingManager.hide();
            }
        }
    }

    renderEvents(events) {
        const container = document.getElementById('events-grid');
        if (!container) return;

        if (events.length === 0) {
            container.innerHTML = `
                <div class="no-events">
                    <i class="fas fa-calendar-times"></i>
                    <h3>No events found</h3>
                    <p>Try adjusting your filters or check back later.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = events.map(event => this.createEventCard(event)).join('');
        
        // Attach event listeners to cards
        container.querySelectorAll('.event-card').forEach(card => {
            card.addEventListener('click', () => {
                const eventId = card.dataset.eventId;
                this.showEventDetails(eventId);
            });
        });
    }

    createEventCard(event) {
        const categoryInfo = CONFIG.EVENT_CATEGORIES[event.event_type] || CONFIG.EVENT_CATEGORIES.other;
        const startTime = Utils.formatDateTime(event.start_time);
        const price = event.price ? Utils.formatPrice(event.price) : 'Free';
        const distance = event.distance_km ? Utils.formatDistance(event.distance_km) : '';
        
        return `
            <div class="event-card" data-event-id="${event.id}">
                <div class="event-image" style="background: linear-gradient(45deg, ${categoryInfo.color}, ${Utils.adjustColor(categoryInfo.color, 20)})">
                    <i class="${categoryInfo.icon}"></i>
                </div>
                <div class="event-content">
                    <h3>${event.title}</h3>
                    <p class="event-time">
                        <i class="fas fa-clock"></i>
                        ${startTime}
                    </p>
                    ${event.location.address ? `
                        <p class="event-location">
                            <i class="fas fa-map-marker-alt"></i>
                            ${event.location.address}
                        </p>
                    ` : ''}
                    ${event.description ? `
                        <p class="event-description">
                            ${Utils.truncateText(event.description, 100)}
                        </p>
                    ` : ''}
                    <div class="event-meta">
                        <span class="event-price">${price}</span>
                        <span class="event-category" style="background: ${categoryInfo.color}">
                            ${categoryInfo.label}
                        </span>
                    </div>
                    ${distance ? `
                        <div class="event-distance">
                            <i class="fas fa-map-marker-alt"></i>
                            ${distance}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }

    renderPagination(pagination) {
        const container = document.getElementById('events-pagination');
        if (!container || !pagination) return;

        if (pagination.total_pages <= 1) {
            container.innerHTML = '';
            return;
        }

        const { page, total_pages } = pagination;
        let paginationHTML = '';

        // Previous button
        paginationHTML += `
            <button ${page <= 1 ? 'disabled' : ''} data-page="${page - 1}">
                <i class="fas fa-chevron-left"></i>
            </button>
        `;

        // Page numbers
        const startPage = Math.max(1, page - 2);
        const endPage = Math.min(total_pages, page + 2);

        if (startPage > 1) {
            paginationHTML += `<button data-page="1">1</button>`;
            if (startPage > 2) {
                paginationHTML += `<span>...</span>`;
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            paginationHTML += `
                <button ${i === page ? 'class="active"' : ''} data-page="${i}">
                    ${i}
                </button>
            `;
        }

        if (endPage < total_pages) {
            if (endPage < total_pages - 1) {
                paginationHTML += `<span>...</span>`;
            }
            paginationHTML += `<button data-page="${total_pages}">${total_pages}</button>`;
        }

        // Next button
        paginationHTML += `
            <button ${page >= total_pages ? 'disabled' : ''} data-page="${page + 1}">
                <i class="fas fa-chevron-right"></i>
            </button>
        `;

        container.innerHTML = paginationHTML;

        // Attach click handlers
        container.querySelectorAll('button[data-page]').forEach(button => {
            button.addEventListener('click', () => {
                const newPage = parseInt(button.dataset.page);
                if (newPage !== this.currentPage && !button.disabled) {
                    this.currentPage = newPage;
                    this.loadEvents();
                }
            });
        });
    }

    async showEventDetails(eventId) {
        try {
            LoadingManager.show('Loading event details...');
            
            const eventData = await apiService.getEventDetails(eventId);
            this.renderEventDetailsModal(eventData);
            ModalManager.show('event-detail-modal');
            
        } catch (error) {
            console.error('Failed to load event details:', error);
            Utils.handleError(error, 'Loading event details');
        } finally {
            LoadingManager.hide();
        }
    }

    renderEventDetailsModal(event) {
        const titleElement = document.getElementById('event-detail-title');
        const contentElement = document.getElementById('event-detail-content');
        
        if (!titleElement || !contentElement) return;

        titleElement.textContent = event.title;

        const categoryInfo = CONFIG.EVENT_CATEGORIES[event.event_type] || CONFIG.EVENT_CATEGORIES.other;
        const startTime = Utils.formatDateTime(event.start_time);
        const endTime = Utils.formatDateTime(event.end_time);
        const price = event.price ? Utils.formatPrice(event.price) : 'Free';
        const distance = event.distance_km ? Utils.formatDistance(event.distance_km) : '';

        let routeOptionsHTML = '';
        if (event.route_options && event.route_options.length > 0) {
            routeOptionsHTML = `
                <div class="route-options">
                    <h4><i class="fas fa-route"></i> How to get there</h4>
                    <div class="routes-list">
                        ${event.route_options.map(route => `
                            <div class="route-option">
                                <div class="route-info">
                                    <h5>${route.description}</h5>
                                    <p><i class="fas fa-clock"></i> ${Utils.formatDuration(route.duration_minutes)}</p>
                                    <p><i class="fas fa-route"></i> ${Utils.formatDistance(route.distance_km)}</p>
                                    ${route.estimated_cost > 0 ? `<p><i class="fas fa-coins"></i> ${Utils.formatPrice(route.estimated_cost)}</p>` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        let crowdPredictionsHTML = '';
        if (event.crowd_predictions && event.crowd_predictions.length > 0) {
            crowdPredictionsHTML = `
                <div class="crowd-predictions">
                    <h4><i class="fas fa-users"></i> Crowd Predictions</h4>
                    <div class="predictions-timeline">
                        ${event.crowd_predictions.slice(0, 8).map(prediction => `
                            <div class="prediction-item">
                                <div class="prediction-time">${Utils.formatTime(prediction.time)}</div>
                                <div class="prediction-bar">
                                    <div class="prediction-level" style="width: ${prediction.crowd_level * 100}%; background: ${this.getCrowdColor(prediction.crowd_level)}"></div>
                                </div>
                                <div class="prediction-label">${prediction.description}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        let amenitiesHTML = '';
        if (event.nearby_amenities && event.nearby_amenities.length > 0) {
            amenitiesHTML = `
                <div class="nearby-amenities">
                    <h4><i class="fas fa-map-signs"></i> Nearby Amenities</h4>
                    <div class="amenities-list">
                        ${event.nearby_amenities.map(amenity => `
                            <div class="amenity-item">
                                <i class="${this.getAmenityIcon(amenity.type)}"></i>
                                <div class="amenity-info">
                                    <h5>${amenity.name}</h5>
                                    <p>${amenity.distance_meters}m away</p>
                                    ${amenity.price || amenity.rating ? `<small>${amenity.price || `Rating: ${amenity.rating}`}</small>` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        contentElement.innerHTML = `
            <div class="event-detail-header">
                <div class="event-category-badge" style="background: ${categoryInfo.color}">
                    <i class="${categoryInfo.icon}"></i>
                    ${categoryInfo.label}
                </div>
                ${distance ? `<div class="event-distance-badge">${distance}</div>` : ''}
            </div>

            <div class="event-detail-info">
                <div class="event-time-info">
                    <h4><i class="fas fa-calendar-alt"></i> When</h4>
                    <p><strong>Starts:</strong> ${startTime}</p>
                    <p><strong>Ends:</strong> ${endTime}</p>
                </div>

                <div class="event-location-info">
                    <h4><i class="fas fa-map-marker-alt"></i> Where</h4>
                    <p>${event.location.address || 'Location details not available'}</p>
                </div>

                <div class="event-price-info">
                    <h4><i class="fas fa-ticket-alt"></i> Price</h4>
                    <p class="price-display">${price}</p>
                </div>
            </div>

            ${event.description ? `
                <div class="event-description">
                    <h4><i class="fas fa-info-circle"></i> About this event</h4>
                    <p>${event.description}</p>
                </div>
            ` : ''}

            ${event.organizer ? `
                <div class="event-organizer">
                    <h4><i class="fas fa-user"></i> Organizer</h4>
                    <p>${event.organizer}</p>
                </div>
            ` : ''}

            ${routeOptionsHTML}
            ${crowdPredictionsHTML}
            ${amenitiesHTML}

            <div class="event-actions">
                ${event.website_url ? `
                    <a href="${event.website_url}" target="_blank" class="primary-btn">
                        <i class="fas fa-external-link-alt"></i>
                        Visit Website
                    </a>
                ` : ''}
                <button class="secondary-btn" onclick="this.shareEvent('${event.id}')">
                    <i class="fas fa-share-alt"></i>
                    Share Event
                </button>
            </div>
        `;
    }

    getCrowdColor(level) {
        if (level < 0.3) return '#4CAF50';
        if (level < 0.6) return '#FFC107';
        if (level < 0.8) return '#FF9800';
        return '#F44336';
    }

    getAmenityIcon(type) {
        const icons = {
            parking: 'fas fa-parking',
            restaurant: 'fas fa-utensils',
            bathroom: 'fas fa-restroom',
            atm: 'fas fa-credit-card',
            hotel: 'fas fa-bed',
            shop: 'fas fa-shopping-bag'
        };
        return icons[type] || 'fas fa-map-marker-alt';
    }

    shareEvent(eventId) {
        const event = this.currentEvents.find(e => e.id === eventId);
        if (!event) return;

        if (navigator.share) {
            navigator.share({
                title: event.title,
                text: event.description || `Check out ${event.title}`,
                url: window.location.href
            }).catch(console.error);
        } else {
            // Fallback: copy to clipboard
            const text = `${event.title} - ${window.location.href}`;
            navigator.clipboard.writeText(text).then(() => {
                ToastManager.show('Event link copied to clipboard!', 'success');
            }).catch(() => {
                ToastManager.show('Unable to share event', 'error');
            });
        }
    }

    // Update nearby events for home dashboard
    async updateNearbyEvents() {
        try {
            const data = await apiService.getNearbyEvents(CONFIG.DEFAULT_RADIUS, 10);
            this.renderNearbyEventsList(data.events);
            return data.events;
        } catch (error) {
            console.error('Failed to update nearby events:', error);
            return [];
        }
    }

    renderNearbyEventsList(events) {
        const container = document.getElementById('nearby-events-list');
        if (!container) return;

        if (events.length === 0) {
            container.innerHTML = `
                <div class="no-events-message">
                    <p>No nearby events found</p>
                </div>
            `;
            return;
        }

        container.innerHTML = events.map(event => {
            const categoryInfo = CONFIG.EVENT_CATEGORIES[event.event_type] || CONFIG.EVENT_CATEGORIES.other;
            const startTime = Utils.formatRelativeTime(event.start_time);
            const distance = event.distance_km ? Utils.formatDistance(event.distance_km) : '';
            
            return `
                <div class="event-item" data-event-id="${event.id}">
                    <h5>${event.title}</h5>
                    <p class="event-time-distance">
                        <i class="fas fa-clock"></i> ${startTime}
                        ${distance ? ` • <i class="fas fa-map-marker-alt"></i> ${distance}` : ''}
                    </p>
                    <span class="event-distance" style="background: ${categoryInfo.color}">
                        ${categoryInfo.label}
                    </span>
                </div>
            `;
        }).join('');

        // Attach click handlers
        container.querySelectorAll('.event-item').forEach(item => {
            item.addEventListener('click', () => {
                const eventId = item.dataset.eventId;
                this.showEventDetails(eventId);
            });
        });
    }

    // Search events
    async searchEvents(query) {
        try {
            const data = await apiService.search(query);
            return data.events || [];
        } catch (error) {
            console.error('Failed to search events:', error);
            return [];
        }
    }

    // Reset filters
    resetFilters() {
        this.currentFilters = {
            event_type: '',
            sort_by: 'date',
            per_page: CONFIG.PAGINATION.EVENTS_PER_PAGE
        };
        this.currentPage = 1;
        
        // Reset UI controls
        const typeFilter = document.getElementById('event-type-filter');
        const sortSelect = document.getElementById('event-sort');
        
        if (typeFilter) typeFilter.value = '';
        if (sortSelect) sortSelect.value = 'date';
        
        this.loadEvents();
    }
}

// Create global events manager instance
const eventsManager = new EventsManager();
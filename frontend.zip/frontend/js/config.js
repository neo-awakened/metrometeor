// Configuration settings for the Zurich Mobility App
const CONFIG = {
    // API Configuration
    API_BASE_URL: 'http://localhost:8000',
    
    // Map Configuration
    MAP: {
        DEFAULT_CENTER: [47.3769, 8.5417], // Zurich coordinates
        DEFAULT_ZOOM: 13,
        MIN_ZOOM: 10,
        MAX_ZOOM: 18,
        TILE_LAYER: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        ATTRIBUTION: '© OpenStreetMap contributors'
    },
    
    // Default search radius in kilometers
    DEFAULT_RADIUS: 5.0,
    
    // Update intervals in milliseconds
    UPDATE_INTERVALS: {
        DASHBOARD: 60000,      // 1 minute
        TRAFFIC: 30000,        // 30 seconds
        EVENTS: 300000,        // 5 minutes
        LOCATION: 10000        // 10 seconds
    },
    
    // UI Configuration
    UI: {
        ANIMATION_DURATION: 300,
        TOAST_DURATION: 5000,
        LOADING_MIN_TIME: 1000
    },
    
    // Feature toggles
    FEATURES: {
        LOCATION_SHARING: true,
        REAL_TIME_UPDATES: true,
        PUSH_NOTIFICATIONS: false,
        OFFLINE_MODE: false
    },
    
    // Error messages
    ERRORS: {
        LOCATION_DENIED: 'Location access denied. Please enable location services.',
        NETWORK_ERROR: 'Network error. Please check your connection.',
        API_ERROR: 'Unable to fetch data. Please try again later.',
        INVALID_DATA: 'Invalid data received from server.'
    },
    
    // Success messages
    SUCCESS: {
        LOCATION_FOUND: 'Location found successfully',
        DATA_LOADED: 'Data loaded successfully',
        SAVED: 'Settings saved successfully'
    },
    
    // Event categories with colors and icons
    EVENT_CATEGORIES: {
        music: {
            label: 'Music & Festivals',
            color: '#9C27B0',
            icon: 'fas fa-music'
        },
        food: {
            label: 'Food Events',
            color: '#FF9800',
            icon: 'fas fa-utensils'
        },
        sports: {
            label: 'Sports',
            color: '#4CAF50',
            icon: 'fas fa-futbol'
        },
        cultural: {
            label: 'Cultural',
            color: '#2196F3',
            icon: 'fas fa-theater-masks'
        },
        other: {
            label: 'Other Events',
            color: '#795548',
            icon: 'fas fa-calendar'
        }
    },
    
    // Traffic levels with colors
    TRAFFIC_LEVELS: {
        low: {
            label: 'Low',
            color: '#4CAF50',
            description: 'Traffic is flowing smoothly'
        },
        moderate: {
            label: 'Moderate',
            color: '#FFC107',
            description: 'Some delays expected'
        },
        high: {
            label: 'High',
            color: '#FF5722',
            description: 'Heavy traffic, plan extra time'
        },
        severe: {
            label: 'Severe',
            color: '#F44336',
            description: 'Severe delays, consider alternatives'
        }
    },
    
    // Deal categories
    DEAL_CATEGORIES: {
        transport: {
            label: 'Transport Passes',
            icon: 'fas fa-train',
            color: '#2196F3'
        },
        events: {
            label: 'Event Tickets',
            icon: 'fas fa-ticket-alt',
            color: '#9C27B0'
        },
        accommodation: {
            label: 'Hotels & Stays',
            icon: 'fas fa-bed',
            color: '#FF9800'
        },
        food: {
            label: 'Food & Drinks',
            icon: 'fas fa-utensils',
            color: '#4CAF50'
        },
        merchandise: {
            label: 'Merchandise',
            icon: 'fas fa-shopping-bag',
            color: '#795548'
        }
    },
    
    // Emergency services
    EMERGENCY_SERVICES: {
        police: {
            number: '117',
            color: '#1976D2',
            icon: 'fas fa-shield-alt'
        },
        medical: {
            number: '144',
            color: '#D32F2F',
            icon: 'fas fa-ambulance'
        },
        fire: {
            number: '118',
            color: '#F57C00',
            icon: 'fas fa-fire-extinguisher'
        }
    },
    
    // Pagination
    PAGINATION: {
        EVENTS_PER_PAGE: 20,
        DEALS_PER_PAGE: 12,
        GROUPS_PER_PAGE: 10
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
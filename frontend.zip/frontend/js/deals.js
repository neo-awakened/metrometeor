// Deals module for handling deals and tickets functionality
class DealsManager {
    constructor() {
        this.currentDeals = [];
        this.currentFilters = {
            category: ''
        };
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadDealCategories();
    }

    setupEventListeners() {
        const categoryFilter = document.getElementById('deal-category-filter');
        
        if (categoryFilter) {
            categoryFilter.addEventListener('change', (e) => {
                this.currentFilters.category = e.target.value;
                this.loadDeals();
            });
        }
    }

    async loadDealCategories() {
        try {
            const data = await apiService.getDealCategories();
            this.populateCategoryFilter(data.categories);
        } catch (error) {
            console.error('Failed to load deal categories:', error);
        }
    }

    populateCategoryFilter(categories) {
        const select = document.getElementById('deal-category-filter');
        if (!select) return;

        // Clear existing options except the first one
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }

        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.value;
            option.textContent = category.label;
            select.appendChild(option);
        });
    }

    async loadDeals() {
        try {
            LoadingManager.show('Loading deals...');
            
            const data = await apiService.getDeals(this.currentFilters);
            this.currentDeals = data.deals;
            
            this.renderDeals(data.deals);
            this.updateSavingsSummary(data.total_savings);
            
        } catch (error) {
            console.error('Failed to load deals:', error);
            Utils.handleError(error, 'Loading deals');
        } finally {
            LoadingManager.hide();
        }
    }

    renderDeals(deals) {
        const container = document.getElementById('deals-grid');
        if (!container) return;

        if (deals.length === 0) {
            container.innerHTML = `
                <div class="no-deals">
                    <i class="fas fa-tag"></i>
                    <h3>No deals found</h3>
                    <p>Try adjusting your filters or check back later for new offers.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = deals.map(deal => this.createDealCard(deal)).join('');
        
        // Attach event listeners
        container.querySelectorAll('.deal-card').forEach(card => {
            card.addEventListener('click', () => {
                const dealId = card.dataset.dealId;
                this.showDealDetails(dealId);
            });
        });
    }

    createDealCard(deal) {
        const categoryInfo = CONFIG.DEAL_CATEGORIES[deal.category] || {
            label: 'Other',
            icon: 'fas fa-tag',
            color: '#795548'
        };
        
        const expiresIn = this.getExpiresIn(deal.valid_until);
        const savings = deal.original_price - deal.discounted_price;
        
        return `
            <div class="deal-card" data-deal-id="${deal.id}">
                <div class="deal-image" style="background: linear-gradient(45deg, ${categoryInfo.color}, ${Utils.adjustColor(categoryInfo.color, 20)})">
                    <i class="${categoryInfo.icon}"></i>
                </div>
                <div class="deal-content">
                    <h3>${deal.title}</h3>
                    <p>${Utils.truncateText(deal.description, 100)}</p>
                    
                    <div class="deal-pricing">
                        <span class="original-price">${Utils.formatCurrency(deal.original_price)}</span>
                        <span class="discounted-price">${Utils.formatCurrency(deal.discounted_price)}</span>
                        <span class="discount-badge">${deal.discount_percentage}% OFF</span>
                    </div>
                    
                    <div class="deal-savings">
                        <strong>You save: ${Utils.formatCurrency(savings)}</strong>
                    </div>
                    
                    <div class="deal-footer">
                        <span class="deal-vendor">
                            <i class="fas fa-store"></i>
                            ${deal.vendor}
                        </span>
                        <span class="deal-expires ${expiresIn.urgent ? 'urgent' : ''}">
                            <i class="fas fa-clock"></i>
                            ${expiresIn.text}
                        </span>
                    </div>
                </div>
            </div>
        `;
    }

    getExpiresIn(validUntil) {
        const now = new Date();
        const expiry = new Date(validUntil);
        const diffMs = expiry - now;
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) {
            return { text: 'Expired', urgent: true };
        } else if (diffDays === 0) {
            return { text: 'Expires today', urgent: true };
        } else if (diffDays === 1) {
            return { text: 'Expires tomorrow', urgent: true };
        } else if (diffDays <= 7) {
            return { text: `${diffDays} days left`, urgent: true };
        } else {
            return { text: `${diffDays} days left`, urgent: false };
        }
    }

    updateSavingsSummary(totalSavings) {
        const summaryElement = document.getElementById('savings-summary');
        if (!summaryElement) return;
        
        const amountElement = summaryElement.querySelector('.savings-amount');
        if (amountElement) {
            amountElement.textContent = Utils.formatCurrency(totalSavings);
        }
    }

    showDealDetails(dealId) {
        const deal = this.currentDeals.find(d => d.id === dealId);
        if (!deal) return;
        
        // For now, show a simple alert. In a real app, this would open a detailed modal
        const message = `
            ${deal.title}\n
            ${deal.description}\n
            Original Price: ${Utils.formatCurrency(deal.original_price)}\n
            Discounted Price: ${Utils.formatCurrency(deal.discounted_price)}\n
            You Save: ${Utils.formatCurrency(deal.original_price - deal.discounted_price)}\n
            Vendor: ${deal.vendor}\n
            Valid Until: ${Utils.formatDate(deal.valid_until)}
        `;
        
        if (confirm(message + '\n\nWould you like to learn more about this deal?')) {
            // In a real app, this would redirect to the vendor's website or booking page
            ToastManager.show('Redirecting to deal details...', 'info');
        }
    }

    // Filter deals by category
    filterByCategory(category) {
        this.currentFilters.category = category;
        
        const categoryFilter = document.getElementById('deal-category-filter');
        if (categoryFilter) {
            categoryFilter.value = category;
        }
        
        this.loadDeals();
    }

    // Reset filters
    resetFilters() {
        this.currentFilters = { category: '' };
        
        const categoryFilter = document.getElementById('deal-category-filter');
        if (categoryFilter) {
            categoryFilter.value = '';
        }
        
        this.loadDeals();
    }
}

// Create global deals manager instance
const dealsManager = new DealsManager();
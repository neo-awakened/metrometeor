// Group Planner module for handling group planning functionality
class PlannerManager {
    constructor() {
        this.currentGroups = [];
        this.selectedGroup = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        const createGroupBtn = document.getElementById('create-group-btn');
        
        if (createGroupBtn) {
            createGroupBtn.addEventListener('click', () => {
                this.showCreateGroupModal();
            });
        }
    }

    async loadGroups() {
        try {
            LoadingManager.show('Loading groups...');
            
            const data = await apiService.getGroups();
            this.currentGroups = data.groups || [];
            
            this.renderGroups(this.currentGroups);
            
        } catch (error) {
            console.error('Failed to load groups:', error);
            // Show mock data for demonstration
            this.loadMockGroups();
        } finally {
            LoadingManager.hide();
        }
    }

    loadMockGroups() {
        const mockGroups = [
            {
                id: 'group1',
                name: 'Weekend Festival Crew',
                description: 'Planning to attend the Zurich Music Festival this weekend',
                created_by: 'user1',
                members: [
                    { id: 'user1', name: 'Alice', avatar_url: null, is_online: true },
                    { id: 'user2', name: 'Bob', avatar_url: null, is_online: false },
                    { id: 'user3', name: 'Charlie', avatar_url: null, is_online: true }
                ],
                events: ['event1', 'event2'],
                meeting_point: { latitude: 47.3769, longitude: 8.5417, address: 'Zurich HB' },
                is_location_sharing_enabled: true,
                created_at: '2023-10-01T10:00:00Z'
            },
            {
                id: 'group2',
                name: 'Food Tour Group',
                description: 'Exploring the best restaurants in Zurich',
                created_by: 'user1',
                members: [
                    { id: 'user1', name: 'Alice', avatar_url: null, is_online: true },
                    { id: 'user4', name: 'David', avatar_url: null, is_online: true }
                ],
                events: ['event3'],
                meeting_point: null,
                is_location_sharing_enabled: false,
                created_at: '2023-09-28T14:30:00Z'
            }
        ];
        
        this.currentGroups = mockGroups;
        this.renderGroups(mockGroups);
    }

    renderGroups(groups) {
        const container = document.getElementById('groups-list');
        if (!container) return;

        if (groups.length === 0) {
            container.innerHTML = `
                <div class="no-groups">
                    <i class="fas fa-users"></i>
                    <h3>No groups yet</h3>
                    <p>Create your first group to start planning events with friends!</p>
                    <button class="primary-btn" onclick="plannerManager.showCreateGroupModal()">
                        <i class="fas fa-plus"></i>
                        Create Group
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = groups.map(group => this.createGroupCard(group)).join('');
        
        // Attach event listeners
        container.querySelectorAll('.group-card').forEach(card => {
            card.addEventListener('click', () => {
                const groupId = card.dataset.groupId;
                this.selectGroup(groupId);
            });
        });
    }

    createGroupCard(group) {
        const memberCount = group.members.length;
        const onlineCount = group.members.filter(m => m.is_online).length;
        const createdDate = Utils.formatRelativeTime(group.created_at);
        
        return `
            <div class="group-card" data-group-id="${group.id}">
                <div class="group-header">
                    <h3>${group.name}</h3>
                    <div class="group-status">
                        <span class="member-count">
                            <i class="fas fa-users"></i>
                            ${memberCount}
                        </span>
                        <span class="online-count">
                            <i class="fas fa-circle" style="color: #4CAF50;"></i>
                            ${onlineCount}
                        </span>
                    </div>
                </div>
                
                ${group.description ? `
                    <p class="group-description">${Utils.truncateText(group.description, 100)}</p>
                ` : ''}
                
                <div class="group-members">
                    ${group.members.slice(0, 4).map(member => `
                        <div class="member-avatar ${member.is_online ? 'online' : 'offline'}" title="${member.name} (${member.is_online ? 'Online' : 'Offline'})">
                            ${member.avatar_url ? 
                                `<img src="${member.avatar_url}" alt="${member.name}">` :
                                member.name.charAt(0).toUpperCase()
                            }
                        </div>
                    `).join('')}
                    ${memberCount > 4 ? `<div class="member-avatar more">+${memberCount - 4}</div>` : ''}
                </div>
                
                <div class="group-meta">
                    ${group.meeting_point ? `
                        <span class="meeting-point">
                            <i class="fas fa-map-marker-alt"></i>
                            ${group.meeting_point.address || 'Meeting point set'}
                        </span>
                    ` : ''}
                    <span class="created-date">
                        <i class="fas fa-clock"></i>
                        Created ${createdDate}
                    </span>
                </div>
                
                ${group.events && group.events.length > 0 ? `
                    <div class="group-events">
                        <span class="events-count">
                            <i class="fas fa-calendar-alt"></i>
                            ${group.events.length} event${group.events.length > 1 ? 's' : ''}
                        </span>
                    </div>
                ` : ''}
            </div>
        `;
    }

    async selectGroup(groupId) {
        try {
            LoadingManager.show('Loading group details...');
            
            // In a real app, fetch detailed group data
            const group = this.currentGroups.find(g => g.id === groupId);
            if (!group) {
                throw new Error('Group not found');
            }
            
            this.selectedGroup = group;
            this.renderGroupDetails(group);
            
        } catch (error) {
            console.error('Failed to load group details:', error);
            Utils.handleError(error, 'Loading group details');
        } finally {
            LoadingManager.hide();
        }
    }

    renderGroupDetails(group) {
        const container = document.getElementById('group-details');
        if (!container) return;

        container.style.display = 'block';
        container.innerHTML = `
            <div class="group-details-header">
                <h2>${group.name}</h2>
                <div class="group-actions">
                    <button class="secondary-btn" onclick="plannerManager.addMember('${group.id}')">
                        <i class="fas fa-user-plus"></i>
                        Add Member
                    </button>
                    <button class="secondary-btn" onclick="plannerManager.editGroup('${group.id}')">
                        <i class="fas fa-edit"></i>
                        Edit
                    </button>
                </div>
            </div>
            
            ${group.description ? `
                <div class="group-description-full">
                    <p>${group.description}</p>
                </div>
            ` : ''}
            
            <div class="group-details-content">
                <div class="members-section">
                    <h3><i class="fas fa-users"></i> Members (${group.members.length})</h3>
                    <div class="members-grid">
                        ${group.members.map(member => `
                            <div class="member-item ${member.is_online ? 'online' : 'offline'}">
                                <div class="member-avatar-large">
                                    ${member.avatar_url ? 
                                        `<img src="${member.avatar_url}" alt="${member.name}">` :
                                        member.name.charAt(0).toUpperCase()
                                    }
                                    <div class="status-indicator"></div>
                                </div>
                                <div class="member-info">
                                    <h4>${member.name}</h4>
                                    <p class="member-status">${member.is_online ? 'Online' : 'Offline'}</p>
                                    ${member.last_seen && !member.is_online ? `
                                        <p class="last-seen">Last seen ${Utils.formatRelativeTime(member.last_seen)}</p>
                                    ` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                ${group.meeting_point ? `
                    <div class="meeting-point-section">
                        <h3><i class="fas fa-map-marker-alt"></i> Meeting Point</h3>
                        <div class="meeting-point-details">
                            <p>${group.meeting_point.address || 'Custom location'}</p>
                            <button class="secondary-btn" onclick="plannerManager.showOnMap(${group.meeting_point.latitude}, ${group.meeting_point.longitude})">
                                <i class="fas fa-map"></i>
                                Show on Map
                            </button>
                        </div>
                    </div>
                ` : ''}
                
                <div class="location-sharing-section">
                    <h3><i class="fas fa-share-alt"></i> Location Sharing</h3>
                    <div class="toggle-switch">
                        <input type="checkbox" id="group-location-sharing" ${group.is_location_sharing_enabled ? 'checked' : ''}>
                        <label for="group-location-sharing">Share location with group members</label>
                    </div>
                </div>
                
                ${group.events && group.events.length > 0 ? `
                    <div class="group-events-section">
                        <h3><i class="fas fa-calendar-alt"></i> Planned Events</h3>
                        <div class="group-events-list">
                            ${group.events.map(eventId => `
                                <div class="group-event-item">
                                    <i class="fas fa-calendar-alt"></i>
                                    <span>Event ${eventId}</span>
                                    <button class="link-btn" onclick="eventsManager.showEventDetails('${eventId}')">
                                        View Details
                                    </button>
                                </div>
                            `).join('')}
                        </div>
                        <button class="secondary-btn" onclick="plannerManager.addEvent('${group.id}')">
                            <i class="fas fa-plus"></i>
                            Add Event
                        </button>
                    </div>
                ` : `
                    <div class="group-events-section">
                        <h3><i class="fas fa-calendar-alt"></i> Planned Events</h3>
                        <p>No events planned yet.</p>
                        <button class="secondary-btn" onclick="plannerManager.addEvent('${group.id}')">
                            <i class="fas fa-plus"></i>
                            Add First Event
                        </button>
                    </div>
                `}
            </div>
        `;
        
        // Setup location sharing toggle
        const locationToggle = document.getElementById('group-location-sharing');
        if (locationToggle) {
            locationToggle.addEventListener('change', (e) => {
                this.updateLocationSharing(group.id, e.target.checked);
            });
        }
    }

    showCreateGroupModal() {
        const modalHTML = `
            <div class="modal active" id="create-group-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Create New Group</h3>
                        <button class="modal-close" onclick="ModalManager.hide('create-group-modal')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="create-group-form">
                            <div class="form-group">
                                <label for="group-name">Group Name *</label>
                                <input type="text" id="group-name" required maxlength="50" placeholder="Enter group name">
                            </div>
                            
                            <div class="form-group">
                                <label for="group-description">Description</label>
                                <textarea id="group-description" maxlength="200" placeholder="What's this group about?"></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" id="enable-location-sharing">
                                    Enable location sharing for group members
                                </label>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="secondary-btn" onclick="ModalManager.hide('create-group-modal')">
                                    Cancel
                                </button>
                                <button type="submit" class="primary-btn">
                                    <i class="fas fa-plus"></i>
                                    Create Group
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        const existingModal = document.getElementById('create-group-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Setup form submission
        const form = document.getElementById('create-group-form');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.createGroup();
            });
        }
    }

    async createGroup() {
        const nameInput = document.getElementById('group-name');
        const descriptionInput = document.getElementById('group-description');
        const locationSharingInput = document.getElementById('enable-location-sharing');
        
        if (!nameInput || !nameInput.value.trim()) {
            ToastManager.show('Please enter a group name', 'error');
            return;
        }
        
        const groupData = {
            name: nameInput.value.trim(),
            description: descriptionInput ? descriptionInput.value.trim() : '',
            is_location_sharing_enabled: locationSharingInput ? locationSharingInput.checked : false
        };
        
        try {
            LoadingManager.show('Creating group...');
            
            // In a real app, this would call the API
            // const newGroup = await apiService.createGroup(groupData);
            
            // For demo, create a mock group
            const newGroup = {
                id: 'group' + Date.now(),
                ...groupData,
                created_by: 'current_user',
                members: [
                    { id: 'current_user', name: 'You', avatar_url: null, is_online: true }
                ],
                events: [],
                meeting_point: null,
                created_at: new Date().toISOString()
            };
            
            this.currentGroups.push(newGroup);
            this.renderGroups(this.currentGroups);
            
            ModalManager.hide('create-group-modal');
            ToastManager.show('Group created successfully!', 'success');
            
        } catch (error) {
            console.error('Failed to create group:', error);
            Utils.handleError(error, 'Creating group');
        } finally {
            LoadingManager.hide();
        }
    }

    addMember(groupId) {
        // In a real app, this would open a member invitation modal
        ToastManager.show('Member invitation feature coming soon!', 'info');
    }

    editGroup(groupId) {
        // In a real app, this would open an edit group modal
        ToastManager.show('Group editing feature coming soon!', 'info');
    }

    addEvent(groupId) {
        // In a real app, this would open an event selection modal
        ToastManager.show('Event planning feature coming soon!', 'info');
    }

    showOnMap(latitude, longitude) {
        // Switch to home tab and center map on the location
        document.querySelector('[data-tab="home"]').click();
        
        setTimeout(() => {
            mapService.setView([latitude, longitude], 15);
            ToastManager.show('Meeting point shown on map', 'success');
        }, 300);
    }

    async updateLocationSharing(groupId, enabled) {
        try {
            // In a real app, this would update the group settings
            const group = this.currentGroups.find(g => g.id === groupId);
            if (group) {
                group.is_location_sharing_enabled = enabled;
            }
            
            ToastManager.show(
                enabled ? 'Location sharing enabled' : 'Location sharing disabled',
                'success'
            );
            
        } catch (error) {
            console.error('Failed to update location sharing:', error);
            Utils.handleError(error, 'Updating location sharing');
        }
    }
}

// Create global planner manager instance
const plannerManager = new PlannerManager();
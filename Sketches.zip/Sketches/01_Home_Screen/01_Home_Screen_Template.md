# Home Screen - Map Interface

## Screen Overview
The main dashboard displaying an interactive map with event locations, traffic data, and navigation controls.

## Layout Structure

### Top Bar (Status Bar + App Header)
- **Height**: 120px
- **Status Bar**: Time, battery, network (24px height)
- **App Header**: 
  - App logo/title (left)
  - Profile icon (right)
  - Search bar (center, expandable)
  - Height: 96px

### Main Map Area
- **Full screen map view** (Google Maps style)
- **Interactive elements on map**:
  - Event icons (different colors for different event types)
  - Traffic indicators (red/yellow/green route overlays)
  - User location pin (blue dot with circle)

### Map Controls (Floating)
- **Location button** (bottom right, 56x56px FAB)
- **Zoom controls** (right side, vertical stack)
- **Map style toggle** (top right corner)

### Bottom Sheet (Slide-up panel)
- **Collapsed state** (80px height):
  - Handle bar (center top)
  - Quick stats: "5 events nearby • Traffic: Light"
- **Expanded state** (40% of screen):
  - Event list preview
  - Traffic summary
  - Quick actions

### Bottom Navigation Bar
- **Height**: 72px
- **5 tabs**:
  1. Home (Map icon) - Active
  2. Events (Calendar icon)
  3. Traffic (Car icon)
  4. Planner (Users icon)
  5. More (Menu icon)

## Color Scheme
- **Primary**: #2196F3 (Blue)
- **Accent**: #FF5722 (Orange for events)
- **Traffic Colors**: 
  - Green: #4CAF50
  - Yellow: #FFC107
  - Red: #F44336
- **Background**: #FAFAFA
- **Text**: #212121, #757575

## Interactive Elements
- **Event Icons**: Tap to show event preview popup
- **Traffic Areas**: Tap to show route alternatives
- **Search**: Tap to expand and search events/locations
- **Profile**: Tap to access settings and profile

## Typography
- **Headers**: Roboto Medium 18sp
- **Body**: Roboto Regular 14sp
- **Captions**: Roboto Regular 12sp

## Spacing
- **Padding**: 16dp standard
- **Margins**: 8dp between elements
- **FAB margin**: 16dp from edges
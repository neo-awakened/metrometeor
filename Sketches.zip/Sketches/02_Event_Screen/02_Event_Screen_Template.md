# Event Screen - Events & Route Planning

## Screen Overview
Displays event listings, detailed event information, route suggestions, and crowd density visualization.

## Layout Structure

### Header Bar
- **Height**: 96px
- **Back arrow** (left, 24x24px)
- **Title**: "Events" or Event name
- **Filter icon** (right, 24x24px)
- **Search icon** (right, 24x24px)

### Event List View (Default State)

#### Filter Bar
- **Height**: 56px
- **Horizontal scroll chips**:
  - "All Events" (selected)
  - "Music Festivals"
  - "Food Events"
  - "Sports"
  - "Cultural"
  - "Distance" (with dropdown)

#### Event Cards
- **Card height**: 120px each
- **Card structure**:
  - Event image (left, 80x80px, rounded corners)
  - Event details (right section):
    - Event title (16sp, bold)
    - Date & time (14sp, gray)
    - Location (14sp, with location icon)
    - Distance from user (12sp, blue)
    - Crowd indicator (colored dot + text)

### Event Detail View (When Event Selected)

#### Event Header
- **Background image** (full width, 200px height)
- **Gradient overlay** (bottom 60px)
- **Event title** (white text, 24sp)
- **Date/time badge** (top right corner)

#### Event Information Panel
- **Description section** (expandable)
- **Location with map preview** (120px height mini-map)
- **Crowd density indicator**:
  - Visual heat level (5 colored circles)
  - Text: "Current crowd: Moderate"
  - Real-time updates toggle

#### Route Planning Section
- **Header**: "Get There" (18sp, bold)
- **Route options** (3 cards, horizontal scroll):
  
  **Driving Route Card**:
  - Car icon + "Driving"
  - Duration: "25 min"
  - Distance: "8.5 km"
  - Traffic status with color indicator
  
  **Public Transport Card**:
  - Bus/train icon + "Public Transport"
  - Duration: "35 min"
  - Cost: "$3.50"
  - Route preview (bus numbers/train lines)
  
  **Walking Path Card**:
  - Walking icon + "Walking"
  - Duration: "1h 15min"
  - Distance: "4.2 km"
  - Difficulty: "Easy"

#### Crowd Density Heatmap
- **Interactive map section** (240px height)
- **Real-time heatmap overlay**:
  - Green: Low density
  - Yellow: Medium density
  - Orange: High density
  - Red: Very crowded
- **Legend** (bottom of map)
- **Time slider** (to view predicted crowd levels)

### Action Buttons (Fixed Bottom)
- **Primary CTA**: "Get Directions" (full width, 48dp height)
- **Secondary actions** (row of 3):
  - "Save Event" (bookmark icon)
  - "Share" (share icon)
  - "Add to Planner" (plus icon)

## Color Scheme
- **Event type colors**:
  - Music: #9C27B0 (Purple)
  - Food: #FF9800 (Orange)
  - Sports: #4CAF50 (Green)
  - Cultural: #2196F3 (Blue)
- **Crowd density colors**:
  - Low: #4CAF50
  - Medium: #FFC107
  - High: #FF5722
  - Very High: #F44336

## Interactive Elements
- **Event cards**: Tap to expand to detail view
- **Route cards**: Tap to open full navigation
- **Crowd heatmap**: Pinch to zoom, tap for specific area info
- **Time slider**: Drag to see predicted crowd levels
- **Filter chips**: Tap to filter events

## States & Animations
- **Loading state**: Skeleton cards while fetching events
- **Empty state**: "No events found" with illustration
- **Error state**: Retry button for failed requests
- **Pull to refresh**: Standard Android pull-to-refresh
- **Card expansion**: Smooth transition from list to detail view

## Typography
- **Event titles**: Roboto Medium 16sp
- **Event details**: Roboto Regular 14sp
- **Section headers**: Roboto Medium 18sp
- **Route duration**: Roboto Bold 16sp

## Spacing
- **Card margins**: 16dp horizontal, 8dp vertical
- **Internal padding**: 16dp
- **Section spacing**: 24dp between major sections
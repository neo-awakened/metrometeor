# Navigation Structure & Component Library

## App Navigation Flow

### Primary Navigation Structure
```
App Root
├── Bottom Navigation (5 tabs)
│   ├── Home (Map Interface)
│   ├── Events (Event Discovery & Details)
│   ├── Traffic (Traffic Simulation)
│   ├── Planner (Group Organization)
│   └── More (Settings & Additional Features)
│       ├── Offline Maps
│       ├── Deals & Tickets
│       ├── SOS Settings
│       ├── Profile Settings
│       ├── App Preferences
│       └── Help & Support
```

### Screen Hierarchy & Deep Linking

#### Home Screen Flow
```
Home (Map) Screen
├── Event Details (tap event icon)
├── Traffic Details (tap traffic area)
├── Search Results (from search bar)
├── Profile Menu (tap profile icon)
└── Quick Settings (pull down)
```

#### Events Screen Flow
```
Events Screen
├── Event List View (default)
├── Event Detail View
│   ├── Route Planning
│   ├── Crowd Density Heatmap
│   ├── Ticket Purchasing (redirect to Deals)
│   └── Add to Group Planner
├── Event Filters
└── Event Search
```

#### Traffic Screen Flow
```
Traffic Screen
├── Route Prediction
├── Alternative Routes
├── Traffic Timeline
├── Disruption Alerts
├── Real-time Updates
└── Navigate (external maps app)
```

#### Planner Screen Flow
```
Planner Screen
├── My Groups List
├── Create New Group
├── Group Detail View
│   ├── Member Management
│   ├── Real-time Location Sharing
│   ├── Event Planning
│   ├── Group Chat
│   └── Emergency Features
├── Invitations Management
└── Shared Plans
```

### Modal & Overlay Flows

#### Bottom Sheets
- **Map Information Panel** (Home screen)
- **Event Quick Preview** (from map pins)
- **Route Options** (from traffic/events)
- **Group Member Actions** (from planner)

#### Full-Screen Modals
- **Event Booking Flow** (from deals)
- **Group Creation Wizard** (from planner)
- **Emergency Contact Setup** (from SOS)
- **Offline Map Download** (from offline maps)

#### Pop-ups & Alerts
- **Location Permission** requests
- **Emergency Confirmation** dialogs
- **Deal Expiration** warnings
- **Group Invitation** notifications

## Component Library

### Navigation Components

#### Bottom Navigation Bar
```
Component: BottomNavigationBar
Height: 72dp
Background: White (#FFFFFF)
Border: 1dp top border (#E0E0E0)

Tabs (5):
- Icon: 24x24dp
- Label: 12sp, Roboto Regular
- Active state: Primary blue (#2196F3)
- Inactive state: Gray (#757575)
- Badge support: Red circle with white text
```

#### Header Components
```
Component: AppHeader
Height: 96dp (including status bar space)
Background: White with shadow

Elements:
- Back button: 24x24dp, left aligned, 16dp margin
- Title: 18sp Roboto Medium, center or left aligned
- Action buttons: 24x24dp, right aligned, 16dp margin
- Search bar: Expandable, 40dp height when expanded
```

### Card Components

#### Event Card
```
Component: EventCard
Height: 120dp
Background: White with 2dp elevation
Corner radius: 8dp
Padding: 16dp

Layout:
- Event image: 80x80dp, 4dp corner radius
- Title: 16sp Roboto Medium, 1 line max
- Subtitle: 14sp Roboto Regular, gray
- Distance: 12sp Roboto Regular, blue
- Status indicator: Colored dot + text
```

#### Deal Card
```
Component: DealCard
Height: 180dp
Background: White with 4dp elevation
Corner radius: 12dp
Padding: 16dp

Layout:
- Deal image: 100x120dp
- Title: 16sp Roboto Medium
- Original price: 14sp strikethrough gray
- Deal price: 18sp Roboto Bold
- Savings badge: Green background, white text
- CTA button: 40dp height, full width
```

### Button Components

#### Primary Button
```
Component: PrimaryButton
Height: 48dp
Background: Primary blue (#2196F3)
Text: 16sp Roboto Medium, white
Corner radius: 24dp
Elevation: 2dp
Minimum width: 120dp
```

#### Secondary Button
```
Component: SecondaryButton
Height: 40dp
Background: Transparent
Border: 1dp primary blue
Text: 14sp Roboto Medium, primary blue
Corner radius: 20dp
```

#### Floating Action Button
```
Component: FAB
Size: 56x56dp
Background: Primary blue (#2196F3)
Icon: 24x24dp, white
Elevation: 6dp
Corner radius: 28dp (circular)
```

#### Emergency Button
```
Component: EmergencyButton
Size: 80x80dp
Background: Emergency red (#F44336)
Icon: 32x32dp, white
Elevation: 8dp
Corner radius: 40dp (circular)
Pulse animation: 2s interval
```

### Input Components

#### Text Input Field
```
Component: TextInputField
Height: 56dp
Background: White
Border: 1dp gray, focus state: 2dp blue
Corner radius: 4dp
Padding: 16dp horizontal, 16dp vertical
Text: 16sp Roboto Regular
Label: 12sp Roboto Regular, gray (floating)
```

#### Search Bar
```
Component: SearchBar
Height: 40dp (collapsed), 56dp (expanded)
Background: Light gray (#F5F5F5)
Corner radius: 20dp
Padding: 12dp horizontal
Icon: 20x20dp search icon, gray
Placeholder: 14sp Roboto Regular, gray
```

### Status Indicators

#### Crowd Density Indicator
```
Component: CrowdIndicator
Size: Variable (text + colored circle)
Circle: 8dp diameter
Colors:
- Low: Green (#4CAF50)
- Medium: Yellow (#FFC107)
- High: Orange (#FF5722)
- Very High: Red (#F44336)
Text: 12sp Roboto Regular
```

#### Loading Indicators
```
Component: LoadingSpinner
Size: 24x24dp (small), 40x40dp (medium), 56x56dp (large)
Color: Primary blue (#2196F3)
Animation: 1.5s rotation cycle

Component: LoadingSkeleton
Background: Light gray (#F0F0F0) with shimmer animation
Corner radius: Matches target component
Animation: 1.5s wave effect
```

### Interactive Components

#### Map Pin
```
Component: MapPin
Size: 32x40dp
Background: Primary blue (#2196F3)
Icon: 16x16dp, white
Shadow: 2dp elevation
Animation: Bounce on tap
Badge: Red circle for notifications
```

#### Progress Bar
```
Component: ProgressBar
Height: 4dp
Background: Light gray (#E0E0E0)
Progress: Primary blue (#2196F3)
Corner radius: 2dp
Animation: Smooth fill transition
```

#### Switch Toggle
```
Component: SwitchToggle
Size: 52x32dp
Track: Gray (off), Primary blue (on)
Thumb: 28dp diameter, white
Animation: 200ms slide transition
```

### Navigation Patterns

#### Screen Transitions
```
Push Navigation:
- Slide from right (Android standard)
- Duration: 300ms
- Easing: Decelerate interpolator

Modal Presentation:
- Slide up from bottom
- Duration: 250ms
- Background dim: 50% black overlay

Bottom Sheet:
- Slide up with rubber band effect
- Gesture-driven dismissal
- Backdrop tap to dismiss
```

#### Deep Link Patterns
```
Base URL: festivalapp://

Deep Link Patterns:
- festivalapp://home - Home screen
- festivalapp://events/[eventId] - Specific event
- festivalapp://traffic?from=[location]&to=[location] - Traffic route
- festivalapp://groups/[groupId] - Group details
- festivalapp://deals/[dealId] - Specific deal
- festivalapp://maps/download?area=[areaId] - Offline map download
- festivalapp://emergency - SOS settings
```

### Responsive Behavior

#### Screen Size Adaptations
```
Compact (< 600dp width):
- Single column layout
- Bottom navigation
- Collapsed search
- Simplified headers

Medium (600-840dp width):
- Two column layout for lists
- Side navigation option
- Expanded search bar
- Additional quick actions

Large (> 840dp width):
- Three column layout
- Persistent side navigation
- Dual pane details
- Enhanced multitasking
```

#### Orientation Changes
```
Portrait Mode:
- Standard single column
- Bottom navigation visible
- Full-height content

Landscape Mode:
- Compact header (reduce height by 20%)
- Hide bottom navigation labels
- Optimize map view for wider aspect
- Side-by-side detail views
```

### Accessibility Components

#### Focus Indicators
```
Component: FocusIndicator
Border: 2dp primary blue
Corner radius: Matches target component
Animation: Fade in 150ms
```

#### Screen Reader Support
```
Content Description Patterns:
- "Event card, [Event Name], [Date], [Location], [Distance]"
- "Navigate to [destination], estimated time [duration]"
- "Emergency button, double tap to activate"
- "Group member [name], online, last seen [time]"
```

### Animation Library

#### Micro-interactions
```
Button Press:
- Scale: 0.95x for 100ms
- Elevation: Increase by 2dp
- Return: 150ms spring animation

Card Tap:
- Elevation: Increase by 4dp
- Scale: 1.02x for 50ms
- Background: Slight color shift

Loading States:
- Pulse: 1.5s cycle, 0.7-1.0 opacity
- Shimmer: 1.5s horizontal sweep
- Rotation: 1s continuous for spinners
```

## Design System Documentation

### Color Palette
```
Primary Colors:
- Primary: #2196F3 (Blue)
- Primary Dark: #1976D2
- Primary Light: #BBDEFB

Secondary Colors:
- Accent: #FF5722 (Orange)
- Accent Dark: #E64A19
- Accent Light: #FFCCBC

Status Colors:
- Success: #4CAF50
- Warning: #FFC107
- Error: #F44336
- Info: #2196F3

Neutral Colors:
- Text Primary: #212121
- Text Secondary: #757575
- Text Hint: #BDBDBD
- Divider: #E0E0E0
- Background: #FAFAFA
- Surface: #FFFFFF
```

### Typography Scale
```
Display Large: 57sp, Roboto Regular
Display Medium: 45sp, Roboto Regular
Display Small: 36sp, Roboto Regular

Headline Large: 32sp, Roboto Regular
Headline Medium: 28sp, Roboto Regular
Headline Small: 24sp, Roboto Regular

Title Large: 22sp, Roboto Medium
Title Medium: 16sp, Roboto Medium
Title Small: 14sp, Roboto Medium

Body Large: 16sp, Roboto Regular
Body Medium: 14sp, Roboto Regular
Body Small: 12sp, Roboto Regular

Label Large: 14sp, Roboto Medium
Label Medium: 12sp, Roboto Medium
Label Small: 11sp, Roboto Medium
```

### Spacing System
```
Base Unit: 4dp

Spacing Scale:
- xs: 4dp
- sm: 8dp
- md: 16dp
- lg: 24dp
- xl: 32dp
- xxl: 48dp

Component Spacing:
- Button padding: 16dp horizontal, 12dp vertical
- Card padding: 16dp all sides
- List item padding: 16dp horizontal, 12dp vertical
- Screen margins: 16dp horizontal
- Section spacing: 24dp vertical
```